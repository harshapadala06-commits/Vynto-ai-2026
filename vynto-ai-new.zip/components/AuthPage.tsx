import React, { useState } from 'react';
import { signup, login, loginWithGoogle, loginWithFacebook, loginAsGuest, requestPasswordReset } from '../services/authService';
import { User } from '../types';

interface AuthPageProps {
  onLoginSuccess: (user: User) => void;
  onSignupSuccess: (user: User) => void;
}

type AuthMode = 'login' | 'signup' | 'forgot_password';

const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess, onSignupSuccess }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [loading, setLoading] = useState(''); // can be 'email', 'google', 'facebook', 'guest', 'reset'
  const [error, setError] = useState('');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [resetSuccess, setResetSuccess] = useState(false);

  const toggleMode = () => {
    setMode(prev => prev === 'login' ? 'signup' : 'login');
    setError('');
    setResetSuccess(false);
  };

  const switchToReset = () => {
      setMode('forgot_password');
      setError('');
      setResetSuccess(false);
  }

  const backToLogin = () => {
      setMode('login');
      setError('');
      setResetSuccess(false);
  }

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleAuthAction = async (action: () => Promise<User | void> | User | void, type: string) => {
      setError('');
      setLoading(type);
      try {
          const result = await action();
          if (type === 'signup') {
              if (result) onSignupSuccess(result as User);
          } else if (type === 'reset') {
              setResetSuccess(true);
          } else if (result) {
              onLoginSuccess(result as User);
          }
      } catch (err: any) {
          setError(err.message || "An unexpected error occurred.");
      } finally {
          setLoading('');
      }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateEmail(email)) {
        setError('Please enter a valid email address.');
        return;
    }

    if (mode === 'signup') {
      if (!fullName.trim() || !username.trim()) {
          setError('Please fill in all fields.');
          return;
      }
      handleAuthAction(() => signup({ fullName, username, email, password }), 'signup');
    } else if (mode === 'login') {
      handleAuthAction(() => login(email, password), 'login');
    } else if (mode === 'forgot_password') {
       handleAuthAction(() => requestPasswordReset(email), 'reset');
    }
  };

  const isSignup = mode === 'signup';
  const isReset = mode === 'forgot_password';

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900 animate-fade-in p-4">
      <div className="w-full max-w-sm bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700 p-6 md:p-8">
        <div className="text-center mb-6">
            <div className="w-12 h-12 bg-vynto-red rounded-xl mx-auto flex items-center justify-center text-white font-bold text-2xl mb-4">V</div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                {isReset ? 'Reset Password' : (isSignup ? 'Create Your Account' : 'Welcome Back')}
            </h2>
            <p className="text-gray-500 dark:text-gray-400 text-sm mt-2">
                {isReset 
                    ? 'Enter your email to receive instructions.' 
                    : (isSignup ? 'Get started with VYNTO AI.' : 'Log in to continue.')}
            </p>
            {!isReset && <p className="text-xs text-gray-400 dark:text-gray-500 mt-2 font-medium">A V STORE Product</p>}
        </div>

        {error && <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm p-4 rounded-lg text-center font-medium mb-4">{error}</div>}
        
        {isReset && resetSuccess && (
             <div className="bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 text-sm p-4 rounded-lg text-center font-medium mb-4">
                 Check your email for the password reset link.
             </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignup && (
            <>
              <div><input type="text" placeholder="Full Name" required value={fullName} onChange={e => setFullName(e.target.value)} className="w-full px-4 py-2.5 rounded-lg border dark:bg-gray-700 dark:border-gray-600 dark:text-white" /></div>
              <div><input type="text" placeholder="Username" required value={username} onChange={e => setUsername(e.target.value)} className="w-full px-4 py-2.5 rounded-lg border dark:bg-gray-700 dark:border-gray-600 dark:text-white" /></div>
            </>
          )}
          
          <div><input type="email" placeholder="Email address" required value={email} onChange={e => setEmail(e.target.value)} className="w-full px-4 py-2.5 rounded-lg border dark:bg-gray-700 dark:border-gray-600 dark:text-white" /></div>
          
          {!isReset && (
             <div>
                 <input type="password" placeholder="Password" required value={password} onChange={e => setPassword(e.target.value)} className="w-full px-4 py-2.5 rounded-lg border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
                 {mode === 'login' && (
                     <div className="flex justify-end mt-1">
                         <button type="button" onClick={switchToReset} className="text-xs text-gray-500 hover:text-vynto-red hover:underline">Forgot Password?</button>
                     </div>
                 )}
             </div>
          )}

          <button type="submit" disabled={!!loading || (isReset && resetSuccess)} className="w-full bg-vynto-red text-white font-semibold py-3 rounded-lg hover:bg-vynto-hover transition-colors disabled:opacity-70 disabled:cursor-not-allowed">
              {loading === 'login' || loading === 'signup' || loading === 'reset' ? 'Processing...' : (isReset ? 'Send Reset Link' : (isSignup ? 'Sign Up' : 'Log In'))}
          </button>
        </form>
        
        {isReset ? (
            <div className="mt-6 text-center">
                <button onClick={backToLogin} className="text-sm font-semibold text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white">
                    Back to Log In
                </button>
            </div>
        ) : (
            <>
                <div className="my-6 flex items-center"><div className="flex-grow border-t dark:border-gray-700"></div><span className="flex-shrink mx-4 text-xs text-gray-400">OR</span><div className="flex-grow border-t dark:border-gray-700"></div></div>

                <div className="space-y-3">
                    <SocialButton onClick={() => handleAuthAction(loginWithGoogle, 'google')} icon={<GoogleIcon />} label="Continue with Google" isLoading={loading==='google'} />
                    <SocialButton onClick={() => handleAuthAction(loginWithFacebook, 'facebook')} icon={<FacebookIcon />} label="Continue with Facebook" isLoading={loading==='facebook'} />
                </div>

                <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-6">
                    {isSignup ? 'Already have an account?' : "Don't have an account?"}
                    <button onClick={toggleMode} className="font-semibold text-vynto-red hover:underline ml-1">{isSignup ? 'Log In' : 'Sign Up'}</button>
                </p>

                <div className="text-center mt-4">
                    <button onClick={() => handleAuthAction(loginAsGuest, 'guest')} className="text-xs text-gray-400 hover:text-vynto-red hover:underline font-medium">Continue as Guest</button>
                </div>
            </>
        )}
      </div>
    </div>
  );
};

const SocialButton = ({ onClick, icon, label, isLoading }: { onClick: () => void, icon: React.ReactNode, label: string, isLoading: boolean }) => (
    <button onClick={onClick} disabled={isLoading} className="w-full flex items-center justify-center gap-3 py-2.5 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 transition-colors text-gray-700 dark:text-gray-200 bg-white dark:bg-transparent">
        {isLoading ? <div className="w-5 h-5 border-2 border-gray-300 border-t-transparent rounded-full animate-spin"></div> : icon}
        <span className="font-medium text-sm">{label}</span>
    </button>
);

const GoogleIcon = () => <svg className="w-5 h-5" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"></path><path fill="#FF3D00" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z"></path><path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238C29.211 35.091 26.715 36 24 36c-5.222 0-9.519-3.317-11.284-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"></path><path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303c-.792 2.237-2.231 4.166-4.087 5.571l6.19 5.238C42.021 35.596 44 30.138 44 24c0-1.341-.138-2.65-.389-3.917z"></path></svg>;
const FacebookIcon = () => <svg className="w-5 h-5 text-[#1877F2]" fill="currentColor" viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" /></svg>;

export default AuthPage;