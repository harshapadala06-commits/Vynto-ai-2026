import React from 'react';
import { Plan, PlanTier, ModelType } from '../types';

const ModelIcons: Record<ModelType, React.ReactNode> = {
  [ModelType.CHATGPT]: (
    <svg className="w-4 h-4 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <title>ChatGPT</title>
      <path d="M12.5 2.5a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM9.5 9.5v5M14.5 9.5v5M9.5 12h5" />
    </svg>
  ),
  [ModelType.GEMINI]: (
    <svg className="w-4 h-4 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <title>Gemini</title>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18M3 12h18M5.636 5.636l12.728 12.728M18.364 5.636L5.636 18.364" />
    </svg>
  ),
  [ModelType.CLAUDE]: (
    <svg className="w-4 h-4 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <title>Claude</title>
        <path d="M14.5 14.5H9.5V9.5h5v5z" />
        <path d="M18.5 14.5H16v-8.5a2 2 0 0 0-2-2H5.5" />
    </svg>
  ),
  [ModelType.GROK]: (
    <svg className="w-4 h-4 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <title>Grok</title>
        <path d="M7 7l10 10M7 17L17 7" />
    </svg>
  ),
};


interface PlanCardProps {
  plan: Plan;
  currentPlanId: PlanTier;
  onSelect: (planId: PlanTier) => void;
  isGuest?: boolean;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, currentPlanId, onSelect, isGuest }) => {
  const isCurrent = plan.id === currentPlanId;
  const isPopular = plan.isPopular;

  const handleCardClick = () => {
    if (isCurrent) return;
    onSelect(plan.id);
  };

  return (
    <div 
      onClick={handleCardClick}
      className={`relative flex flex-col p-0 rounded-2xl border transition-all duration-300 overflow-hidden group h-full bg-gray-50/50 dark:bg-gray-800/50
        ${isCurrent 
          ? 'border-gray-200 cursor-default dark:border-gray-700' 
          : 'border-gray-200 hover:border-vynto-red hover:shadow-xl cursor-pointer dark:border-gray-700 dark:hover:border-vynto-red'}
        ${isPopular ? 'shadow-lg' : 'shadow-sm'}
      `}
    >
      {isPopular && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-vynto-red"></div>
      )}
      
      <div className="p-6 pb-4">
        <div className="flex justify-between items-start">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white uppercase tracking-wide">{plan.name}</h3>
            {isPopular && (
                <div className="bg-vynto-light text-vynto-red text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-widest">
                Most Popular
                </div>
            )}
        </div>
        <div className="flex items-baseline mt-4 mb-1">
          <span className="text-4xl font-extrabold tracking-tight text-gray-900 dark:text-white">{plan.price}</span>
        </div>
         {plan.originalPrice && (
            <span className="text-sm text-gray-400 line-through decoration-gray-400">{plan.originalPrice}</span>
          )}
        {plan.id !== PlanTier.BASIC && <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">per 6 months</p>}
      </div>

      <div className="flex-1 px-6 py-4 border-t border-gray-100 dark:border-gray-700">
        <ul className="space-y-4 mb-4">
          {plan.features.map((feature, idx) => (
            <li key={idx} className="flex items-start text-sm text-gray-700 dark:text-gray-300 font-medium">
              <svg className="h-5 w-5 text-vynto-red mr-3 shrink-0" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>
              <span className="leading-tight">{feature}</span>
            </li>
          ))}
        </ul>
         {plan.models && (
            <div className="pt-4 mt-4 border-t border-gray-100 dark:border-gray-700">
                <div className="flex items-center gap-3">
                     <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase">Models Included</span>
                     <div className="flex items-center gap-2">
                        {plan.models.map(modelId => (
                            <div key={modelId} className="p-1.5 bg-gray-100 dark:bg-gray-700 rounded-full">
                                {ModelIcons[modelId]}
                            </div>
                        ))}
                     </div>
                </div>
            </div>
         )}
      </div>

      <div className="p-6 pt-0 mt-auto">
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleCardClick();
          }}
          disabled={isCurrent}
          className={`w-full py-3 px-4 rounded-xl text-sm font-bold tracking-wide transition-all duration-200
            ${isCurrent 
              ? 'bg-gray-100 text-gray-400 cursor-default dark:bg-gray-700 dark:text-gray-500' 
              : isPopular 
                ? 'bg-vynto-red text-white hover:bg-vynto-hover shadow-lg shadow-red-600/30' 
                : 'bg-gray-900 text-white hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100'}
          `}
        >
          {isCurrent ? 'CURRENT PLAN' : 'UPGRADE PLAN'}
        </button>
      </div>
    </div>
  );
};

export default React.memo(PlanCard);