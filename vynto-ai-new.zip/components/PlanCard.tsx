import React from 'react';
import { Plan, PlanTier, ModelType } from '../types';

const ModelIcons: Record<ModelType, React.ReactNode> = {
  [ModelType.CHATGPT]: (
    <svg className="w-4 h-4 text-emerald-600 dark:text-emerald-400" viewBox="0 0 24 24" fill="currentColor">
      <title>ChatGPT</title>
      <path d="M12.0002 2.2998C12.8702 2.2998 13.6202 2.5098 14.3902 2.8798C12.5902 3.6698 11.6602 5.0698 11.5302 6.8498C11.5302 6.8898 11.5302 6.9298 11.5302 6.9698L11.5702 9.0798L7.22021 6.5698C7.66021 5.9198 8.24021 5.3798 8.92021 4.9798C11.1602 3.6898 13.7902 3.7098 15.6802 5.8698C16.2702 6.5498 17.5102 8.7898 17.5102 8.7898C17.5102 8.7898 17.7502 9.2098 17.9802 9.6198C17.3002 9.4698 16.7102 9.5398 16.1402 9.8698C14.2802 10.9398 13.6402 13.3098 14.7102 15.1698L15.3402 16.2598L14.7002 16.6298C14.4102 16.7998 14.0702 16.8898 13.7302 16.8898C12.7902 16.8898 11.8902 16.4098 11.4102 15.5898L11.1302 15.1098L11.0202 14.9198C10.5302 14.0698 8.66021 10.8298 8.66021 10.8298C8.66021 10.8298 8.42021 10.4098 8.17021 10.0098C8.85021 10.1598 9.44021 10.0898 10.0102 9.7598C11.8702 8.6898 12.5102 6.3198 11.4402 4.4598L11.2602 4.1498C11.2302 4.0998 11.2002 4.0498 11.1602 3.9998C11.4302 3.9698 11.7102 3.9498 12.0002 3.9498V2.2998Z" opacity="0.9"/>
      <path d="M12 22C6.48 22 2 17.52 2 12C2 6.48 6.48 2 12 2C13.5 2 14.93 2.33 16.24 2.92L14.44 4.54C13.68 4.2 12.86 4 12 4C7.58 4 4 7.58 4 12C4 16.42 7.58 20 12 20C16.42 20 20 16.42 20 12C20 10.37 19.51 8.85 18.66 7.56L20.21 5.86C21.34 7.66 22 9.76 22 12C22 17.52 17.52 22 12 22Z" />
    </svg>
  ),
  [ModelType.GEMINI]: (
    <svg className="w-4 h-4 text-blue-600 dark:text-blue-400" viewBox="0 0 24 24" fill="currentColor">
        <title>Gemini</title>
        <path d="M12.0003 2.5647C12.0003 2.5647 12.2858 8.27786 16.2847 11.9994C12.2858 15.7209 12.0003 21.4341 12.0003 21.4341C12.0003 21.4341 11.7148 15.7209 7.71594 11.9994C11.7148 8.27786 12.0003 2.5647 12.0003 2.5647Z" />
        <path d="M19.4925 14.0752C19.4925 14.0752 19.5781 15.7892 20.7778 16.9058C19.5781 18.0224 19.4925 19.7364 19.4925 19.7364C19.4925 19.7364 19.4069 18.0224 18.2072 16.9058C19.4069 15.7892 19.4925 14.0752 19.4925 14.0752Z" />
    </svg>
  ),
  [ModelType.CLAUDE]: (
    <svg className="w-4 h-4 text-orange-600 dark:text-orange-400" viewBox="0 0 24 24" fill="currentColor">
        <title>Claude</title>
        <path d="M3 5C3 3.89543 3.89543 3 5 3H19C20.1046 3 21 3.89543 21 5V19C21 20.1046 20.1046 21 19 21H5C3.89543 21 3 20.1046 3 19V5Z" fillOpacity="0.1"/>
        <path d="M17 7H7V17H17V7Z" stroke="currentColor" strokeWidth="2" fill="none" />
        <path d="M10 12C10 10.8954 10.8954 10 12 10C13.1046 10 14 10.8954 14 12C14 13.1046 13.1046 14 12 14C10.8954 14 10 13.1046 10 12Z" fill="currentColor"/>
    </svg>
  ),
  [ModelType.GROK]: (
    <svg className="w-4 h-4 text-gray-900 dark:text-white" viewBox="0 0 24 24" fill="currentColor">
        <title>Grok</title>
        <path d="M21 3H3v18h18V3z" fill="currentColor" fillOpacity="0.1" />
        <path d="M3 21L21 3" stroke="currentColor" strokeWidth="2.5" strokeLinecap="square" />
        <rect x="3" y="3" width="18" height="18" stroke="currentColor" strokeWidth="2" fill="none"/>
    </svg>
  ),
};


interface PlanCardProps {
  plan: Plan;
  currentPlanId: PlanTier;
  onSelect: (planId: PlanTier) => void;
  isGuest?: boolean;
  buttonText?: string;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, currentPlanId, onSelect, isGuest, buttonText }) => {
  const isCurrent = plan.id === currentPlanId;
  const isPopular = plan.isPopular;

  const handleCardClick = () => {
    if (isCurrent && !isGuest) return; // Allow guest to re-select "their" basic plan to sign up
    onSelect(plan.id);
  };

  const getButtonText = () => {
    if (buttonText) return buttonText;
    if (isCurrent) return 'CURRENT PLAN';
    return 'UPGRADE PLAN';
  }

  return (
    <div 
      onClick={handleCardClick}
      className={`relative flex flex-col p-0 rounded-2xl border transition-all duration-300 overflow-hidden group h-full bg-gray-50/50 dark:bg-gray-800/50
        ${(isCurrent && !isGuest)
          ? 'border-gray-200 cursor-default dark:border-gray-700' 
          : 'border-gray-200 hover:border-vynto-red hover:shadow-xl cursor-pointer dark:border-gray-700 dark:hover:border-vynto-red'}
        ${isPopular ? 'shadow-lg' : 'shadow-sm'}
      `}
    >
      {isPopular && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-vynto-red"></div>
      )}
      
      <div className="p-6 pb-4">
        <div className="flex justify-between items-start">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white uppercase tracking-wide">{plan.name}</h3>
            {isPopular && (
                <div className="bg-vynto-light text-vynto-red text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-widest">
                Most Popular
                </div>
            )}
        </div>
        <div className="flex items-baseline mt-4 mb-1">
          <span className="text-4xl font-extrabold tracking-tight text-gray-900 dark:text-white">{plan.price}</span>
        </div>
         {plan.originalPrice && (
            <span className="text-sm text-gray-400 line-through decoration-gray-400">{plan.originalPrice}</span>
          )}
        {plan.id !== PlanTier.BASIC && <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">per 6 months</p>}
      </div>

      <div className="flex-1 px-6 py-4 border-t border-gray-100 dark:border-gray-700">
        <ul className="space-y-4 mb-4">
          {plan.features.map((feature, idx) => (
            <li key={idx} className="flex items-start text-sm text-gray-700 dark:text-gray-300 font-medium">
              <svg className="h-5 w-5 text-vynto-red mr-3 shrink-0" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>
              <span className="leading-tight">{feature}</span>
            </li>
          ))}
        </ul>
         {plan.models && (
            <div className="pt-4 mt-4 border-t border-gray-100 dark:border-gray-700">
                <div className="flex items-center gap-3">
                     <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase">Models Included</span>
                     <div className="flex items-center gap-2">
                        {plan.models.map(modelId => (
                            <div key={modelId} className="p-1.5 bg-white dark:bg-gray-700 rounded-full shadow-sm border border-gray-100 dark:border-gray-600">
                                {ModelIcons[modelId]}
                            </div>
                        ))}
                     </div>
                </div>
            </div>
         )}
      </div>

      <div className="p-6 pt-0 mt-auto">
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleCardClick();
          }}
          disabled={isCurrent && !isGuest}
          className={`w-full py-3 px-4 rounded-xl text-sm font-bold tracking-wide transition-all duration-200
            ${(isCurrent && !isGuest) 
              ? 'bg-gray-100 text-gray-400 cursor-default dark:bg-gray-700 dark:text-gray-500' 
              : isPopular 
                ? 'bg-vynto-red text-white hover:bg-vynto-hover shadow-lg shadow-red-600/30' 
                : 'bg-gray-900 text-white hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100'}
          `}
        >
          {getButtonText()}
        </button>
      </div>
    </div>
  );
};

export default React.memo(PlanCard);
