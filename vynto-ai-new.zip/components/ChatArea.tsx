import React, { useEffect, useRef, useState } from 'react';
import { Message } from '../types';

interface ChatAreaProps {
  messages: Message[];
  isStreaming: boolean;
  onFollowUpClick: (question: string) => void;
  onPinMessage: (msg: Message) => void;
}

const ProfessionalMarkdownRenderer: React.FC<{ content: string }> = React.memo(({ content }) => {
  const lines = content.split('\n');

  const renderLine = (line: string) => {
    // This function handles bolding within a line of text.
    const parts = line.split(/(\*\*.*?\*\*)/g).filter(Boolean);
    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={index} className="font-semibold text-gray-900 dark:text-white">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  const elements = lines.map((line, index) => {
    // Main Heading (e.g., **Title**)
    if (line.startsWith('**') && line.endsWith('**') && !line.slice(2, -2).includes('**')) {
      return <h2 key={index} className="text-lg font-bold text-gray-900 dark:text-white mb-3 mt-4 first:mt-0">{line.slice(2, -2)}</h2>;
    }

    // Bullet point (e.g., - Point one)
    if (line.trim().startsWith('- ')) {
      const bulletContent = line.trim().substring(2);
      return (
        <div key={index} className="flex items-start text-gray-700 dark:text-gray-300 mb-1.5 leading-relaxed">
          <span className="mr-3 text-vynto-red mt-1 text-lg">•</span>
          <div className="flex-1">
            {renderLine(bulletContent)}
          </div>
        </div>
      );
    }
    
    // Handle empty lines as vertical space. A single empty line creates a small break.
    if (line.trim() === '') {
        // Avoid adding space if the previous line was also a spacer or it's the first line.
        if (index > 0 && lines[index - 1].trim() !== '') {
            return <div key={index} className="h-2"></div>;
        }
        return null;
    }

    return (
        <p key={index} className="text-gray-800 dark:text-gray-300 mb-3 leading-relaxed">
            {renderLine(line)}
        </p>
    );
  });

  return <>{elements.filter(Boolean)}</>;
});


const ChatArea: React.FC<ChatAreaProps> = ({ messages, isStreaming, onFollowUpClick, onPinMessage }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isStreaming]);

  if (messages.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-col w-full max-w-3xl mx-auto pb-40 pt-8 px-4 sm:px-6">
      {messages.map((msg) => (
        <MessageItem key={msg.id} msg={msg} onFollowUpClick={onFollowUpClick} onPin={onPinMessage} />
      ))}
      <div ref={bottomRef} />
    </div>
  );
};

const MessageItem: React.FC<{ msg: Message; onFollowUpClick: (q: string) => void, onPin: (m: Message) => void }> = ({ msg, onFollowUpClick, onPin }) => {
    
    // User Message
    if (msg.role === 'user') {
      return (
        <div className="mb-8 md:mb-10 animate-fade-in flex justify-end">
            <div className="max-w-[90%] md:max-w-[85%]">
                {msg.images && msg.images.length > 0 && (
                   <div className="flex gap-4 mb-4 overflow-x-auto justify-end">
                       {msg.images.map((img, idx) => (
                           <img key={idx} src={img} alt="User upload" className="h-32 md:h-40 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm object-cover" />
                       ))}
                   </div>
                )}
                <div className="bg-vynto-red text-white px-5 py-3 md:px-6 md:py-4 rounded-3xl rounded-br-lg inline-block shadow-lg shadow-red-500/20">
                    <p className="text-base font-medium leading-relaxed break-words">{msg.content}</p>
                </div>
            </div>
        </div>
      );
    }

    // Model Message
    return (
        <div className="mb-8 md:mb-10 animate-fade-in">
            <div className="bg-white dark:bg-gray-800/50 rounded-xl border border-gray-100 dark:border-gray-700/50 shadow-sm overflow-hidden relative pl-3">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-vynto-red/50 rounded-l-xl"></div>
                {/* Header */}
                <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700/50 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-vynto-red to-rose-500 flex items-center justify-center text-white text-[10px] font-bold shadow-sm">V</div>
                        <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-gray-900 dark:text-white">VYNTO AI</span>
                            {msg.modelUsed && <span className="text-[10px] text-gray-400 px-2 py-0.5 bg-gray-100 dark:bg-gray-800 rounded-full border border-gray-200 dark:border-gray-700">{msg.modelUsed}</span>}
                        </div>
                    </div>
                    {!msg.isThinking && <ActionToolbar msg={msg} onPin={onPin} />}
                </div>

                {/* Body */}
                <div className="p-5">
                    <div>
                        {msg.isThinking ? (
                            <div className="flex items-center gap-2 text-gray-400 italic">
                                <span className="w-2 h-2 rounded-full bg-gray-400 animate-pulse"></span>
                                <span className="w-2 h-2 rounded-full bg-gray-400 animate-pulse [animation-delay:0.1s]"></span>
                                <span className="w-2 h-2 rounded-full bg-gray-400 animate-pulse [animation-delay:0.2s]"></span>
                            </div>
                        ) : (
                           <ProfessionalMarkdownRenderer content={msg.content} />
                        )}
                    </div>

                    {/* Generated Media */}
                    {(msg.images?.length || 0) > 0 && (
                       <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                           {msg.images!.map((img, idx) => (
                               <img key={idx} src={img} alt="Generated visual" className="w-full rounded-xl border border-gray-100 dark:border-gray-700 shadow-md hover:shadow-lg transition-shadow" />
                           ))}
                       </div>
                    )}
                    {(msg.videos?.length || 0) > 0 && (
                       <div className="mt-6">
                           {msg.videos!.map((videoUrl, idx) => (
                               <video key={idx} controls className="w-full rounded-xl border border-gray-100 dark:border-gray-700 shadow-md">
                                   <source src={videoUrl} type="video/mp4" />
                               </video>
                           ))}
                       </div>
                    )}
                </div>

                 {/* Related Questions Footer */}
                 {!msg.isThinking && msg.relatedQuestions && msg.relatedQuestions.length > 0 && (
                     <div className="p-4 bg-gray-50/50 dark:bg-gray-900/30 border-t border-gray-100 dark:border-gray-700/50">
                         <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-3 uppercase tracking-wider">Related</h4>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                             {msg.relatedQuestions.map((q, idx) => (
                                 <button 
                                     key={idx}
                                     onClick={() => onFollowUpClick(q)}
                                     className="text-left px-3 py-2 rounded-lg bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 shadow-sm text-sm text-gray-700 dark:text-gray-300 transition-all flex items-center justify-between group/q active:scale-[0.98]"
                                 >
                                     <span className="truncate mr-2">{q}</span>
                                     <svg className="w-4 h-4 text-gray-300 dark:text-gray-500 group-hover/q:text-vynto-red transition-colors shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
                                 </button>
                             ))}
                         </div>
                     </div>
                 )}
            </div>
        </div>
    );
};


const ActionToolbar = ({ msg, onPin }: { msg: Message, onPin: (m: Message) => void }) => {
    const [feedback, setFeedback] = useState('');

    const showFeedback = (text: string) => {
        setFeedback(text);
        setTimeout(() => setFeedback(''), 2000);
    }

    const handleCopy = () => {
        navigator.clipboard.writeText(msg.content);
        showFeedback("Copied!");
    };

    const handleShare = () => {
        if (navigator.share) {
            navigator.share({
                title: 'VYNTO AI Response',
                text: msg.content,
            }).catch(console.error);
        } else {
            navigator.clipboard.writeText(msg.content);
            showFeedback("Link copied!");
        }
    };

    return (
        <div className="flex items-center gap-1 relative">
            {feedback && <span className="absolute right-full mr-2 text-xs bg-gray-900 text-white px-2 py-1 rounded-md animate-fade-in">{feedback}</span>}
            <ActionBtn title="Copy" onClick={handleCopy} children={<CopyIcon/>} />
            <ActionBtn title="Share" onClick={handleShare} children={<ShareIcon/>} />
            <ActionBtn title={msg.isPinned ? "Unpin" : "Pin"} onClick={() => onPin(msg)} children={<PinIcon filled={msg.isPinned} />} />
        </div>
    );
};

const ActionBtn = ({ title, onClick, children }: { title: string, onClick: () => void, children: React.ReactNode }) => (
    <button 
      onClick={onClick}
      title={title}
      className="p-1.5 rounded-md text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
    >
       {children}
    </button>
);

const CopyIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v3.042m-7.416 0v3.042c0 .212.03.418.084.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" /></svg>;
const PinIcon = ({ filled }: { filled?: boolean }) => <svg className="w-4 h-4" fill={filled ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.75V16.5L12 14.25 7.5 16.5V3.75m9 0H7.5A2.25 2.25 0 005.25 6v13.5l6.75-3.375L18.75 21V6a2.25 2.25 0 00-2.25-2.25z" /></svg>;
const ShareIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0 0a2.25 2.25 0 100-2.186m0 2.186a2.25 2.25 0 100-2.186" /></svg>;

export default React.memo(ChatArea);