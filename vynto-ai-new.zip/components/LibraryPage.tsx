import React from 'react';
import { User } from '../types';

interface LibraryPageProps {
    user: User | null;
    onMenuClick?: () => void;
}

const LibraryPage: React.FC<LibraryPageProps> = ({ user, onMenuClick }) => {
  // Pinned items feature removed in system reset.
  const items: any[] = [];

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 animate-fade-in">
      {/* Mobile Header */}
       <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
            <button 
                onClick={onMenuClick}
                className="p-1.5 -ml-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="font-bold text-lg dark:text-white tracking-tight">Library</div>
            <div className="w-8"></div>
       </div>

      <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
        <div className="max-w-5xl mx-auto w-full">
            <div className="flex justify-between items-end mb-8">
            <div>
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Library</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-2">Your pinned threads and saved history.</p>
            </div>
            <div className="relative hidden sm:block">
                <input type="text" placeholder="Search..." disabled className="pl-9 pr-4 py-2 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white rounded-lg text-sm" />
                <svg className="w-4 h-4 text-gray-400 absolute left-3 top-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden min-h-[200px]">
            {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center text-gray-400">
                    <svg className="w-12 h-12 mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>
                    <p className="text-sm font-medium text-gray-500">Pinning is coming soon</p>
                    <p className="text-xs mt-1 max-w-xs">The ability to pin and save important conversations will be available in a future update.</p>
                </div>
            ) : (
                items.map((item, idx) => (
                    <div key={item.id} className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors cursor-pointer flex items-center justify-between ${idx !== items.length - 1 ? 'border-b border-gray-100 dark:border-gray-700' : ''}`}>
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-lg bg-red-50 dark:bg-red-900/20 flex items-center justify-center text-vynto-red">
                                <svg className="w-5 h-5" fill="currentColor" stroke="none" viewBox="0 0 24 24"><path d="M16 12V4H8v8l-2 2v2h6v6l2-2v-4h6v-2l-2-2z" /></svg>
                            </div>
                            <div>
                                <h3 className="font-medium text-gray-900 dark:text-white line-clamp-1">{item.content.substring(0, 60)}...</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400">{item.model || 'AI Model'} · {new Date(item.date).toLocaleDateString()}</p>
                            </div>
                        </div>
                        <div className="text-xs text-gray-400 font-medium">
                            Pinned
                        </div>
                    </div>
                ))
            )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default LibraryPage;