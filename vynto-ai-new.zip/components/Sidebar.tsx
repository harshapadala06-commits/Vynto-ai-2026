import React, { useState, useRef, useEffect } from 'react';
import { User, PlanTier, ChatSession } from '../types';
import { PLANS } from '../constants';

interface SidebarProps {
  user: User;
  activeView: string;
  onNavigate: (view: string) => void;
  onNewChat: () => void;
  onUpgradeClick: () => void;
  onSettingsClick: () => void;
  onComingSoon: (feature: string) => void;
  onLogout: () => void;
  onAccountClick: () => void;
  onLegalClick: () => void;
  sessions?: ChatSession[];
  onDeleteSession?: (id: string) => void;
  onLoadSession?: (id: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  user, 
  activeView, 
  onNavigate, 
  onNewChat, 
  onUpgradeClick, 
  onSettingsClick,
  onComingSoon,
  onLogout,
  onAccountClick,
  onLegalClick,
  sessions = [],
  onDeleteSession,
  onLoadSession,
  isOpen = false,
  onClose
}) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
            className="fixed inset-0 bg-black/50 z-40 md:hidden animate-fade-in"
            onClick={onClose}
        ></div>
      )}

      {/* Sidebar Container */}
      <div 
        className={`fixed top-0 left-0 bottom-0 w-[280px] md:w-64 bg-gray-50 border-r border-gray-200 dark:border-gray-800 dark:bg-gray-900 flex flex-col pt-safe-top pb-safe-bottom z-50 font-sans transition-transform duration-300 ease-in-out md:translate-x-0 ${isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'} md:shadow-none`}
      >
        <div className="flex flex-col flex-1 overflow-y-auto no-scrollbar">
          {/* Header */}
          <div className="flex-shrink-0">
            {/* Brand */}
            <div className="flex items-center justify-between mb-4 px-5 pt-5">
                <div className="flex items-center gap-3 cursor-pointer group" onClick={() => onNavigate('chat')}>
                    <div className="w-7 h-7 bg-vynto-red rounded-md flex items-center justify-center text-white font-bold text-base shadow-sm group-hover:bg-vynto-hover transition-colors">V</div>
                    <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">VYNTO AI</span>
                </div>
                 {/* Mobile Close Button */}
                <button 
                    onClick={onClose}
                    className="md:hidden p-2 -mr-2 text-gray-500 hover:bg-gray-200 rounded-full"
                >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>

            {/* New Thread Button */}
            <div className="px-3 mb-6">
                <button 
                    onClick={onNewChat}
                    className="flex items-center justify-between w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 hover:shadow-subtle text-gray-700 dark:text-gray-200 px-3 py-2.5 rounded-lg transition-all duration-200 group"
                >
                    <span className="flex items-center gap-2 font-medium text-sm">
                    <svg className="w-4 h-4 text-gray-400 group-hover:text-vynto-red transition-colors" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>
                    New Thread
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono opacity-0 group-hover:opacity-100 transition-opacity hidden md:block">Ctrl I</span>
                </button>
            </div>
          </div>
          
          {/* Main Navigation */}
          <div className="flex-1 overflow-y-auto no-scrollbar">
              {/* Menu Items */}
            <nav className="space-y-0.5 px-3">
                <NavItem icon={<HomeIcon />} label="Home" active={activeView === 'chat'} onClick={() => onNavigate('chat')} />
                <NavItem icon={<GlobeIcon />} label="Discover" active={activeView === 'discover'} onClick={() => onNavigate('discover')} />
                <NavItem icon={<LibraryIcon />} label="Library" active={activeView === 'library'} onClick={() => onNavigate('library')} />
                <NavItem icon={<SpacesIcon />} label="Spaces" active={activeView === 'spaces'} onClick={() => onNavigate('spaces')} />
                <NavItem icon={<TeamIcon />} label="Teams" onClick={() => onComingSoon('Teams')} isComingSoon />
                <NavItem icon={<ChartIcon />} label="Analytics" onClick={() => onComingSoon('Analytics')} isComingSoon />
                
                {user.isAdmin && (
                    <>
                    <div className="my-2 border-t border-gray-100 dark:border-gray-800 mx-2"></div>
                    <NavItem icon={<ShieldIcon />} label="Admin Panel" active={activeView === 'admin'} onClick={() => onNavigate('admin')} />
                    </>
                )}

                <div className="my-3 border-t border-gray-100 dark:border-gray-800 mx-2"></div>
                <NavItem icon={<StoreIcon />} label="Services" active={activeView === 'services'} onClick={() => onNavigate('services')} />
                <NavItem icon={<ContactIcon />} label="Contact" active={activeView === 'contact'} onClick={() => onNavigate('contact')} />
                <NavItem icon={<DocIcon />} label="Legal & Policies" onClick={onLegalClick} />
                <NavItem icon={<SettingsIcon />} label="Settings" active={activeView === 'settings'} onClick={onSettingsClick} />
            </nav>

            <div className="mt-4 flex-1 overflow-y-auto min-h-0 px-3 custom-scrollbar">
                <div className="px-2 mb-2 text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Recent</div>
                {sessions.length === 0 ? (
                    <div className="px-2 text-sm text-gray-400 italic">No recent chats</div>
                ) : (
                    <ul className="space-y-0.5">
                        {sessions.map((session) => (
                            <li key={session.id} className="group relative">
                                <button 
                                    onClick={() => onLoadSession && onLoadSession(session.id)}
                                    className="w-full text-left px-2 py-2 rounded-md text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white transition-colors truncate pr-6"
                                >
                                    {session.title || 'Untitled Chat'}
                                </button>
                                {onDeleteSession && (
                                    <button 
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onDeleteSession(session.id);
                                        }}
                                        className="absolute right-1 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-red-600 opacity-0 group-hover:opacity-100 md:opacity-0 transition-opacity p-2 md:p-1"
                                        title="Delete thread"
                                    >
                                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" /></svg>
                                    </button>
                                )}
                            </li>
                        ))}
                    </ul>
                )}
            </div>
          </div>

          <div className="mt-auto pt-3 border-t border-gray-200 dark:border-gray-800 flex-shrink-0">
                {!user.isAnonymous && user.plan === PlanTier.BASIC && (
                  <div className="px-3 mb-2">
                      <button onClick={onUpgradeClick} className="w-full bg-vynto-red text-white font-medium py-2.5 rounded-lg hover:bg-vynto-hover transition-colors text-sm shadow-sm flex items-center justify-center gap-2">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        Upgrade Plan
                      </button>
                  </div>
                )}
                <div className="px-3 py-2 group/user relative" ref={userMenuRef}>
                  <div className="flex items-center justify-between w-full p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors">
                      <div className="flex items-center gap-3 flex-1 min-w-0" onClick={onAccountClick} role="button">
                          <div className="w-7 h-7 bg-vynto-light dark:bg-red-900/20 text-vynto-red font-bold rounded-full flex items-center justify-center text-sm shrink-0">{user.fullName.charAt(0)}</div>
                          <div className="flex-1 overflow-hidden">
                              <div className="flex items-center gap-2">
                                <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">{user.fullName}</p>
                                {!user.isAnonymous && user.plan !== PlanTier.BASIC && (
                                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-vynto-red text-white uppercase tracking-wide shrink-0">
                                        {PLANS[user.plan]?.name}
                                    </span>
                                )}
                              </div>
                              <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{user.isAnonymous ? "Guest Account" : user.email}</p>
                          </div>
                      </div>
                      <button onClick={() => setIsUserMenuOpen(prev => !prev)} title="User Options" className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors shrink-0">
                         <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M6.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM18.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" /></svg>
                      </button>
                  </div>
                   {isUserMenuOpen && (
                        <div className="absolute bottom-full left-3 right-3 mb-2 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 py-2 z-20 animate-fade-in-up">
                            <button onClick={onAccountClick} className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3">
                                <SettingsIcon /> Account Settings
                            </button>
                            <div className="my-1 border-t border-gray-100 dark:border-gray-700"></div>
                            <button onClick={onLogout} className="w-full text-left px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-3">
                                <LogOutIcon /> Log Out
                            </button>
                        </div>
                   )}
                </div>
                <div className="px-3 py-2 text-center">
                    <p className="text-[10px] text-gray-400 dark:text-gray-500">
                        Presented by <span className="font-semibold">V STORE</span>
                    </p>
                </div>
          </div>
        </div>
      </div>
    </>
  );
};

const NavItem = React.memo(({ icon, label, active = false, onClick, isComingSoon }: { icon: React.ReactNode, label: string, active?: boolean, onClick?: () => void, isComingSoon?: boolean }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-sm font-medium transition-colors group
    ${active 
        ? 'bg-white dark:bg-gray-800 text-vynto-red shadow-subtle' 
        : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200'}`}
  >
    <div className="flex items-center gap-3">
        <span className={`transition-colors ${active ? 'text-vynto-red' : 'text-gray-400 dark:text-gray-500 group-hover:text-gray-600'}`}>{icon}</span>
        {label}
    </div>
    {isComingSoon && (
        <span className="text-[9px] bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 px-1.5 py-0.5 rounded border border-gray-200 dark:border-gray-700 whitespace-nowrap opacity-80">
            Coming Soon
        </span>
    )}
  </button>
));

const HomeIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" /></svg>;
const GlobeIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 100-18 9 9 0 000 18z" /><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9h16.5M3.75 15h16.5" /></svg>;
const LibraryIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3.75V16.5L12 14.25 7.5 16.5V3.75m9 0H7.5A2.25 2.25 0 005.25 6v13.5l6.75-3.375L18.75 21V6a2.25 2.25 0 00-2.25-2.25z" /></svg>;
const SpacesIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 8.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6A2.25 2.25 0 0115.75 3.75h2.25A2.25 2.25 0 0120.25 6v2.25a2.25 2.25 0 01-2.25 2.25H15.75A2.25 2.25 0 0113.5 8.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H15.75a2.25 2.25 0 01-2.25-2.25v-2.25z" /></svg>;
const TeamIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.952a4.5 4.5 0 014.5 0m-4.5 0a4.5 4.5 0 00-4.5 0M12 12.75a4.5 4.5 0 014.5-.39m-4.5.39a4.5 4.5 0 00-4.5-.39m4.5 .39v.72a3.75 3.75 0 01-3.75 3.75H8.25a3.75 3.75 0 01-3.75-3.75v-.72M15 12.75a4.5 4.5 0 004.5-.39m-4.5 .39v.72a3.75 3.75 0 003.75 3.75h.375m-3.75-3.75a4.5 4.5 0 014.5-.39" /></svg>;
const ChartIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>;
const SettingsIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-1.007 1.11-1.226.554-.22 1.197-.22 1.752 0 .546.219 1.02.684 1.11 1.226l.094.542c.063.372.333.693.698.85l.383.182c.554.264 1.15.044 1.432-.474l.286-.532c.398-.74.982-1.292 1.724-1.605.747-.314 1.586-.245 2.268.195l.522.332c.692.44 1.152 1.168 1.152 1.944v.433c0 .842-.49 1.59-1.208 1.944l-.398.202c.37.188.644.49.7.868l-.062.433c-.09.542-.56 1.007-1.11 1.226-.554.22-1.197-.22-1.752 0-.546-.219-1.02-.684-1.11-1.226l-.094-.542c-.063-.372-.333-.693-.698-.85l-.383-.182c-.554-.264-1.15-.044-1.432.474l-.286.532c-.398.74-.982-1.292-1.724-1.605-.747.314-1.586.245-2.268-.195l-.522-.332c-.692-.44-1.152 1.168-1.152-1.944v-.433c0-.842.49 1.59 1.208 1.944l.398-.202c.37.188.644.49.7.868l.062.433zM12 15.75a3.75 3.75 0 100-7.5 3.75 3.75 0 000 7.5z" /></svg>;
const ContactIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>;
const StoreIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5A2.25 2.25 0 0011.25 11.25H4.5A2.25 2.25 0 002.25 13.5V21M6 4.5h12M6 4.5v7.5M6 4.5L12 3m0 0l6 1.5M12 3v7.5" /></svg>;
const ShieldIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" /></svg>;
const DocIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>;
const LogOutIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" /></svg>;

export default React.memo(Sidebar);