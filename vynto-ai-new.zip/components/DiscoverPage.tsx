import React from 'react';
import { ModelType } from '../types';

interface DiscoverPageProps {
  onPromptClick: (prompt: string, model: ModelType) => void;
  onMenuClick?: () => void;
}

const DiscoverPage: React.FC<DiscoverPageProps> = ({ onPromptClick, onMenuClick }) => {
  const categories = [
    {
      title: 'Writing & Creative',
      items: [
        { title: 'Write a sci-fi story', desc: 'About a robot discovering emotions.', prompt: 'Write a short sci-fi story about a robot who discovers emotions for the first time.', model: ModelType.CLAUDE },
        { title: 'Blog Post Outline', desc: 'For a travel blog about Japan.', prompt: 'Create a detailed blog post outline for a 7-day trip to Japan, focusing on culture and food.', model: ModelType.CHATGPT },
      ]
    },
    {
      title: 'Coding & Technical',
      items: [
        { title: 'React Component', desc: 'A responsive navbar with Tailwind.', prompt: 'Write a React functional component for a responsive navigation bar using Tailwind CSS.', model: ModelType.CLAUDE },
        { title: 'Python Script', desc: 'Parse CSV and plot data.', prompt: 'Write a Python script using pandas and matplotlib to read a CSV file and plot a bar chart of the "Sales" column.', model: ModelType.CLAUDE },
      ]
    },
    {
      title: 'Analysis & Logic',
      items: [
        { title: 'Explain Quantum Physics', desc: 'Like I am 5 years old.', prompt: 'Explain the basic concepts of Quantum Physics as if I were a 5-year-old.', model: ModelType.GEMINI },
        { title: 'Market Trends', desc: 'Analyze current AI trends.', prompt: 'Analyze the current trends in the Generative AI market for 2024-2025.', model: ModelType.GROK },
      ]
    }
  ];

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 animate-fade-in">
      {/* Mobile Header */}
       <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
            <button 
                onClick={onMenuClick}
                className="p-1.5 -ml-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="font-bold text-lg dark:text-white tracking-tight">Discover</div>
            <div className="w-8"></div>
       </div>

      <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
        <div className="max-w-5xl mx-auto w-full">
            <div className="mb-10">
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Discover</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1 text-sm">Explore templates and capabilities.</p>
            </div>

            <div className="space-y-12">
            {categories.map((cat, idx) => (
                <div key={idx}>
                <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-200 uppercase tracking-wide mb-4 border-b border-gray-100 dark:border-gray-800 pb-2">{cat.title}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
                    {cat.items.map((item, i) => (
                    <button 
                        key={i}
                        onClick={() => onPromptClick(item.prompt, item.model)}
                        className="text-left p-5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-gray-300 dark:hover:border-gray-600 hover:shadow-subtle transition-all group relative overflow-hidden"
                    >
                        <div className="absolute top-0 left-0 w-1 h-full bg-transparent group-hover:bg-vynto-red transition-colors"></div>
                        
                        <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold text-gray-900 dark:text-white group-hover:text-vynto-red transition-colors">{item.title}</h3>
                        <span className="text-[10px] uppercase tracking-wider text-gray-500 dark:text-gray-400 font-medium bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded border border-gray-200 dark:border-gray-600">{item.model}</span>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{item.desc}</p>
                    </button>
                    ))}
                </div>
                </div>
            ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default DiscoverPage;