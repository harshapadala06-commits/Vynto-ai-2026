import React from 'react';

interface ComingSoonModalProps {
  isOpen: boolean;
  onClose: () => void;
  featureName?: string;
}

const ComingSoonModal: React.FC<ComingSoonModalProps> = ({ isOpen, onClose, featureName }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-gray-800 w-full max-w-sm rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 p-6 flex flex-col items-center text-center animate-scale-in">
        
        <div className="w-10 h-10 bg-gray-50 dark:bg-gray-700 rounded-full flex items-center justify-center mb-4">
             <svg className="w-5 h-5 text-gray-400 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
             </svg>
        </div>

        <h2 className="text-base font-semibold text-gray-900 dark:text-white mb-2">Feature in development</h2>
        
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-6 leading-relaxed">
          The <strong className="text-gray-900 dark:text-white">{featureName || 'requested feature'}</strong> is currently under development and will be available in a future update.
        </p>
        
        <div className="w-full border-t border-gray-100 dark:border-gray-700 pt-4 mb-4">
             <p className="text-xs text-gray-400">Thank you for your patience.</p>
        </div>

        <button 
            onClick={onClose}
            className="w-full py-2 bg-gray-900 hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-200 text-white font-medium rounded-md transition-colors text-sm"
        >
            Close
        </button>
      </div>
    </div>
  );
};

export default ComingSoonModal;