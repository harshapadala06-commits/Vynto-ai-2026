import React, { useState } from 'react';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Tab = 'disclaimer' | 'privacy' | 'terms' | 'refund' | 'about';

const LegalModal: React.FC<LegalModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<Tab>('disclaimer');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-gray-900 w-full max-w-4xl h-[80vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row animate-scale-in">
        
        {/* Sidebar Tabs */}
        <div className="w-full md:w-64 bg-gray-50 dark:bg-gray-800 border-b md:border-b-0 md:border-r border-gray-200 dark:border-gray-700 flex-shrink-0 flex md:flex-col overflow-x-auto md:overflow-visible">
            <div className="p-4 md:p-6 border-b border-gray-100 dark:border-gray-700 hidden md:block">
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">Information Center</h2>
            </div>
            <div className="flex md:flex-col p-2 md:p-4 gap-2">
                <TabButton id="disclaimer" label="Disclaimer" active={activeTab} onClick={setActiveTab} />
                <TabButton id="privacy" label="Privacy Policy" active={activeTab} onClick={setActiveTab} />
                <TabButton id="terms" label="Terms & Conditions" active={activeTab} onClick={setActiveTab} />
                <TabButton id="refund" label="Refund Policy" active={activeTab} onClick={setActiveTab} />
                <TabButton id="about" label="About Us" active={activeTab} onClick={setActiveTab} />
            </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
            <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 bg-white dark:bg-gray-900 rounded-full shadow-sm border border-gray-100 dark:border-gray-700 z-10">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
            
            <div className="flex-1 overflow-y-auto p-6 md:p-10 custom-scrollbar">
                {activeTab === 'disclaimer' && <DisclaimerContent />}
                {activeTab === 'privacy' && <PrivacyContent />}
                {activeTab === 'terms' && <TermsContent />}
                {activeTab === 'refund' && <RefundContent />}
                {activeTab === 'about' && <AboutContent />}
            </div>
        </div>
      </div>
    </div>
  );
};

const TabButton = ({ id, label, active, onClick }: { id: Tab, label: string, active: Tab, onClick: (t: Tab) => void }) => (
    <button 
        onClick={() => onClick(id)}
        className={`px-4 py-2 md:py-3 rounded-lg text-sm font-medium text-left transition-colors whitespace-nowrap flex-shrink-0
        ${active === id 
            ? 'bg-white dark:bg-gray-700 text-vynto-red shadow-sm' 
            : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700/50'}`}
    >
        {label}
    </button>
);

const ExternalLinkBanner = ({ href, text }: { href: string, text: string }) => (
    <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 flex items-center justify-between group">
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">View official document</span>
        <a href={href} target="_blank" rel="noopener noreferrer" className="text-sm font-bold text-vynto-red hover:underline flex items-center gap-1">
            {text}
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 003 8.25v10.5A2.25 2.25 0 005.25 21h10.5A2.25 2.25 0 0018 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" /></svg>
        </a>
    </div>
);

const DisclaimerContent = () => (
    <div className="prose dark:prose-invert max-w-none">
        <h2 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">Disclaimer</h2>
        <ExternalLinkBanner href="https://sites.google.com/view/vyntoaipolicy/discremer" text="Open Disclaimer" />
        <div className="bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-200 dark:border-yellow-900/30 p-4 rounded-xl mb-6">
            <p className="text-yellow-800 dark:text-yellow-200 font-medium text-sm">
                Important: VYNTO AI generates content using Artificial Intelligence.
            </p>
        </div>
        <p><strong>1. Accuracy of Information</strong><br/>
        VYNTO AI utilizes third-party Large Language Models (LLMs) to generate responses. While we strive for accuracy, AI can occasionally produce incorrect, misleading, or outdated information ("hallucinations"). Users should independently verify any facts, statistics, or code generated by the platform.</p>
        
        <p className="mt-4"><strong>2. No Professional Advice</strong><br/>
        The content generated by VYNTO AI is for informational purposes only. It does not constitute professional medical, legal, financial, or engineering advice. Always consult with a qualified professional for specific advice related to your situation.</p>
        
        <p className="mt-4"><strong>3. Liability</strong><br/>
        VYNTO AI and V STORE are not liable for any damages, losses, or actions taken based on the content generated by the service. You use the generated content at your own risk.</p>
    </div>
);

const PrivacyContent = () => (
    <div className="prose dark:prose-invert max-w-none">
        <h2 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">Privacy Policy</h2>
        <ExternalLinkBanner href="https://sites.google.com/view/vyntoaipolicy/home" text="Open Privacy Policy" />
        <p className="text-sm text-gray-500 mb-6">Effective Date: October 26, 2023</p>
        
        <h3>1. Introduction</h3>
        <p>Welcome to VYNTO AI ("we," "our," or "us"), a product of V STORE. We are committed to protecting your personal information and your right to privacy.</p>

        <h3>2. Information We Collect</h3>
        <ul className="list-disc pl-5 space-y-1">
            <li><strong>Personal Information:</strong> Name, email address, username, and billing information (processed securely by Razorpay).</li>
            <li><strong>Usage Data:</strong> Information about how you interact with our services, including chat history, generated content, preferred models, and timestamps.</li>
            <li><strong>Device Data:</strong> IP address, browser type, and operating system for security and analytics purposes.</li>
        </ul>

        <h3>3. How We Use Your Information</h3>
        <p>We use your data to manage your account, process payments, generate AI content via third-party providers (like Google Gemini), and improve our platform. We do not use your personal chat data to train our own models.</p>

        <h3>4. Data Sharing</h3>
        <p>We share data only with necessary service providers (Razorpay, Supabase, Google) and for legal compliance. We do not sell your personal data.</p>
    </div>
);

const TermsContent = () => (
    <div className="prose dark:prose-invert max-w-none">
        <h2 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">Terms and Conditions</h2>
        <ExternalLinkBanner href="https://sites.google.com/view/vyntoaipolicy/terms-and-conditions" text="Open Terms & Conditions" />
        
        <h3>1. Acceptance of Terms</h3>
        <p>By accessing or using VYNTO AI, you agree to be bound by these Terms. If you disagree, you may not access the service.</p>

        <h3>2. Accounts & Subscriptions</h3>
        <p>You are responsible for maintaining the security of your account. Paid plans are billed securely via Razorpay. By upgrading, you authorize recurring charges as per your selected plan.</p>

        <h3>3. Acceptable Use</h3>
        <p>You agree not to generate illegal, harmful, or abusive content, or to reverse engineer the platform.</p>

        <h3>4. AI-Generated Content</h3>
        <p>You retain ownership of the content you generate, subject to the terms of the underlying AI model providers. We do not guarantee the uniqueness of generated content.</p>

        <h3>5. Governing Law</h3>
        <p>These terms are governed by the laws of India. Disputes are subject to the jurisdiction of Nizamabad, Telangana.</p>
    </div>
);

const RefundContent = () => (
    <div className="prose dark:prose-invert max-w-none">
        <h2 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">Refund & Cancellation Policy</h2>
        <ExternalLinkBanner href="https://sites.google.com/view/vyntoaipolicy/refund-policy" text="Open Refund Policy" />
        
        <h3>1. Cancellation</h3>
        <p>You may cancel your VYNTO AI subscription at any time via your Account Settings. Access continues until the end of the current billing cycle.</p>

        <h3>2. Refunds</h3>
        <p><strong>No Refunds:</strong> Payments for subscription plans are generally non-refundable. We do not provide refunds or credits for partially used subscription periods.</p>
        <p><strong>Exceptions:</strong> In the event of a technical error (e.g., double charge), please contact <strong>vynto@vstoreonline.in</strong> within 7 days for a review.</p>
    </div>
);

const AboutContent = () => (
    <div className="prose dark:prose-invert max-w-none">
        <h2 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">About Us</h2>
        <ExternalLinkBanner href="https://sites.google.com/view/vyntoaipolicy/about-us" text="View About Us Page" />
        
        <div className="mb-6">
            <p><strong>VYNTO AI</strong> is a cutting-edge AI workspace designed to bring enterprise-grade artificial intelligence to professionals, creators, and students.</p>
            <p>We believe that accessing powerful AI models shouldn't require complex setups or multiple subscriptions. VYNTO AI aggregates top-tier models (like Google Gemini, Claude, and GPT) into a single, intuitive interface inspired by answer-first search engines.</p>
        </div>

        <h3>Powered by V STORE</h3>
        <p>VYNTO AI is proudly developed and managed by <strong>V STORE</strong>, an e-commerce and digital solutions brand based in India.</p>

        <h3>Our Mission</h3>
        <p>To democratize access to advanced AI tools and enhance productivity for everyone, everywhere.</p>

        <h3>Headquarters</h3>
        <p>
            V STORE / VYNTO AI<br/>
            Nizamabad, Telangana, India.<br/>
            Email: vynto@vstoreonline.in
        </p>
    </div>
);

export default LegalModal;