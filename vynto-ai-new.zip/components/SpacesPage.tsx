import React, { useState } from 'react';

interface SpacesPageProps {
  onMenuClick?: () => void;
}

const SpacesPage: React.FC<SpacesPageProps> = ({ onMenuClick }) => {
  const [spaces, setSpaces] = useState([
      { id: '1', name: 'General', icon: '🌍', desc: 'Default workspace' },
      { id: '2', name: 'Marketing', icon: '📈', desc: 'Campaign strategies' },
      { id: '3', name: 'Engineering', icon: '💻', desc: 'Code and docs' }
  ]);
  const [isCreating, setIsCreating] = useState(false);
  const [newSpaceName, setNewSpaceName] = useState('');

  const handleCreate = () => {
      if (!newSpaceName.trim()) return;
      const newSpace = {
          id: Date.now().toString(),
          name: newSpaceName,
          icon: '📁',
          desc: 'New workspace'
      };
      setSpaces([...spaces, newSpace]);
      setNewSpaceName('');
      setIsCreating(false);
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 animate-fade-in">
       {/* Mobile Header */}
       <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
            <button 
                onClick={onMenuClick}
                className="p-1.5 -ml-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="font-bold text-lg dark:text-white tracking-tight">Spaces</div>
            <div className="w-8"></div>
       </div>

       <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
            <div className="max-w-5xl mx-auto w-full">
                <div className="text-center mb-10">
                    <div className="w-20 h-20 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center mb-6 mx-auto">
                        <svg className="w-10 h-10 text-vynto-red" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Workspace Spaces</h1>
                    <p className="text-gray-500 dark:text-gray-400 max-w-md mx-auto">Organize your chats, documents, and agents into dedicated spaces for different projects or teams.</p>
                </div>
                
                <div className="flex justify-center mb-12">
                    {isCreating ? (
                        <div className="flex gap-2 animate-fade-in">
                            <input 
                                autoFocus
                                type="text" 
                                value={newSpaceName}
                                onChange={(e) => setNewSpaceName(e.target.value)}
                                placeholder="Space Name"
                                className="border border-gray-300 dark:border-gray-700 rounded-lg px-4 py-2 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-vynto-red"
                                onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                            />
                            <button onClick={handleCreate} className="px-4 py-2 bg-vynto-red text-white rounded-lg hover:bg-vynto-hover">Save</button>
                            <button onClick={() => setIsCreating(false)} className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600">Cancel</button>
                        </div>
                    ) : (
                        <button 
                            onClick={() => setIsCreating(true)}
                            className="px-6 py-3 bg-vynto-red text-white font-medium rounded-lg shadow-lg hover:bg-vynto-hover transition-all flex items-center gap-2"
                        >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                            Create New Space
                        </button>
                    )}
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 w-full">
                    {spaces.map((space) => (
                        <div key={space.id} className="p-6 border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 hover:shadow-lg hover:border-vynto-red dark:hover:border-vynto-red transition-all cursor-pointer group">
                            <div className="flex items-start justify-between mb-4">
                                <div className="w-10 h-10 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-xl">
                                    {space.icon}
                                </div>
                                <button className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2m0 7a1 1 0 110-2 1 1 0 010 2m0 7a1 1 0 110-2 1 1 0 010 2" /></svg>
                                </button>
                            </div>
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">{space.name}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{space.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
       </div>
    </div>
  );
};

export default SpacesPage;