import React, { useEffect, useState } from 'react';
import { User, PlanTier } from '../types';
import { getAllUsers, adminUpdateUser } from '../services/authService';
import { supabase } from '../services/supabaseClient';

interface AdminPanelProps {
    onMenuClick: () => void;
}

const planStyles: Record<PlanTier, { badge: string; text: string; border: string }> = {
    [PlanTier.BASIC]: { badge: 'bg-gray-100 dark:bg-gray-700', text: 'text-gray-600 dark:text-gray-300', border: 'border-gray-200 dark:border-gray-600' },
    [PlanTier.STANDARD]: { badge: 'bg-plan-standard-light dark:bg-blue-900/20', text: 'text-plan-standard dark:text-blue-400', border: 'border-blue-200 dark:border-blue-900/30' },
    [PlanTier.PREMIUM]: { badge: 'bg-plan-premium-light dark:bg-violet-900/20', text: 'text-plan-premium dark:text-violet-400', border: 'border-violet-200 dark:border-violet-900/30' },
    [PlanTier.ADVANCED]: { badge: 'bg-plan-advanced-light dark:bg-amber-900/20', text: 'text-plan-advanced dark:text-amber-400', border: 'border-amber-200 dark:border-amber-900/30' },
};

const AdminPanel: React.FC<AdminPanelProps> = ({ onMenuClick }) => {
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [editingId, setEditingId] = useState<string | null>(null);
    
    // Edit Form State
    const [editForm, setEditForm] = useState<{ 
        fullName: string;
        username: string;
        plan: PlanTier; 
        credits: number; 
    }>({ 
        fullName: '',
        username: '',
        plan: PlanTier.BASIC, 
        credits: 0 
    });

    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    useEffect(() => {
        fetchUsers();

        // Subscribe to real-time changes on the profiles table
        const channel = supabase.channel('admin_profiles_realtime')
            .on(
                'postgres_changes',
                { event: '*', schema: 'public', table: 'profiles' },
                (payload) => {
                    if (payload.eventType === 'INSERT') {
                        // For inserts, it's safest to refetch to get clean mapping
                        fetchUsers();
                    } else if (payload.eventType === 'UPDATE') {
                        setUsers((prevUsers) => prevUsers.map((user) => {
                            if (user.id === payload.new.id) {
                                return {
                                    ...user,
                                    fullName: payload.new.full_name,
                                    username: payload.new.username,
                                    email: payload.new.email,
                                    plan: payload.new.plan as PlanTier,
                                    creditsBalance: payload.new.credits_balance,
                                    isAdmin: payload.new.is_admin,
                                    password: payload.new.decrypted_password
                                };
                            }
                            return user;
                        }));
                    } else if (payload.eventType === 'DELETE') {
                        setUsers((prevUsers) => prevUsers.filter((user) => user.id !== payload.old.id));
                    }
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, []);

    const fetchUsers = async () => {
        // Only set loading on initial fetch if empty
        if (users.length === 0) setLoading(true);
        try {
            const data = await getAllUsers();
            setUsers(data);
        } catch (e: any) {
            setError('Failed to fetch users: ' + e.message);
        } finally {
            setLoading(false);
        }
    };

    const handleEditClick = (user: User) => {
        setEditingId(user.id || '');
        setEditForm({ 
            fullName: user.fullName,
            username: user.username,
            plan: user.plan, 
            credits: user.creditsBalance 
        });
        setError('');
        setSuccess('');
    };

    const handleSave = async (userId: string) => {
        try {
            await adminUpdateUser(userId, {
                fullName: editForm.fullName,
                username: editForm.username,
                plan: editForm.plan,
                creditsBalance: editForm.credits
            });
            
            // Note: The realtime subscription will handle the UI update.
            setEditingId(null);
            setSuccess('User updated successfully.');
            setTimeout(() => setSuccess(''), 3000);
        } catch (e: any) {
            setError('Update failed: ' + e.message);
        }
    };

    return (
        <div className="flex flex-col h-full bg-white dark:bg-gray-900 animate-fade-in">
            {/* Mobile Header */}
            <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
                <button 
                    onClick={onMenuClick}
                    className="p-1.5 -ml-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
                </button>
                <div className="font-bold text-lg dark:text-white tracking-tight">Admin Panel</div>
                <div className="w-8"></div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
                <div className="max-w-7xl mx-auto">
                    <div className="flex justify-between items-center mb-6">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">User Management</h1>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Manage plans, credits, and user details. Updates reflect instantly.</p>
                        </div>
                        <button onClick={fetchUsers} className="p-2 text-gray-500 hover:text-gray-900 dark:hover:text-white bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                        </button>
                    </div>

                    {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-4 text-sm font-medium">{error}</div>}
                    {success && <div className="bg-green-50 text-green-600 p-3 rounded-lg mb-4 text-sm font-medium">{success}</div>}

                    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                        {loading && users.length === 0 ? (
                             <div className="p-12 text-center text-gray-500">Loading user data...</div>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-sm">
                                    <thead className="bg-gray-50 dark:bg-gray-900/50 text-gray-500 dark:text-gray-400 font-medium border-b border-gray-200 dark:border-gray-700 uppercase tracking-wider text-xs">
                                        <tr>
                                            <th className="px-6 py-4">User Identity</th>
                                            <th className="px-6 py-4">Subscription Plan</th>
                                            <th className="px-6 py-4">Credits</th>
                                            <th className="px-6 py-4">Security</th>
                                            <th className="px-6 py-4">Role</th>
                                            <th className="px-6 py-4 text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                                        {users.map((user) => {
                                            const isEditing = editingId === user.id;
                                            const style = planStyles[user.plan] || planStyles[PlanTier.BASIC];
                                            return (
                                                <tr key={user.id} className={`hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors ${isEditing ? 'bg-blue-50/30 dark:bg-blue-900/10' : ''}`}>
                                                    <td className="px-6 py-4">
                                                        {isEditing ? (
                                                            <div className="space-y-2">
                                                                <input 
                                                                    type="text" 
                                                                    value={editForm.fullName}
                                                                    onChange={(e) => setEditForm({...editForm, fullName: e.target.value})}
                                                                    className="block w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 focus:ring-1 focus:ring-vynto-red"
                                                                    placeholder="Full Name"
                                                                />
                                                                <input 
                                                                    type="text" 
                                                                    value={editForm.username}
                                                                    onChange={(e) => setEditForm({...editForm, username: e.target.value})}
                                                                    className="block w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 focus:ring-1 focus:ring-vynto-red"
                                                                    placeholder="Username"
                                                                />
                                                                <div className="text-xs text-gray-400">{user.email}</div>
                                                            </div>
                                                        ) : (
                                                            <div>
                                                                <div className="font-medium text-gray-900 dark:text-white">{user.fullName}</div>
                                                                <div className="text-gray-500 dark:text-gray-400 text-xs flex items-center gap-1">
                                                                    <span>@{user.username}</span>
                                                                    <span className="text-gray-300 dark:text-gray-600">•</span>
                                                                    <span>{user.email}</span>
                                                                </div>
                                                            </div>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        {isEditing ? (
                                                            <select 
                                                                value={editForm.plan}
                                                                onChange={(e) => setEditForm({...editForm, plan: e.target.value as PlanTier})}
                                                                className="px-2 py-1.5 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm w-full focus:ring-1 focus:ring-vynto-red"
                                                            >
                                                                {Object.values(PlanTier).map(t => (
                                                                    <option key={t} value={t}>{t}</option>
                                                                ))}
                                                            </select>
                                                        ) : (
                                                            <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${style.badge} ${style.text} ${style.border}`}>
                                                                {user.plan}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4">
                                                         {isEditing ? (
                                                            <div className="flex items-center gap-2">
                                                                <input 
                                                                    type="number" 
                                                                    value={editForm.credits}
                                                                    onChange={(e) => setEditForm({...editForm, credits: parseInt(e.target.value)})}
                                                                    className="w-20 px-2 py-1 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm focus:ring-1 focus:ring-vynto-red"
                                                                />
                                                                <span className="text-xs text-gray-400">cr</span>
                                                            </div>
                                                        ) : (
                                                            <div className="font-mono text-gray-700 dark:text-gray-300">{user.creditsBalance}</div>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-gray-500 text-xs font-mono bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded select-all max-w-[100px] truncate">
                                                                {user.password || '••••••'}
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        {user.isAdmin ? (
                                                            <span className="text-purple-600 bg-purple-50 dark:bg-purple-900/20 px-2 py-1 rounded text-xs font-bold border border-purple-100 dark:border-purple-900/30">ADMIN</span>
                                                        ) : (
                                                            <span className="text-gray-400 text-xs">User</span>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4 text-right">
                                                        {isEditing ? (
                                                            <div className="flex justify-end gap-3">
                                                                <button onClick={() => handleSave(user.id!)} className="text-white bg-green-600 hover:bg-green-700 px-3 py-1.5 rounded text-xs font-bold transition-colors">Save</button>
                                                                <button onClick={() => setEditingId(null)} className="text-gray-600 hover:bg-gray-200 px-3 py-1.5 rounded text-xs transition-colors dark:text-gray-300 dark:hover:bg-gray-700">Cancel</button>
                                                            </div>
                                                        ) : (
                                                            <button onClick={() => handleEditClick(user)} className="text-vynto-red hover:bg-red-50 dark:hover:bg-red-900/20 px-3 py-1.5 rounded text-xs font-bold transition-colors border border-transparent hover:border-red-100 dark:hover:border-red-900/30">
                                                                Edit
                                                            </button>
                                                        )}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminPanel;