import React, { useEffect, useState } from 'react';
import { User, PlanTier, AccountStatus } from '../types';
import { getAllUsers, adminUpdateUser } from '../services/authService';
import { supabase } from '../services/supabaseClient';

interface AdminPanelProps {
    onMenuClick: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onMenuClick }) => {
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    
    // Edit State
    const [editingUser, setEditingUser] = useState<User | null>(null);
    const [formState, setFormState] = useState<{ 
        plan: PlanTier; 
        credits: number; 
        status: AccountStatus 
    }>({ 
        plan: PlanTier.BASIC, 
        credits: 0,
        status: 'Active'
    });

    const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

    useEffect(() => {
        fetchUsers();
        // Subscribe to real-time changes
        const channel = supabase.channel('admin_dashboard')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => {
                fetchUsers(); 
            })
            .subscribe();

        return () => { supabase.removeChannel(channel); };
    }, []);

    const fetchUsers = async () => {
        try {
            const data = await getAllUsers();
            setUsers(data);
            setLoading(false);
        } catch (e: any) {
            console.error(e);
            setMessage({ text: 'Failed to fetch users', type: 'error' });
        }
    };

    const handleEditClick = (user: User) => {
        setEditingUser(user);
        setFormState({
            plan: user.plan,
            credits: user.creditsBalance,
            status: user.accountStatus
        });
        setMessage(null);
    };

    const handleSave = async () => {
        if (!editingUser || !editingUser.id) return;
        
        try {
            await adminUpdateUser(editingUser.id, {
                plan: formState.plan,
                creditsBalance: formState.credits,
                accountStatus: formState.status
            });
            setMessage({ text: 'User updated successfully', type: 'success' });
            setEditingUser(null);
        } catch (e: any) {
            setMessage({ text: 'Update failed: ' + e.message, type: 'error' });
        }
    };

    const filteredUsers = users.filter(u => 
        u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || 
        u.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Stats
    const totalUsers = users.length;
    const activeUsers = users.filter(u => u.accountStatus === 'Active').length;
    const premiumUsers = users.filter(u => u.plan !== PlanTier.BASIC).length;

    return (
        <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900 animate-fade-in font-sans">
            {/* Mobile Header */}
            <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 sticky top-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur z-20 pt-safe-top">
                <button onClick={onMenuClick} className="p-2 -ml-2 text-gray-600 dark:text-gray-300">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
                </button>
                <div className="font-bold text-lg dark:text-white">Admin Control</div>
                <div className="w-8"></div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-8">
                <div className="max-w-7xl mx-auto">
                    {/* Header */}
                    <div className="mb-8">
                        <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Admin Dashboard</h1>
                        <p className="text-gray-500 dark:text-gray-400 mt-1">Manage users, subscriptions, and system status.</p>
                    </div>

                    {/* Stats Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Users</p>
                                <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">{totalUsers}</p>
                            </div>
                            <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex items-center justify-center text-blue-600 dark:text-blue-400">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" /></svg>
                            </div>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Status</p>
                                <p className="text-3xl font-bold text-green-600 dark:text-green-400 mt-1">{activeUsers}</p>
                            </div>
                            <div className="w-12 h-12 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-center justify-center text-green-600 dark:text-green-400">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            </div>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Paid Subscribers</p>
                                <p className="text-3xl font-bold text-vynto-red mt-1">{premiumUsers}</p>
                            </div>
                            <div className="w-12 h-12 bg-red-50 dark:bg-red-900/20 rounded-lg flex items-center justify-center text-vynto-red">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
                        {/* Filters */}
                        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row justify-between gap-4 bg-gray-50/50 dark:bg-gray-900/20">
                            <div className="relative flex-1 max-w-md">
                                <input 
                                    type="text" 
                                    placeholder="Search by name or email..." 
                                    value={searchTerm}
                                    onChange={e => setSearchTerm(e.target.value)}
                                    className="w-full pl-9 pr-4 py-2 border border-gray-200 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-vynto-red focus:outline-none"
                                />
                                <svg className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                            </div>
                            <button onClick={fetchUsers} className="flex items-center gap-2 px-4 py-2 text-sm text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg transition-colors">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                                Refresh
                            </button>
                        </div>

                        {message && (
                            <div className={`p-4 ${message.type === 'success' ? 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400' : 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400'} flex justify-between`}>
                                <span>{message.text}</span>
                                <button onClick={() => setMessage(null)}>&times;</button>
                            </div>
                        )}

                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="bg-gray-50 dark:bg-gray-900/50 text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 font-semibold border-b border-gray-200 dark:border-gray-700">
                                        <th className="px-6 py-4">User Details</th>
                                        <th className="px-6 py-4">Plan Tier</th>
                                        <th className="px-6 py-4">Credits</th>
                                        <th className="px-6 py-4">Account Status</th>
                                        <th className="px-6 py-4 text-right">Controls</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                                    {loading ? (
                                        <tr><td colSpan={5} className="px-6 py-12 text-center text-gray-500">Loading users...</td></tr>
                                    ) : filteredUsers.length === 0 ? (
                                        <tr><td colSpan={5} className="px-6 py-12 text-center text-gray-500">No users found matching your search.</td></tr>
                                    ) : (
                                        filteredUsers.map(user => {
                                            const isEditing = editingUser?.id === user.id;
                                            
                                            return (
                                                <tr key={user.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors ${isEditing ? 'bg-blue-50/50 dark:bg-blue-900/10' : ''}`}>
                                                    <td className="px-6 py-4">
                                                        <div className="flex flex-col">
                                                            <span className="font-semibold text-gray-900 dark:text-white">{user.fullName}</span>
                                                            <span className="text-xs text-gray-500 dark:text-gray-400">{user.email}</span>
                                                            <span className="text-[10px] text-gray-400 mt-0.5">{user.id}</span>
                                                            {user.password && <span className="text-[10px] text-gray-400 mt-0.5 font-mono">Pwd: {user.password}</span>}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        {isEditing ? (
                                                            <select 
                                                                value={formState.plan}
                                                                onChange={(e) => setFormState({...formState, plan: e.target.value as PlanTier})}
                                                                className="w-full text-sm border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 py-1"
                                                            >
                                                                {Object.values(PlanTier).map(p => <option key={p} value={p}>{p}</option>)}
                                                            </select>
                                                        ) : (
                                                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                                                ${user.plan === PlanTier.BASIC ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' : 
                                                                  user.plan === PlanTier.STANDARD ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' :
                                                                  user.plan === PlanTier.PREMIUM ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300' :
                                                                  'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'}`}>
                                                                {user.plan}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        {isEditing ? (
                                                            <input 
                                                                type="number" 
                                                                value={formState.credits} 
                                                                onChange={(e) => setFormState({...formState, credits: parseInt(e.target.value) || 0})}
                                                                className="w-20 text-sm border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 py-1 px-2"
                                                            />
                                                        ) : (
                                                            <span className="font-mono text-gray-700 dark:text-gray-300 font-bold">{user.creditsBalance}</span>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        {isEditing ? (
                                                            <select 
                                                                value={formState.status}
                                                                onChange={(e) => setFormState({...formState, status: e.target.value as AccountStatus})}
                                                                className="w-28 text-sm border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 py-1"
                                                            >
                                                                <option value="Active">Active</option>
                                                                <option value="Blocked">Blocked</option>
                                                            </select>
                                                        ) : (
                                                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${user.accountStatus === 'Active' ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-900/30' : 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-900/30'}`}>
                                                                <span className={`w-1.5 h-1.5 rounded-full ${user.accountStatus === 'Active' ? 'bg-green-500' : 'bg-red-500'}`}></span>
                                                                {user.accountStatus}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="px-6 py-4 text-right">
                                                        {isEditing ? (
                                                            <div className="flex items-center justify-end gap-2">
                                                                <button onClick={handleSave} className="p-1.5 bg-green-600 text-white rounded hover:bg-green-700 transition-colors shadow-sm" title="Save Changes">
                                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>
                                                                </button>
                                                                <button onClick={() => setEditingUser(null)} className="p-1.5 bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300 rounded hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors" title="Cancel">
                                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                                                                </button>
                                                            </div>
                                                        ) : (
                                                            <button 
                                                                onClick={() => handleEditClick(user)}
                                                                className="text-sm font-medium text-vynto-red hover:text-red-700 dark:hover:text-red-400 transition-colors flex items-center justify-end gap-1 ml-auto"
                                                            >
                                                                <span>Edit</span>
                                                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                                                            </button>
                                                        )}
                                                    </td>
                                                </tr>
                                            );
                                        })
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminPanel;