import React from 'react';

interface ServicesPageProps {
  onMenuClick?: () => void;
}

const ServicesPage: React.FC<ServicesPageProps> = ({ onMenuClick }) => {
  const services = [
    {
      title: "Ebooks",
      desc: "Get our pre-launch offer book for only ₹99. Master new skills today.",
      link: "https://ebooks.vstoreonline.in/",
      color: "bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400",
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
      )
    },
    {
      title: "Promail",
      desc: "Get our professional email solutions at the lowest cost in the market.",
      link: "https://promail.vstoreonline.in/",
      color: "bg-purple-50 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400",
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
      )
    },
    {
      title: "V Store",
      desc: "Visit our e-commerce website for quality products and exclusive discounts.",
      link: "https://www.vstoreonline.in/",
      color: "bg-vynto-light text-vynto-red dark:bg-red-900/20 dark:text-red-400",
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
      )
    }
  ];

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 animate-fade-in">
       {/* Mobile Header */}
       <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
            <button 
                onClick={onMenuClick}
                className="p-1.5 -ml-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="font-bold text-lg dark:text-white tracking-tight">Services</div>
            <div className="w-8"></div>
       </div>

       <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
            <div className="max-w-5xl mx-auto w-full">
                <div className="text-center mb-12">
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">More from V Store</h1>
                    <p className="text-gray-500 dark:text-gray-400">Discover our ecosystem of professional tools and services.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                    {services.map((service, idx) => (
                        <a 
                            key={idx} 
                            href={service.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex flex-col p-6 bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all group"
                        >
                            <div className={`w-14 h-14 ${service.color} rounded-xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110`}>
                                {service.icon}
                            </div>
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{service.title}</h3>
                            <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed mb-6 flex-1">
                                {service.desc}
                            </p>
                            <div className="flex items-center text-sm font-semibold text-gray-900 dark:text-white group-hover:text-vynto-red transition-colors">
                                Explore
                                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                            </div>
                        </a>
                    ))}
                </div>

                {/* Google Review Section */}
                <div className="bg-gradient-to-r from-gray-900 to-gray-800 dark:from-gray-800 dark:to-gray-700 rounded-3xl p-8 md:p-12 text-center text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-white opacity-5 rounded-full blur-3xl"></div>
                    <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-40 h-40 bg-vynto-red opacity-20 rounded-full blur-3xl"></div>
                    
                    <div className="relative z-10">
                        <div className="flex justify-center mb-4">
                            <div className="flex gap-1 text-yellow-400">
                                {[1,2,3,4,5].map(i => (
                                    <svg key={i} className="w-6 h-6 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                                ))}
                            </div>
                        </div>
                        <h2 className="text-2xl md:text-3xl font-bold mb-4">Love VYNTO AI?</h2>
                        <p className="text-gray-300 mb-8 max-w-xl mx-auto">Review our business on Google Business Profile and get exclusive discounts on V Store products as a token of our appreciation.</p>
                        <a 
                            href="https://share.google/Qea310EaJUozscWHj" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center px-8 py-3 bg-white text-gray-900 rounded-xl font-bold hover:bg-gray-100 transition-colors shadow-lg"
                        >
                            Write a Review
                        </a>
                    </div>
                </div>
            </div>
       </div>
    </div>
  );
};

export default ServicesPage;