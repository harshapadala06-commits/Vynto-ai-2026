import React, { useState } from 'react';
import { User, PlanTier } from '../types';
import { PLANS } from '../constants';

interface AccountPageProps {
  user: User;
  onLogout: () => void;
  onUpgradeClick: () => void;
  onUpdateUser: (details: { fullName: string; username: string }) => void;
  onDeleteAccount: () => void;
}

const StatCard: React.FC<{ label: string, value: string | number, color: string, icon: React.ReactNode }> = ({ label, value, color, icon }) => (
    <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-xl border border-gray-100 dark:border-gray-700/50 flex items-center gap-4">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color.replace('text-', 'bg-').replace('-600', '-50').replace('-500', '-50')} dark:bg-opacity-10`}>
            <div className={`w-5 h-5 ${color}`}>{icon}</div>
        </div>
        <div>
            <p className="text-xs text-gray-500 dark:text-gray-400 font-medium uppercase tracking-wider">{label}</p>
            <p className={`text-2xl font-bold ${color} mt-1`}>{value}</p>
        </div>
    </div>
);

const AccountPage: React.FC<AccountPageProps> = ({ user, onLogout, onUpgradeClick, onUpdateUser, onDeleteAccount }) => {
  const plan = PLANS[user.plan];
  const [isEditing, setIsEditing] = useState(false);
  const [fullName, setFullName] = useState(user.fullName);
  const [username, setUsername] = useState(user.username);

  const handleSave = () => {
    onUpdateUser({ fullName, username });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFullName(user.fullName);
    setUsername(user.username);
    setIsEditing(false);
  };

  return (
    <div className="animate-fade-in">
      <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-3xl font-medium text-gray-900 dark:text-white">Account</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2">Manage your account details and subscription.</p>
          </div>
          <button 
            onClick={onLogout}
            className="px-4 py-2 text-sm font-medium text-gray-600 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
           >
            Log Out
          </button>
      </div>

      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Profile</h3>
      <div className="bg-white dark:bg-gray-800/50 p-6 rounded-xl border border-gray-100 dark:border-gray-700/50 shadow-sm mb-8">
        {!isEditing ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-vynto-light dark:bg-red-900/20 rounded-full flex items-center justify-center text-vynto-red text-2xl font-bold">
                      {user.fullName.charAt(0)}
                  </div>
                  <div>
                      <h2 className="text-xl font-bold text-gray-900 dark:text-white">{user.fullName}</h2>
                      <p className="text-gray-500 dark:text-gray-400">{user.isAnonymous ? "Guest Account" : user.email}</p>
                      {!user.isAnonymous && <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">Username: @{user.username}</p>}
                  </div>
              </div>
              {!user.isAnonymous && (
                <button onClick={() => setIsEditing(true)} className="px-4 py-2 text-sm font-medium text-gray-600 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">Edit Profile</button>
              )}
            </div>
        ) : (
            <div className="space-y-4 animate-fade-in">
                <div>
                    <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Full Name</label>
                    <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} className="w-full mt-1 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-vynto-red" />
                </div>
                 <div>
                    <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Username</label>
                    <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full mt-1 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-vynto-red" />
                </div>
                <div className="flex justify-end gap-3 pt-2">
                    <button onClick={handleCancel} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">Cancel</button>
                    <button onClick={handleSave} className="px-4 py-2 text-sm font-medium text-white bg-vynto-red rounded-lg hover:bg-vynto-hover transition-colors">Save Changes</button>
                </div>
            </div>
        )}
      </div>
      
      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Subscription</h3>

      <div className="border border-gray-200 dark:border-gray-700 rounded-xl p-6 mb-8">
         <div className="flex justify-between items-start mb-6">
            <div>
                <p className="text-gray-900 dark:text-white font-bold text-xl">{plan.name} Plan</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{user.isAnonymous ? "You are currently on a guest plan." : "Your current subscription details."}</p>
            </div>
            <button 
                onClick={onUpgradeClick}
                className="bg-vynto-red text-white font-semibold px-5 py-2.5 rounded-lg text-sm hover:bg-vynto-hover transition-colors"
            >
                {user.isAnonymous ? 'Sign Up & Upgrade' : 'Upgrade Plan'}
            </button>
         </div>
         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <StatCard 
                label={user.isAnonymous ? "Messages Remaining" : "Credits"} 
                value={user.creditsBalance} 
                color="text-vynto-red" 
                icon={<svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M9 9.563V9a3 3 0 013-3v0a3 3 0 013 3v.563M9 18v-3.375a3 3 0 013-3v0a3 3 0 013 3V18" /></svg>}
            />
            <StatCard 
                label="Account Status" 
                value={user.accountStatus} 
                color="text-green-500"
                icon={<svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            />
         </div>
      </div>

      {!user.isAnonymous && (
          <>
            <h3 className="text-lg font-medium text-red-600 dark:text-red-500 mb-4 mt-8">Danger Zone</h3>
            <div className="border border-red-200 dark:border-red-500/30 rounded-xl p-6 bg-red-50/50 dark:bg-red-900/10">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                    <div className="flex-1 mb-4 sm:mb-0">
                        <p className="font-bold text-gray-900 dark:text-white">Delete Account</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md">Once you request deletion, there is no going back. Please be certain.</p>
                        <div className="mt-2 text-xs text-red-600/90 dark:text-red-400/80 space-y-0.5">
                            <p>• Your account and data will be permanently deleted after processing.</p>
                            <p>• This action cannot be undone.</p>
                        </div>
                    </div>
                    <button onClick={onDeleteAccount} className="bg-red-600 text-white font-semibold px-5 py-2.5 rounded-lg text-sm hover:bg-red-700 transition-colors whitespace-nowrap self-start sm:self-center">Request Deletion</button>
                </div>
            </div>
          </>
      )}

    </div>
  );
};

export default AccountPage;