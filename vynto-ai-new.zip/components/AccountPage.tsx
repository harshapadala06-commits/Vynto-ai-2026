import React, { useState } from 'react';
import { User, PlanTier } from '../types';
import { PLANS } from '../constants';

interface AccountPageProps {
  user: User;
  onLogout: () => void;
  onUpgradeClick: () => void;
  onUpdateUser: (details: { fullName: string; username: string }) => void;
  onDeleteAccount: () => void;
  onContactClick: () => void;
}

const InfinityIcon = () => (
    <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.23 0l-4.58-2.64a6 6 0 010-10.46l4.58-2.64a6 6 0 015.23 0l4.58 2.64a6 6 0 010 10.46l-4.58 2.64z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.23 0l-4.58-2.64a6 6 0 010-10.46l4.58-2.64a6 6 0 015.23 0l4.58 2.64a6 6 0 010 10.46l-4.58 2.64z" transform="translate(0, 0)"/>
    </svg>
);
const CreditIcon = () => <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5 0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m16.5 0v3.75m-16.5-3.75v3.75m16.5 0v3.75C20.25 16.153 16.556 18 12 18s-8.25-1.847-8.25-4.125v-3.75m16.5 0c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125" /></svg>

const StatCard: React.FC<{ label: string, value: string | number, color: string, icon: React.ReactNode }> = ({ label, value, color, icon }) => (
    <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center gap-5">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color.replace('text-', 'bg-').replace('-600', '-50').replace('-500', '-50')} dark:bg-opacity-10`}>
            <div className={`w-6 h-6 ${color}`}>{icon}</div>
        </div>
        <div>
            <p className="text-xs text-gray-500 dark:text-gray-400 font-semibold uppercase tracking-wider mb-1">{label}</p>
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
        </div>
    </div>
);

const AccountPage: React.FC<AccountPageProps> = ({ user, onLogout, onUpgradeClick, onUpdateUser, onDeleteAccount, onContactClick }) => {
  const plan = PLANS[user.plan];
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ fullName: user.fullName, username: user.username });
  const [loading, setLoading] = useState(false);
  
  const isBasic = user.plan === PlanTier.BASIC;

  // Determine next plan for upgrade motivation
  const planOrder = [PlanTier.BASIC, PlanTier.STANDARD, PlanTier.PREMIUM, PlanTier.ADVANCED];
  const currentPlanIndex = planOrder.indexOf(user.plan);
  const nextPlanTier = currentPlanIndex >= 0 && currentPlanIndex < planOrder.length - 1 
      ? planOrder[currentPlanIndex + 1] 
      : null;
  const nextPlan = nextPlanTier ? PLANS[nextPlanTier] : null;

  const handleSave = async () => {
    setLoading(true);
    try {
        await onUpdateUser(formData);
        setIsEditing(false);
    } catch(e) {
        // Error handled in App.tsx
    } finally {
        setLoading(false);
    }
  };

  const handleCancel = () => {
    setFormData({ fullName: user.fullName, username: user.username });
    setIsEditing(false);
  };

  return (
    <div className="animate-fade-in max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">Account Settings</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">Manage your profile and subscription preferences.</p>
          </div>
          <button 
            onClick={onLogout}
            className="px-4 py-2.5 text-sm font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 rounded-xl hover:bg-red-100 dark:hover:bg-red-900/20 transition-colors flex items-center gap-2 self-start md:self-auto"
           >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" /></svg>
            Log Out
          </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden mb-8">
        <div className="p-6 md:p-8">
            <div className="flex items-start justify-between mb-6">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Profile Details</h3>
                {!user.isAnonymous && !isEditing && (
                    <button onClick={() => setIsEditing(true)} className="text-sm font-medium text-vynto-red hover:text-red-700 dark:hover:text-red-400 transition-colors">Edit Profile</button>
                )}
            </div>

            <div className="flex flex-col md:flex-row gap-8 items-start">
                 <div className="flex-shrink-0">
                    <div className="w-24 h-24 bg-gradient-to-br from-vynto-red to-orange-500 rounded-2xl flex items-center justify-center text-white text-4xl font-bold shadow-lg">
                        {user.fullName.charAt(0)}
                    </div>
                 </div>

                 <div className="flex-1 w-full space-y-6">
                    {isEditing ? (
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
                            <div>
                                <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Full Name</label>
                                <input 
                                    type="text" 
                                    value={formData.fullName} 
                                    onChange={e => setFormData({...formData, fullName: e.target.value})} 
                                    className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700/50 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-vynto-red transition-all"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Username</label>
                                <input 
                                    type="text" 
                                    value={formData.username} 
                                    onChange={e => setFormData({...formData, username: e.target.value})} 
                                    className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700/50 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-vynto-red transition-all"
                                />
                            </div>
                         </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <p className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-1">Full Name</p>
                                <p className="text-lg font-medium text-gray-900 dark:text-white">{user.fullName}</p>
                            </div>
                            <div>
                                <p className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-1">Username</p>
                                <p className="text-lg font-medium text-gray-900 dark:text-white">@{user.username}</p>
                            </div>
                             <div>
                                <p className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-1">Email</p>
                                <p className="text-lg font-medium text-gray-900 dark:text-white">{user.isAnonymous ? "Guest User" : user.email}</p>
                            </div>
                        </div>
                    )}

                    {isEditing && (
                        <div className="flex justify-end gap-3 pt-4 border-t border-gray-100 dark:border-gray-700">
                            <button onClick={handleCancel} disabled={loading} className="px-5 py-2.5 text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-colors">Cancel</button>
                            <button onClick={handleSave} disabled={loading} className="px-5 py-2.5 text-sm font-medium text-white bg-vynto-red hover:bg-vynto-hover rounded-xl shadow-lg shadow-red-500/20 transition-colors flex items-center gap-2">
                                {loading && <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>}
                                Save Changes
                            </button>
                        </div>
                    )}
                 </div>
            </div>
        </div>
      </div>
      
      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 px-1">Subscription & Usage</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <StatCard 
                label="Current Plan" 
                value={plan.name} 
                color="text-gray-900 dark:text-white"
                icon={<svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" /></svg>}
            />
            <StatCard 
                label={user.isAnonymous ? "Messages Left" : "Available Credits"} 
                value={isBasic ? user.creditsBalance : 'Unlimited'} 
                color="text-vynto-red" 
                icon={isBasic ? <CreditIcon /> : <InfinityIcon />}
            />
      </div>

         {/* Upgrade Motivation for Paid Users */}
         {!isBasic && nextPlan && !user.isAnonymous && (
            <div className="mb-8 p-8 rounded-2xl bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 dark:from-gray-800 dark:via-gray-900 dark:to-black text-white shadow-xl relative overflow-hidden group border border-gray-800">
                <div className="absolute top-0 right-0 w-64 h-64 bg-vynto-red opacity-10 rounded-full blur-3xl -mr-10 -mt-10 group-hover:opacity-20 transition-opacity duration-700"></div>
                
                <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                    <div>
                        <div className="flex items-center gap-2 mb-3">
                            <span className="bg-vynto-red text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">Recommended</span>
                        </div>
                        <h3 className="text-2xl font-bold tracking-tight mb-2">Upgrade to {nextPlan.name}</h3>
                        <p className="text-gray-300 text-sm max-w-md leading-relaxed">
                            Get access to premium features like {nextPlan.features[1] || 'advanced capabilities'} and more.
                        </p>
                    </div>
                    <button 
                        onClick={onUpgradeClick}
                        className="bg-white text-gray-900 font-bold py-3 px-6 rounded-xl shadow-lg hover:bg-gray-100 hover:scale-105 transition-all active:scale-95 whitespace-nowrap self-start md:self-center"
                    >
                        View Plan Details
                    </button>
                </div>
            </div>
         )}
         
         {isBasic && (
             <div className="mb-8 p-6 rounded-2xl bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30">
                 <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                     <div>
                         <h4 className="font-bold text-gray-900 dark:text-white mb-1">Upgrade your plan</h4>
                         <p className="text-sm text-gray-600 dark:text-gray-400">Unlock more credits, image generation, and premium support.</p>
                     </div>
                     <button onClick={onUpgradeClick} className="px-6 py-2.5 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-sm whitespace-nowrap">
                         See Plans
                     </button>
                 </div>
             </div>
         )}

         {!isBasic && !user.isAnonymous && (
            <div className="border-t border-gray-100 dark:border-gray-700 pt-6 mb-8">
                <button 
                    onClick={onContactClick}
                    className="text-sm text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white font-medium flex items-center gap-2 transition-colors"
                >
                    <span>Manage Subscription / Cancel</span>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 003 8.25v10.5A2.25 2.25 0 005.25 21h10.5A2.25 2.25 0 0018 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" /></svg>
                </button>
            </div>
         )}

      {!user.isAnonymous && (
          <div className="mt-12">
            <h3 className="text-lg font-bold text-red-600 dark:text-red-500 mb-4 px-1">Danger Zone</h3>
            <div className="border border-red-200 dark:border-red-500/30 rounded-2xl p-6 bg-red-50/50 dark:bg-red-900/10">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                    <div>
                        <p className="font-bold text-gray-900 dark:text-white">Delete Account</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md mt-1">
                            Permanently remove your account and all of its content from the VYNTO AI platform. This action is not reversible.
                        </p>
                    </div>
                    <button onClick={onDeleteAccount} className="px-5 py-2.5 bg-white dark:bg-red-900/20 text-red-600 border border-red-200 dark:border-red-500/30 font-semibold rounded-xl hover:bg-red-50 dark:hover:bg-red-900/30 transition-colors whitespace-nowrap self-start sm:self-center">
                        Delete Account
                    </button>
                </div>
            </div>
          </div>
      )}
    </div>
  );
};

export default AccountPage;