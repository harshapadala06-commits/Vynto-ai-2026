import React from 'react';

interface SettingsLayoutProps {
  activePage: string;
  onNavigate: (page: string) => void;
  onHomeClick: () => void;
  children: React.ReactNode;
  onMenuClick?: () => void; // For mobile
}

const SettingsLayout: React.FC<SettingsLayoutProps> = ({ activePage, onNavigate, onHomeClick, children, onMenuClick }) => {
  
  const navItems = [
    { id: 'account', label: 'Account' },
    { id: 'models', label: 'AI Models' },
  ];

  const workspaceItems = [
    { id: 'api_access', label: 'API Access' },
    { id: 'api_usage', label: 'API Usage' },
  ];

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 font-sans text-gray-900 dark:text-white overflow-hidden">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
            <button 
                onClick={onMenuClick}
                className="p-1.5 -ml-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="font-bold text-lg dark:text-white tracking-tight">Settings</div>
            <div className="w-8"></div> {/* Spacer */}
        </div>

        <div className="flex flex-1 overflow-hidden">
            {/* Settings Sidebar (Desktop) */}
            <div className="hidden md:flex w-full md:w-64 flex-shrink-0 h-full border-r border-gray-100 dark:border-gray-800 flex-col bg-gray-50/50 dark:bg-gray-900/50">
                <div className="p-4 flex-1 flex flex-col">
                    <button 
                        onClick={onHomeClick}
                        className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors mb-4"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                        Back to Chat
                    </button>

                    <div className="space-y-1">
                        {navItems.map((item) => (
                            <button
                            key={item.id}
                            onClick={() => onNavigate(item.id)}
                            className={`w-full text-left px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                                activePage === item.id 
                                ? 'bg-white dark:bg-gray-800 text-vynto-red shadow-sm' 
                                : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'
                            }`}
                            >
                            {item.label}
                            </button>
                        ))}
                    </div>

                    <div className="mt-6 pt-6 border-t border-gray-100 dark:border-gray-700">
                        <p className="px-3 text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Workspace</p>
                        <div className="space-y-1">
                            {workspaceItems.map((item) => (
                                <button
                                key={item.id}
                                onClick={() => onNavigate(item.id)}
                                className={`w-full text-left px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                                    activePage === item.id 
                                    ? 'bg-white dark:bg-gray-800 text-vynto-red shadow-sm' 
                                    : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'
                                }`}
                                >
                                {item.label}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 h-full overflow-y-auto bg-white dark:bg-gray-900 w-full">
                <div className="max-w-3xl mx-auto px-4 sm:px-6 md:px-8 py-8 md:py-12 min-h-full">
                    {children}
                </div>
            </div>
        </div>
    </div>
  );
};

export default SettingsLayout;