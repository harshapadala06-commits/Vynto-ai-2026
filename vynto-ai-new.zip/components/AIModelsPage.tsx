import React from 'react';

const AIModelsPage: React.FC = () => {
  
  const models = [
    { id: 'chatgpt', name: 'ChatGPT 4o', label: 'Balanced & Creative', desc: 'The flagship model, great for creative writing, complex problem-solving, and general-purpose tasks.' },
    { id: 'gemini', name: 'Gemini 3 Pro', label: 'Reasoning & Speed', desc: 'Optimized for fast, logical responses and benefits from real-time Google Search grounding for up-to-date info.' },
    { id: 'claude', name: 'Claude 3.5 Sonnet', label: 'Analysis & Coding', desc: 'Excels at long-form document analysis, summarization, and generating high-quality code.' },
    { id: 'grok', name: 'Grok Beta', label: 'Witty & Real-Time', desc: 'Provides witty, conversational responses with real-time access to current events and trending topics.' },
  ];

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tight">AI Models</h1>
      <p className="text-gray-500 dark:text-gray-400 mt-1 mb-8">Manage the AI models available in your workspace. Credit usage may vary by model.</p>

      <div className="space-y-4">
        {models.map((model) => (
          <div key={model.id} className="p-5 border border-gray-100 dark:border-gray-700 rounded-2xl bg-white dark:bg-gray-800 transition-colors group">
            <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                     <h3 className="font-bold text-gray-900 dark:text-white">{model.name}</h3>
                     <span className="text-[10px] text-gray-500 dark:text-gray-400 font-semibold px-2 py-0.5 bg-gray-50 dark:bg-gray-700 rounded-full border border-gray-200 dark:border-gray-600 uppercase tracking-wider">{model.label}</span>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 max-w-md">{model.desc}</p>
                </div>
                
                <div className="relative flex items-center">
                    <label className="inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked className="sr-only peer" />
                      <div className="relative w-11 h-6 bg-gray-200 dark:bg-gray-700 rounded-full peer peer-focus:ring-2 peer-focus:ring-vynto-red dark:peer-focus:ring-vynto-red peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-vynto-red"></div>
                    </label>
                </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AIModelsPage;