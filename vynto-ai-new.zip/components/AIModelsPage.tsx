import React from 'react';

const AIModelsPage: React.FC = () => {
  
  const models = [
    { id: 'chatgpt', name: 'ChatGPT', label: 'General purpose', desc: 'Best for everyday tasks and writing.' },
    { id: 'gemini', name: 'Gemini', label: 'Fast reasoning', desc: 'Quick responses with Google Search grounding.' },
    { id: 'claude', name: 'Claude', label: 'Long-form analysis', desc: 'Great for coding and complex document analysis.' },
    { id: 'grok', name: 'Grok', label: 'Real-time insights', desc: 'Witty and up-to-date with current events.' },
  ];

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-medium text-gray-900 mb-4">AI Models</h1>
      <p className="text-gray-500 mb-8">Choose which AI models you want to use. Credit usage varies by model.</p>

      <div className="space-y-4">
        {models.map((model) => (
          <div key={model.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors bg-white group">
            <div>
              <div className="flex items-center gap-2 mb-1">
                 <h3 className="font-bold text-gray-900">{model.name}</h3>
                 <span className="text-xs text-gray-400 font-medium px-2 py-0.5 bg-gray-100 rounded-full">{model.label}</span>
              </div>
              <p className="text-sm text-gray-500">{model.desc}</p>
            </div>
            
            <div className="relative group/tooltip">
                <span className="text-xs text-gray-400 cursor-help border-b border-dotted border-gray-400">Usage info</span>
                <div className="absolute right-0 bottom-full mb-2 w-48 bg-gray-900 text-white text-xs rounded p-2 opacity-0 group-hover/tooltip:opacity-100 transition-opacity pointer-events-none z-10">
                    Some models may use more credits.
                </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AIModelsPage;