import React from 'react';
import { PlanTier } from '../types';
import { PLANS } from '../constants';
import PlanCard from './PlanCard';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: PlanTier;
  onUpgrade: (planId: PlanTier) => void;
  message?: string;
  isGuest?: boolean;
  onGuestSignUpClick?: () => void;
}

const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose, currentPlan, onUpgrade, message, isGuest, onGuestSignUpClick }) => {
  if (!isOpen) return null;
  
  const handlePlanSelect = (planId: PlanTier) => {
    if (isGuest) {
      onGuestSignUpClick?.();
    } else {
      onUpgrade(planId);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-0 md:p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-gray-900 w-full md:max-w-6xl md:rounded-2xl shadow-2xl overflow-hidden h-full md:h-auto md:max-h-[90vh] flex flex-col">
        <div className="p-4 md:p-6 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center bg-gray-50/50 dark:bg-gray-900/50 flex-shrink-0">
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white">{isGuest ? 'Sign Up to Continue' : 'Upgrade Your Plan'}</h2>
            <p className="text-xs md:text-sm text-gray-500 dark:text-gray-400 mt-1 max-w-[250px] md:max-w-none truncate">{message || "Unlock advanced AI models, image generation, and more."}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-full text-gray-500 transition-colors">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
        
        <div className="p-4 md:p-6 overflow-y-auto bg-white dark:bg-gray-900 flex-1 custom-scrollbar">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-4 pb-4">
                {Object.values(PLANS).map((plan) => (
                <PlanCard 
                    key={plan.id} 
                    plan={plan} 
                    currentPlanId={currentPlan}
                    onSelect={handlePlanSelect}
                    isGuest={isGuest}
                />
                ))}
            </div>
        </div>
        
        <div className="p-4 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 text-center text-xs text-gray-400 dark:text-gray-500 flex-shrink-0 safe-bottom">
            <div className="flex justify-center items-center gap-1.5">
                <svg className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v4m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                <span>Secure payments powered by</span>
                <span className="font-bold text-gray-500 dark:text-gray-400">Razorpay</span>
            </div>
            <p className="text-[10px] mt-1">All major cards, UPI, and net banking accepted. Cancel anytime.</p>
        </div>
      </div>
    </div>
  );
};

export default UpgradeModal;
