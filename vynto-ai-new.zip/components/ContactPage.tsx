import React, { useState } from 'react';
import { supabase } from '../services/supabaseClient';

interface ContactPageProps {
    onMenuClick: () => void;
}

const SocialLink = ({ href, icon, handle }: { href: string; icon: React.ReactNode; handle: string; }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
        <div className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-400 group-hover:text-vynto-red dark:group-hover:text-vynto-red transition-colors">
            {icon}
        </div>
        <div>
            <span className="text-gray-900 dark:text-white font-medium group-hover:text-vynto-red dark:group-hover:text-vynto-red transition-colors">{handle}</span>
        </div>
    </a>
);


const ContactPage: React.FC<ContactPageProps> = ({ onMenuClick }) => {
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState('');
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        message: ''
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setSuccess(false);

        try {
            // Get current user if logged in (optional linking)
            const { data: { session } } = await supabase.auth.getSession();
            const user_id = session?.user?.id || null;

            const { error: dbError } = await supabase
                .from('contact_submissions')
                .insert([
                    { 
                        name: formData.name, 
                        email: formData.email, 
                        message: formData.message,
                        user_id: user_id
                    }
                ]);

            if (dbError) throw dbError;

            setSuccess(true);
            setFormData({ name: '', email: '', message: '' });
        } catch (err: any) {
            console.error('Submission error:', err);
            setError('Failed to send message. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full bg-white dark:bg-gray-900 animate-fade-in">
             {/* Mobile Header */}
            <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
                <button 
                    onClick={onMenuClick}
                    className="p-1.5 -ml-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" /></svg>
                </button>
                <div className="font-bold text-lg dark:text-white tracking-tight">Contact</div>
                <div className="w-8"></div>
            </div>

            <div className="flex-1 overflow-y-auto">
                <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
                    <div className="text-center mb-12">
                         <div className="w-16 h-16 bg-vynto-red rounded-2xl mx-auto flex items-center justify-center text-white text-3xl font-bold mb-6 shadow-lg shadow-red-200 dark:shadow-none">
                            V
                         </div>
                         <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Get in touch</h1>
                         <p className="text-lg text-gray-500 dark:text-gray-400">We'd love to hear from you. Fill out the form below or reach us directly.</p>
                         <div className="inline-block mt-4 bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 text-xs font-semibold px-3 py-1 rounded-full border border-gray-200 dark:border-gray-700">
                           VYNTO AI is proudly presented by V STORE
                         </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-8 mb-12">
                        {/* Office Info */}
                        <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-2xl border border-gray-100 dark:border-gray-700">
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                                <svg className="w-6 h-6 text-vynto-red" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6h1.5m-1.5 3h1.5m-1.5 3h1.5M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" /></svg>
                                Head Office
                            </h3>
                            <div className="space-y-4 text-gray-600 dark:text-gray-300">
                                <p className="font-medium text-lg">VYNTO AI HQ</p>
                                <p>Nizamabad</p>
                                <p>Telangana, India</p>
                            </div>
                        </div>

                        {/* Contact Info */}
                        <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-2xl border border-gray-100 dark:border-gray-700">
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                                <svg className="w-6 h-6 text-vynto-red" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>
                                Contact Info
                            </h3>
                            <div className="space-y-6">
                               <SocialLink 
                                 href="mailto:vynto@vstoreonline.in"
                                 handle="vynto@vstoreonline.in"
                                 icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>}
                               />
                               <SocialLink 
                                 href="https://www.instagram.com/vstoreonline.in"
                                 handle="@vstoreonline.in"
                                 icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="5" ry="5" /><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" /><line x1="17.5" y1="6.5" x2="17.51" y2="6.5" /></svg>}
                               />
                            </div>
                        </div>
                    </div>

                    {/* Contact Form */}
                    <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6 md:p-10 shadow-sm">
                        <div className="mb-6">
                            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Send us a message</h3>
                            <p className="text-gray-500 dark:text-gray-400 mt-1">We'll get back to you as soon as possible.</p>
                        </div>
                        
                        {success ? (
                            <div className="bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 p-6 rounded-xl flex flex-col items-center text-center animate-fade-in">
                                <div className="w-12 h-12 bg-green-100 dark:bg-green-800 rounded-full flex items-center justify-center mb-4">
                                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                                </div>
                                <h4 className="font-bold text-lg mb-2">Message Sent!</h4>
                                <p>Thank you for reaching out. We have received your message and will be in touch shortly.</p>
                                <button onClick={() => setSuccess(false)} className="mt-4 text-sm font-semibold underline hover:text-green-700">Send another message</button>
                            </div>
                        ) : (
                            <form onSubmit={handleSubmit} className="space-y-6">
                                {error && <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm p-4 rounded-lg">{error}</div>}
                                
                                <div className="grid md:grid-cols-2 gap-6">
                                    <div>
                                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Full Name</label>
                                        <input 
                                            type="text" 
                                            id="name"
                                            name="name"
                                            value={formData.name}
                                            onChange={handleChange}
                                            required
                                            className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-vynto-red focus:border-transparent transition-all"
                                            placeholder="John Doe"
                                        />
                                    </div>
                                    <div>
                                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Email Address</label>
                                        <input 
                                            type="email" 
                                            id="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            required
                                            className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-vynto-red focus:border-transparent transition-all"
                                            placeholder="john@example.com"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Message</label>
                                    <textarea 
                                        id="message"
                                        name="message"
                                        value={formData.message}
                                        onChange={handleChange}
                                        required
                                        rows={5}
                                        className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-vynto-red focus:border-transparent transition-all resize-none"
                                        placeholder="How can we help you?"
                                    />
                                </div>
                                <div className="flex justify-end">
                                    <button 
                                        type="submit" 
                                        disabled={loading}
                                        className={`px-8 py-3 bg-vynto-red text-white font-semibold rounded-lg hover:bg-vynto-hover shadow-lg shadow-red-500/20 transition-all flex items-center gap-2 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
                                    >
                                        {loading ? (
                                            <>
                                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                                Sending...
                                            </>
                                        ) : (
                                            <>
                                                Send Message
                                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                                            </>
                                        )}
                                    </button>
                                </div>
                            </form>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
export default ContactPage;