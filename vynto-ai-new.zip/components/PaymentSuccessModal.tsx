import React from 'react';

interface PaymentSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCancel: () => void;
  planName: string;
}

const PaymentSuccessModal: React.FC<PaymentSuccessModalProps> = ({ isOpen, onClose, onCancel, planName }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-gray-800 w-full max-w-sm rounded-2xl shadow-2xl p-8 flex flex-col items-center text-center animate-scale-in relative overflow-hidden">
        
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-400 to-emerald-600"></div>

        <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-6">
             <svg className="w-8 h-8 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
             </svg>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Payment Confirmed!</h2>
        
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-6 leading-relaxed">
          Welcome to the <strong className="text-gray-900 dark:text-white">{planName}</strong> plan!
          Your new features are now active.
        </p>
        
        <button 
            onClick={onClose}
            className="w-full py-3 bg-gray-900 dark:bg-white dark:text-gray-900 hover:bg-gray-800 dark:hover:bg-gray-200 text-white font-semibold rounded-xl transition-colors text-sm shadow-lg"
        >
            Start Exploring
        </button>
        <div className="mt-4">
            <button onClick={onCancel} className="text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 underline transition-colors">
                I didn't complete the payment
            </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentSuccessModal;