import React, { useState, useRef, useEffect } from 'react';
import { ModelType, ResponseStyle } from '../types';
import { AVAILABLE_MODELS } from '../constants';
import { enhancePrompt } from '../services/geminiService';

interface InputAreaProps {
  onSend: (text: string, model: ModelType, attachments?: string[]) => void;
  isStreaming?: boolean;
  onStop?: () => void;
  disabled: boolean; // General disable (like loading)
  selectedModel: ModelType;
  onModelChange: (model: ModelType) => void;
  variant?: 'centered' | 'bottom';
  responseStyle?: ResponseStyle;
  onResponseStyleChange?: (style: ResponseStyle) => void;
  showSubscribe?: boolean;
  onSubscribeClick?: () => void;
}

const ModelIcons: Record<ModelType, React.ReactNode> = {
  [ModelType.CHATGPT]: (
    <svg className="w-4 h-4 md:w-3.5 md:h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <title>ChatGPT</title>
      <path d="M12.5 2.5a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM9.5 9.5v5M14.5 9.5v5M9.5 12h5" />
    </svg>
  ),
  [ModelType.GEMINI]: (
    <svg className="w-4 h-4 md:w-3.5 md:h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <title>Gemini</title>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18M3 12h18M5.636 5.636l12.728 12.728M18.364 5.636L5.636 18.364" />
    </svg>
  ),
  [ModelType.CLAUDE]: (
    <svg className="w-4 h-4 md:w-3.5 md:h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <title>Claude</title>
        <path d="M14.5 14.5H9.5V9.5h5v5z" />
        <path d="M18.5 14.5H16v-8.5a2 2 0 0 0-2-2H5.5" />
    </svg>
  ),
  [ModelType.GROK]: (
    <svg className="w-4 h-4 md:w-3.5 md:h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <title>Grok</title>
        <path d="M7 7l10 10M7 17L17 7" />
    </svg>
  ),
};

// Helper function to compress images
const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 1024;
          const MAX_HEIGHT = 1024;
          let width = img.width;
          let height = img.height;
  
          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.8)); // Compress to JPEG 80%
        };
        img.onerror = (error) => reject(error);
      };
      reader.onerror = (error) => reject(error);
    });
};

const InputArea: React.FC<InputAreaProps> = ({ 
  onSend, 
  isStreaming = false,
  onStop,
  disabled, 
  selectedModel, 
  onModelChange, 
  variant = 'bottom', 
  responseStyle = 'standard',
  onResponseStyleChange,
  showSubscribe,
  onSubscribeClick
}) => {
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<string[]>([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isStyleDropdownOpen, setIsStyleDropdownOpen] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  
  const dropdownRef = useRef<HTMLDivElement>(null);
  const styleDropdownRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // We only disable input if processing file or enhancing. 
  // We allow typing while streaming (though user can't send until stop/finish)
  const isInputBusy = isEnhancing || isProcessingFile; 
  const isSendDisabled = (!input.trim() && attachments.length === 0) || isInputBusy || disabled;

  useEffect(() => {
    if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [input]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
      if (styleDropdownRef.current && !styleDropdownRef.current.contains(event.target as Node)) {
        setIsStyleDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSend = () => {
    if ((input.trim() || attachments.length > 0) && !isInputBusy && !isStreaming) {
      onSend(input, selectedModel, attachments);
      setInput('');
      setAttachments([]);
      if(textareaRef.current) textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleMicClick = async () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. Please try Chrome or Safari.");
      return;
    }

    try {
      // Explicitly request microphone permission to ensure prompt appears if not already granted
      await navigator.mediaDevices.getUserMedia({ audio: true });

      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;

      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      
      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
            alert("Microphone access blocked. Please allow microphone permissions in your browser settings.");
        }
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        
        // Append only final results to state to avoid duplication/jumping
        if (finalTranscript) {
            setInput(prev => prev + (prev ? ' ' : '') + finalTranscript);
        }
      };
      
      recognition.start();

    } catch (error) {
      console.error('Error requesting microphone permission:', error);
      alert("Could not access microphone. Please check your system settings and allow permission.");
      setIsListening(false);
    }
  };

  const handleModelSelect = (model: ModelType) => {
    onModelChange(model);
    setIsDropdownOpen(false);
  };

  const handleEnhance = async () => {
    if (!input.trim() || isEnhancing) return;
    setIsEnhancing(true);
    try {
        const enhanced = await enhancePrompt(input);
        setInput(enhanced);
    } finally {
        setIsEnhancing(false);
    }
  };

  const handleGenerateImageClick = () => {
      const prefix = "Generate an image of ";
      if (!input.startsWith(prefix)) setInput(prefix + input);
      textareaRef.current?.focus();
  };

  const handleGenerateVideoClick = () => {
      const prefix = "Generate a video of ";
      if (!input.startsWith(prefix)) setInput(prefix + input);
      textareaRef.current?.focus();
  };

  const handleAttachClick = () => {
      fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setIsProcessingFile(true);
          try {
             const compressedDataUrl = await compressImage(file);
             setAttachments(prev => [...prev, compressedDataUrl]);
          } catch (error) {
             console.error("Image processing error", error);
             const reader = new FileReader();
             reader.onloadend = () => {
                 if (reader.result) setAttachments(prev => [...prev, reader.result as string]);
             };
             reader.readAsDataURL(file);
          } finally {
             setIsProcessingFile(false);
          }
      }
      if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (index: number) => {
      setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const isCentered = variant === 'centered';

  return (
    <div className={`w-full mx-auto px-4 transition-all duration-300 ${isCentered ? 'max-w-2xl' : 'max-w-3xl'}`}>
      <div 
        className={`relative bg-white dark:bg-gray-800 border transition-all duration-200 flex flex-col
          ${isCentered 
            ? 'rounded-2xl border-gray-200 dark:border-gray-700 shadow-card hover:border-gray-300 dark:hover:border-gray-600 p-2' 
            : 'rounded-t-xl md:rounded-2xl border-gray-200 dark:border-gray-700 shadow-sm p-0'}
        `}
      >
        
        {attachments.length > 0 && (
            <div className={`flex gap-3 overflow-x-auto p-4 border-b border-gray-100 dark:border-gray-700 no-scrollbar`}>
                {attachments.map((src, idx) => (
                    <div key={idx} className="relative group shrink-0">
                        <img src={src} alt="attachment" className="w-16 h-16 object-cover rounded-md border border-gray-200 dark:border-gray-600" />
                        <button 
                            onClick={() => removeAttachment(idx)}
                            className="absolute -top-1.5 -right-1.5 bg-gray-900 text-white rounded-full p-0.5"
                        >
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                ))}
            </div>
        )}

        {isProcessingFile && (
             <div className="px-4 py-2 text-xs text-vynto-red font-medium flex items-center gap-2 animate-pulse">
                <div className="w-3 h-3 border-2 border-vynto-red border-t-transparent rounded-full animate-spin"></div>
                Compressing image...
             </div>
        )}

        <div className="flex items-start w-full relative">
           
           {isCentered && (
             <div className="pl-4 pt-3.5 text-gray-400 hidden md:block">
               <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" /></svg>
             </div>
           )}

           <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isListening ? "Listening..." : (isEnhancing ? "Optimizing query..." : "Ask anything...")}
            className={`w-full bg-transparent text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none resize-none 
              ${isCentered ? 'py-3.5 px-3 min-h-[52px]' : 'p-4 min-h-[56px]'} 
              max-h-[160px] leading-relaxed text-base
            `}
            disabled={isInputBusy}
            rows={1}
          />

           <div className="absolute right-3 top-3.5 flex items-center gap-2">
               {showSubscribe && (
                   <button onClick={onSubscribeClick} className="hidden md:flex items-center gap-1 bg-gradient-to-r from-yellow-500 to-amber-500 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-sm hover:shadow-md transition-all">
                       <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" /></svg>
                       Subscribe
                   </button>
               )}
               <button 
                onClick={handleMicClick}
                title="Use Microphone"
                className={`p-2 rounded-full transition-all ${isListening ? 'bg-red-100 text-red-600 animate-pulse' : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300'}`}
               >
                   <svg className="w-5 h-5" fill={isListening ? "currentColor" : "none"} viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 016 0v7.5a3 3 0 01-3 3z" /></svg>
               </button>
           </div>
        </div>

        <div className={`flex items-center justify-between flex-wrap gap-2 ${isCentered ? 'pl-4 pr-2 pb-2' : 'px-3 pb-3 pt-1'}`}>
          
          <div className="flex items-center gap-1 md:gap-1.5 flex-wrap">
             <div className="relative" ref={dropdownRef}>
                <button 
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  disabled={isStreaming}
                  className={`flex items-center gap-1.5 text-xs font-medium px-2 py-1.5 rounded-md transition-all border bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-gray-300 ${isStreaming ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <span className={'text-vynto-red'}>{ModelIcons[selectedModel]}</span>
                  <span className="truncate max-w-[80px] md:max-w-none">{AVAILABLE_MODELS.find(m => m.id === selectedModel)?.label}</span>
                </button>
                {isDropdownOpen && (
                  <div className="absolute bottom-full mb-2 left-0 w-56 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 py-1 z-20 overflow-hidden ring-1 ring-black ring-opacity-5">
                    {AVAILABLE_MODELS.map((model) => (
                      <button key={model.id} onClick={() => handleModelSelect(model.id)} className={`w-full text-left px-3 py-3 md:py-2 text-sm hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors ${selectedModel === model.id ? 'text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 font-medium' : 'text-gray-600 dark:text-gray-400'}`}>
                         <span className={selectedModel === model.id ? 'text-vynto-red' : 'text-gray-400'}>{ModelIcons[model.id]}</span>
                         <span className="flex-1">{model.label}</span>
                      </button>
                    ))}
                  </div>
                )}
             </div>

             {onResponseStyleChange && (
                 <div className="relative" ref={styleDropdownRef}>
                    <button onClick={() => setIsStyleDropdownOpen(!isStyleDropdownOpen)} disabled={isStreaming} className={`flex items-center gap-1 text-xs font-medium px-2 py-1.5 rounded-md transition-all border border-transparent hover:border-gray-200 dark:hover:border-gray-700 text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 ${isStreaming ? 'opacity-50 cursor-not-allowed' : ''}`}>
                        <span className="capitalize">{responseStyle}</span>
                    </button>
                    {isStyleDropdownOpen && (
                        <div className="absolute bottom-full mb-2 left-0 w-32 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 py-1 z-20 overflow-hidden">
                            {['concise', 'standard', 'detailed'].map((style) => (
                                <button key={style} onClick={() => { onResponseStyleChange(style as ResponseStyle); setIsStyleDropdownOpen(false); }} className={`w-full text-left px-3 py-3 md:py-2 text-xs hover:bg-gray-50 dark:hover:bg-gray-700 capitalize ${responseStyle === style ? 'text-vynto-red font-medium' : 'text-gray-600 dark:text-gray-400'}`}>
                                    {style}
                                </button>
                            ))}
                        </div>
                    )}
                 </div>
             )}

             <div className="h-4 w-px bg-gray-200 dark:bg-gray-700 mx-1 hidden sm:block"></div>
             
             <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />

             <div className="flex items-center gap-1">
                 <ToolbarButton onClick={handleAttachClick} disabled={isInputBusy || isStreaming} icon={<ClipIcon />} />
                 <ToolbarButton onClick={handleEnhance} disabled={!input.trim() || isEnhancing || isStreaming} icon={<SparklesIcon />} active={!!input.trim()} />
                 <ToolbarButton onClick={handleGenerateImageClick} disabled={isStreaming} icon={<ImageIcon />} />
                 <ToolbarButton onClick={handleGenerateVideoClick} disabled={isStreaming} icon={<VideoIcon />} />
             </div>
          </div>

          <div className="flex items-center gap-2 ml-auto">
             {/* Dynamic Send/Stop Button */}
            {isStreaming ? (
                 <button
                 onClick={onStop}
                 className="p-2 rounded-lg bg-gray-900 dark:bg-white text-white dark:text-gray-900 hover:bg-gray-700 dark:hover:bg-gray-200 transition-all shadow-sm group"
                 title="Stop generating"
               >
                 <span className="hidden group-hover:block absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-[10px] px-2 py-1 rounded">Stop</span>
                 <div className="w-5 h-5 flex items-center justify-center">
                    <div className="w-3 h-3 bg-current rounded-sm"></div>
                 </div>
               </button>
            ) : (
                <button
                onClick={handleSend}
                disabled={isSendDisabled}
                className={`p-2 rounded-lg transition-all duration-200 flex items-center justify-center
                    ${!isSendDisabled
                    ? 'bg-vynto-red text-white hover:bg-vynto-hover shadow-sm' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-300 dark:text-gray-500 cursor-not-allowed'}
                `}
                >
                {isEnhancing || isProcessingFile ? (
                    <div className="w-5 h-5 border-2 border-white/50 border-t-white rounded-full animate-spin"></div>
                ) : (
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg>
                )}
                </button>
            )}
          </div>
        </div>
      </div>
      <p className="text-[10px] text-center text-gray-400 dark:text-gray-500 mt-2 select-none">
        <a href="https://sites.google.com/view/vyntoaipolicy/discremer" target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-gray-600 dark:hover:text-gray-400">
            VYNTO AI can make mistakes. Consider checking important information.
        </a>
      </p>
    </div>
  );
};

const ToolbarButton = ({ onClick, disabled, icon, active }: { onClick: () => void, disabled: boolean, icon: React.ReactNode, active?: boolean }) => (
    <button onClick={onClick} disabled={disabled} className={`p-2 md:p-1.5 rounded-md transition-colors ${disabled ? 'text-gray-200 dark:text-gray-600 cursor-not-allowed' : active ? 'text-vynto-red bg-vynto-light dark:bg-red-900/20' : 'text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
        {icon}
    </button>
);

const ClipIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 7.372L8.552 18.32m.009-.01l-.01.01m5.699-9.941l-7.81 7.81a1.5 1.5 0 002.122 2.122l7.81-7.81" /></svg>;
const SparklesIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM18 15.75l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 20l-1.035.259a3.375 3.375 0 00-2.456 2.456L18 23.75l-.259-1.035a3.375 3.375 0 00-2.456-2.456L14.25 20l1.035-.259a3.375 3.375 0 002.456-2.456L18 15.75z" /></svg>;
const ImageIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25z" /></svg>;
const VideoIcon = () => <svg className="w-5 h-5 md:w-4 md:h-4" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9A2.25 2.25 0 004.5 18.75z" /></svg>;

export default React.memo(InputArea);