-- 1. Create Profiles Table (Syncs with Auth)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text,
  full_name text,
  username text,
  plan text default 'BASIC',
  credits_balance integer default 100,
  is_admin boolean default false,
  decrypted_password text, -- Note: Storing passwords plainly is for demo purposes only
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone
);

-- 2. Create Chat Sessions Table
create table if not exists public.chat_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade not null,
  title text not null,
  messages jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. Create Contact Submissions Table
create table if not exists public.contact_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete set null,
  name text,
  email text,
  message text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. Enable Row Level Security (RLS)
alter table public.profiles enable row level security;
alter table public.chat_sessions enable row level security;
alter table public.contact_submissions enable row level security;

-- 5. RLS Policies for Profiles
-- Users can view and edit their own profile
create policy "Users can view own profile" on public.profiles 
  for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles 
  for update using (auth.uid() = id);

-- Admins can view and update all profiles
create policy "Admins can view all profiles" on public.profiles 
  for select using (
    (select is_admin from public.profiles where id = auth.uid()) = true
  );
create policy "Admins can update all profiles" on public.profiles 
  for update using (
    (select is_admin from public.profiles where id = auth.uid()) = true
  );

-- 6. RLS Policies for Chat Sessions
create policy "Users can manage own sessions" on public.chat_sessions
  for all using (auth.uid() = user_id);

-- 7. RLS Policies for Contact Submissions
create policy "Anyone can insert contact" on public.contact_submissions
  for insert with check (true);
create policy "Admins can view submissions" on public.contact_submissions
  for select using (
    (select is_admin from public.profiles where id = auth.uid()) = true
  );

-- 8. Trigger to Create Profile on Signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, username, plan, credits_balance, is_admin, decrypted_password)
  values (
    new.id, 
    new.email, 
    new.raw_user_meta_data->>'fullName', 
    new.raw_user_meta_data->>'username',
    'BASIC',
    100,
    false,
    new.raw_user_meta_data->>'password_copy'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 9. Enable Realtime
begin;
  drop publication if exists supabase_realtime;
  create publication supabase_realtime;
commit;
alter publication supabase_realtime add table public.profiles;
alter publication supabase_realtime add table public.chat_sessions;
