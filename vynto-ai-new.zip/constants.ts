import { Plan, PlanTier, ModelType } from './types';

export const ADMIN_CONFIG = {
  GUEST_MESSAGE_LIMIT: 3,
};

export const PLANS: Record<PlanTier, Plan> = {
  [PlanTier.BASIC]: {
    id: PlanTier.BASIC,
    name: 'Basic',
    price: 'Free',
    initialCredits: 100,
    allowImages: false,
    models: [ModelType.CHATGPT],
    features: [
        'Access to Standard AI Models',
        'Standard Chat History',
        'Community Support Access'
    ],
  },
  [PlanTier.STANDARD]: {
    id: PlanTier.STANDARD,
    name: 'Standard',
    price: '₹99',
    originalPrice: '₹299',
    initialCredits: 500,
    allowImages: true,
    models: [ModelType.CHATGPT, ModelType.GEMINI],
    features: [
        'Access to Standard AI Models',
        'Image Generation Access',
        'Standard Chat History',
        'Ad-Free Experience',
        '24/7 Premium Support'
    ],
  },
  [PlanTier.PREMIUM]: {
    id: PlanTier.PREMIUM,
    name: 'Premium',
    price: '₹199',
    originalPrice: '₹399',
    initialCredits: 1000,
    allowImages: true,
    isPopular: true,
    models: [ModelType.CHATGPT, ModelType.GEMINI, ModelType.CLAUDE, ModelType.GROK],
    features: [
        'Access to All Premium Models',
        'Advanced Image Generation',
        'Early Access to New Features',
        'Priority Email Support',
        'Ad-Free Experience'
    ],
  },
  [PlanTier.ADVANCED]: {
    id: PlanTier.ADVANCED,
    name: 'Advanced',
    price: '₹399',
    originalPrice: '₹799',
    initialCredits: 2500,
    allowImages: true,
    models: [ModelType.CHATGPT, ModelType.GEMINI, ModelType.CLAUDE, ModelType.GROK],
    features: [
        'Maximum Power & Performance',
        'Access to All Premium Models',
        'Advanced Image Generation',
        '4K Video Generation',
        'Dedicated Account Manager',
        'API Access (Coming Soon)',
        'Early Access to New Features',
    ],
  },
};

export const AVAILABLE_MODELS = [
  { id: ModelType.CHATGPT, label: 'ChatGPT 4o' },
  { id: ModelType.GEMINI, label: 'Gemini 3 Pro' },
  { id: ModelType.CLAUDE, label: 'Claude 3.5 Sonnet' },
  { id: ModelType.GROK, label: 'Grok Beta' },
];

export const APP_NAME = "VYNTO AI";