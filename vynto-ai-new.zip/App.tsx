import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User, Message, ModelType, PlanTier, ResponseStyle, ChatSession } from './types';
import { clearSession, saveSession, getUser, updateUser, loginAsGuest, deleteUser } from './services/authService';
import { getSessions, createSession, deleteSession } from './services/chatService';
import { generateResponseStream, generateImage, generateVideo, generateRelatedQuestions } from './services/geminiService';
import { AVAILABLE_MODELS, PLANS, ADMIN_CONFIG } from './constants';
import { supabase, isSupabaseConfigured } from './services/supabaseClient';

import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import InputArea from './components/InputArea';
import UpgradeModal from './components/UpgradeModal';
import NotificationToast from './components/NotificationToast';
import ComingSoonModal from './components/ComingSoonModal';
import ContactPage from './components/ContactPage';
import ServicesPage from './components/ServicesPage';
import AuthPage from './components/AuthPage';
import SettingsLayout from './components/SettingsLayout';
import AccountPage from './components/AccountPage';
import AIModelsPage from './components/AIModelsPage';
import DiscoverPage from './components/DiscoverPage';
import LibraryPage from './components/LibraryPage';
import SpacesPage from './components/SpacesPage';
import ConfirmationModal from './components/ConfirmationModal';
import AdminPanel from './components/AdminPanel';
import PaymentSuccessModal from './components/PaymentSuccessModal';
import LegalModal from './components/LegalModal';

type AppView = 'chat' | 'settings' | 'discover' | 'library' | 'spaces' | 'contact' | 'services' | 'admin';
type SettingsPage = 'account' | 'models' | 'api_access' | 'api_usage';

const paymentLinks: Record<string, string> = {
  [PlanTier.STANDARD]: 'https://rzp.io/rzp/TTi26zoz',
  [PlanTier.PREMIUM]: 'https://rzp.io/rzp/aKStrC1',
  [PlanTier.ADVANCED]: 'https://rzp.io/rzp/vURF3hm',
};

const PENDING_UPGRADE_KEY = 'vynto_pending_upgrade';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [selectedModel, setSelectedModel] = useState<ModelType>(ModelType.CHATGPT);
  const [isStreaming, setIsStreaming] = useState(false);
  
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [upgradeReason, setUpgradeReason] = useState("Unlock more features.");
  const [comingSoonFeature, setComingSoonFeature] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [notification, setNotification] = useState<{ message: string, type: 'info' | 'warning' | 'success' | 'error' } | null>(null);
  const [currentView, setCurrentView] = useState<AppView>('chat');
  const [settingsPage, setSettingsPage] = useState<SettingsPage>('account');
  const [responseStyle, setResponseStyle] = useState<ResponseStyle>('standard');
  
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [showUpgradeConfirmModal, setShowUpgradeConfirmModal] = useState(false);
  const [showPaymentSuccessModal, setShowPaymentSuccessModal] = useState(false);
  const [pendingUpgrade, setPendingUpgrade] = useState<PlanTier | null>(null);
  const [showLegalModal, setShowLegalModal] = useState(false);
  
  const abortControllerRef = useRef<AbortController | null>(null);

  const handleLoginSuccess = useCallback((loggedInUser: User) => {
      if (loggedInUser.accountStatus === 'Blocked') {
          setNotification({ message: "Your account is blocked. Please contact support.", type: 'error' });
          return;
      }
      
      setUser(loggedInUser);
      setShowUpgradeModal(false);
      if(!loggedInUser.isAnonymous) {
          setNotification({ message: `Welcome back, ${loggedInUser.fullName.split(' ')[0]}!`, type: 'success' });
      } else if (isSupabaseConfigured) {
          const isNewGuest = loggedInUser.creditsBalance === ADMIN_CONFIG.GUEST_MESSAGE_LIMIT;
          if (isNewGuest) {
            setNotification({ message: `You are browsing as a guest.`, type: 'info' });
          }
      }
  }, []);
  
  const handleLogout = async (notify = false) => {
      setUser(null);
      setMessages([]);
      setSessions([]);
      setCurrentView('chat');
      setIsMobileMenuOpen(false);
      await clearSession();
      if (notify) {
        setNotification({ message: "You have been logged out.", type: 'info' });
      }
  };

  const handleGuestLogin = useCallback(() => {
    const guestUser = loginAsGuest();
    saveSession(guestUser);
    handleLoginSuccess(guestUser);
  }, [handleLoginSuccess]);
  
  const initiateUpgrade = (planId: PlanTier) => {
    if (isSupabaseConfigured && (!user || user.isAnonymous)) {
        setShowUpgradeModal(true);
        return;
    }
    setPendingUpgrade(planId);
    localStorage.setItem(PENDING_UPGRADE_KEY, planId);
    setShowUpgradeModal(false);
    setShowUpgradeConfirmModal(true);
  };

  const handleGuestUpgradeAttempt = (planId: PlanTier) => {
    if (!isSupabaseConfigured) {
        setNotification({ message: "An internet connection is required to create an account.", type: 'warning' });
        return;
    }
    // Force guest to log in or sign up before they can upgrade
    setShowUpgradeModal(false);
    handleLogout(false);
  };

  useEffect(() => {
    if (!isSupabaseConfigured) {
      // If backend is not set up, silently fall back to guest mode.
      handleGuestLogin();
      setNotification({ message: "Backend not configured. Running in offline Guest Mode.", type: 'warning' });
      setIsLoading(false);
      return;
    }

    const initAuth = async () => {
      try {
        const userData = await getUser();
        if (userData) {
          setUser(userData);
          const savedPendingUpgrade = localStorage.getItem(PENDING_UPGRADE_KEY);
          if (savedPendingUpgrade && Object.values(PlanTier).includes(savedPendingUpgrade as PlanTier)) {
              setPendingUpgrade(savedPendingUpgrade as PlanTier);
          }
        } else {
           handleGuestLogin();
        }
      } catch (error) {
        console.error("Auth initialization error", error);
        handleGuestLogin();
      } finally {
        setIsLoading(false);
      }
    };
    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
            const userData = await getUser();
            if(userData) setUser(userData);
        } else if (event === 'SIGNED_OUT') {
            setUser(null);
        }
    });
    return () => subscription.unsubscribe();
  }, [handleGuestLogin]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (isLoading) {
        timer = setTimeout(() => {
            if (isLoading) {
                setIsLoading(false);
                if (!user) {
                    handleGuestLogin();
                    setNotification({ message: "Connection timed out. Switched to offline mode.", type: 'warning' });
                }
            }
        }, 10000);
    }
    return () => clearTimeout(timer);
  }, [isLoading, user, handleGuestLogin]);

  useEffect(() => {
    if (!user || user.isAnonymous || !user.id || !isSupabaseConfigured) return;
    const channel = supabase.channel(`user_profile_${user.id}`).on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${user.id}`},
            (payload: any) => {
                const updatedUser = { 
                    ...user, 
                    plan: payload.new.plan, 
                    creditsBalance: payload.new.credits_balance, 
                    isAdmin: payload.new.is_admin,
                    fullName: payload.new.full_name,
                    username: payload.new.username,
                    accountStatus: payload.new.account_status
                };
                setUser(updatedUser);
                if (updatedUser.accountStatus === 'Blocked') {
                     setNotification({ message: "Your account has been blocked by an administrator.", type: 'error' });
                } else {
                     setNotification({ message: "Your account has been updated.", type: 'info' });
                }
            }
        ).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user]);

  useEffect(() => {
    if (!user || !user.id) {
        setSessions([]);
        return;
    };

    const fetchUserSessions = async () => {
        try {
            const userSessions = await getSessions(user.id!);
            setSessions(userSessions);
        } catch (error: any) {
            console.error("Failed to fetch sessions", error);
            if (isSupabaseConfigured && error?.code === '42P01') { 
                 setNotification({ message: "System Update: Please run the database setup SQL.", type: 'warning' });
            }
        }
    };
    fetchUserSessions();

    if (isSupabaseConfigured) {
        const channel = supabase.channel(`chat_sessions_${user.id}`)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_sessions', filter: `user_id=eq.${user.id}` },
                (payload) => {
                    if (payload.eventType === 'INSERT') {
                        setSessions(prev => [payload.new as ChatSession, ...prev]);
                    } else if (payload.eventType === 'DELETE') {
                        setSessions(prev => prev.filter(s => s.id !== payload.old.id));
                    }
                }
            ).subscribe();
        return () => { supabase.removeChannel(channel); };
    }
  }, [user?.id]);

  useEffect(() => {
      const handleVisibilityChange = () => {
          if (document.visibilityState === 'visible' && pendingUpgrade) {
              setShowPaymentSuccessModal(true);
          }
      };
      document.addEventListener('visibilitychange', handleVisibilityChange);
      return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [pendingUpgrade]);


  const handleNewChat = async () => {
    if (messages.length > 0 && user) {
        const title = messages[0].content.substring(0, 30) + (messages[0].content.length > 30 ? '...' : '');
        const newSession: Omit<ChatSession, 'id' | 'createdAt'> = { title, messages: [...messages] };
        try {
            const savedSession = await createSession(newSession, user.id!);
            if (!isSupabaseConfigured) {
                setSessions(prev => [savedSession, ...prev]);
            }
        } catch(e) {
            console.error(e);
            setNotification({ message: 'Failed to save session.', type: 'error' });
        }
    }
    setMessages([]);
    setCurrentView('chat');
    setIsMobileMenuOpen(false);
  };

  const handleDeleteSession = async (sessionId: string) => {
      try {
        await deleteSession(sessionId);
        if (!isSupabaseConfigured) {
             setSessions(prev => prev.filter(s => s.id !== sessionId));
        }
        setNotification({ message: "Thread deleted.", type: 'info' });
      } catch (e) {
        setNotification({ message: "Failed to delete thread.", type: 'error' });
      }
  };

  const handleLoadSession = (sessionId: string) => {
      const session = sessions.find(s => s.id === sessionId);
      if (session) {
          setMessages(session.messages);
          setCurrentView('chat');
          setIsMobileMenuOpen(false);
      }
  };

  const handleOpenSettings = (page: SettingsPage = 'account') => {
      setSettingsPage(page);
      setCurrentView('settings');
      setIsMobileMenuOpen(false);
  };
  
  
  const confirmAndPay = () => {
      if (!pendingUpgrade) return;
      setShowUpgradeConfirmModal(false);
      const url = paymentLinks[pendingUpgrade];
      if (url) {
          setNotification({ message: "Redirecting to payment... Do not press back.", type: 'info' });
          setTimeout(() => window.open(url, '_blank'), 1500);
      }
  };

  const finalizeUpgrade = async () => {
      if (!user || !pendingUpgrade) return;
      const planId = pendingUpgrade;
      const planDetails = PLANS[planId];
      
      const updatedUser: User = { 
          ...user, 
          plan: planId, 
          creditsBalance: user.creditsBalance + planDetails.initialCredits 
      };
      setUser(updatedUser);
      setShowPaymentSuccessModal(false);
      setNotification({ message: `Successfully upgraded to ${planDetails.name}!`, type: 'success' });
      setCurrentView('chat');
      
      setPendingUpgrade(null);
      localStorage.removeItem(PENDING_UPGRADE_KEY);

      try {
          await updateUser(updatedUser);
      } catch(e) {
          console.error("Failed to sync upgrade to DB", e);
      }
  };

  const cancelPendingUpgrade = () => {
      setPendingUpgrade(null);
      localStorage.removeItem(PENDING_UPGRADE_KEY);
      setShowPaymentSuccessModal(false);
      setNotification({ message: "Upgrade process has been cancelled.", type: 'info' });
  };
  
  const handleUpdateUserDetails = (updatedDetails: { fullName: string; username: string }) => {
    if (!user) return;
    const originalUser = { ...user };
    const optimisticUser = { ...user, ...updatedDetails };

    setUser(optimisticUser);

    updateUser(optimisticUser)
      .then(() => {
        setNotification({ message: 'Profile updated successfully!', type: 'success' });
      })
      .catch((error: any) => {
        setUser(originalUser);
        setNotification({ message: `Update failed: ${error.message || 'Please try again.'}`, type: 'error' });
      });
  };

  const handleDeleteAccount = async () => {
    if (!user || user.isAnonymous) return;
    try {
        await deleteUser(user.email);
        setShowDeleteConfirmModal(false);
        handleLogout(false); 
        setNotification({ message: 'Deletion request submitted.', type: 'info'});
    } catch (error) {
        console.error(error);
        setNotification({ message: 'Failed to submit deletion request.', type: 'error' });
    }
  };

  const handlePinMessage = (message: Message) => {
      setMessages(prev => prev.map(m => m.id === message.id ? { ...m, isPinned: !m.isPinned } : m));
      setNotification({ 
          message: message.isPinned ? "Message unpinned." : "Message pinned.", 
          type: 'info' 
      });
  };

  const handleStopGeneration = () => {
      if (abortControllerRef.current) {
          abortControllerRef.current.abort();
          abortControllerRef.current = null;
          setIsStreaming(false);
          setMessages(prev => prev.map(m => m.isThinking ? { ...m, isThinking: false, content: m.content + " [Stopped]" } : m));
      }
  };

  const handleSendMessage = useCallback(async (text: string, model: ModelType, attachments?: string[]) => {
    if (currentView !== 'chat') setCurrentView('chat');
    if (!user) return;
    
    if (user.accountStatus === 'Blocked') {
        setNotification({ message: "Your account is blocked. You cannot send messages.", type: 'error' });
        return;
    }

    const type = text.toLowerCase().startsWith('generate image') ? 'image' : text.toLowerCase().startsWith('generate video') ? 'video' : 'text';
    const plan = PLANS[user.plan];
    
    if (type === 'image' && !plan.allowImages) {
        setUpgradeReason("Upgrade your plan to generate images.");
        setShowUpgradeModal(true);
        return;
    }
    
    if (user.creditsBalance <= 0 && user.plan === PlanTier.BASIC) {
        setUpgradeReason(user.isAnonymous ? "You have used all guest credits." : "You've run out of credits.");
        setShowUpgradeModal(true);
        return;
    }

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: text, timestamp: Date.now(), images: attachments };
    const modelMsgId = (Date.now() + 1).toString();
    const modelMsg: Message = { id: modelMsgId, role: 'model', content: '', modelUsed: AVAILABLE_MODELS.find(m => m.id === model)?.label, timestamp: Date.now(), isThinking: true };

    setMessages(prev => [...prev, userMsg, modelMsg]);
    setIsStreaming(true);

    const aborter = new AbortController();
    abortControllerRef.current = aborter;

    try {
      if (type === 'image') {
          const imageUrl = await generateImage(text);
          setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: `Image generated for: "${text}"`, isThinking: false, images: [imageUrl] } : m));
      } else if (type === 'video') {
          const videoUrl = await generateVideo(text);
          setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: `Video generated for: "${text}"`, isThinking: false, videos: [videoUrl] } : m));
      } else {
          const history = messages.slice(0, -2).map(m => ({ role: m.role, content: m.content }));
          let fullResponse = "";
          await generateResponseStream(text, model, history, (chunk) => {
              fullResponse += chunk;
              setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: fullResponse, isThinking: false } : m));
          }, responseStyle, attachments, aborter.signal);
          
          if (!aborter.signal.aborted) {
              generateRelatedQuestions(fullResponse).then(questions => {
                  setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, relatedQuestions: questions } : m));
              });
          }
      }
      
      if (user.plan === PlanTier.BASIC) {
        const updatedUser = { ...user, creditsBalance: Math.max(0, user.creditsBalance - 1) };
        setUser(updatedUser);
        updateUser(updatedUser);
      }

    } catch (error: any) {
        if (error.name !== 'AbortError') {
            console.error("Generation error", error);
            setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: "An error occurred. Please try again.", isThinking: false } : m));
        }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  }, [user, messages, currentView, responseStyle]);

  const onLegalClick = () => setShowLegalModal(true);

  if (isLoading) {
    return (
        <div className="flex items-center justify-center h-screen w-screen bg-gray-50 dark:bg-gray-900">
            <div className="w-8 h-8 border-4 border-vynto-red border-t-transparent rounded-full animate-spin"></div>
        </div>
    );
  }

  if (!user) {
    return (
        <>
            <AuthPage onLoginSuccess={handleLoginSuccess} onSignupSuccess={(u) => {
                handleLoginSuccess(u);
                setNotification({ message: `Welcome! You have ${u.creditsBalance} credits.`, type: 'success' });
            }} onLegalClick={onLegalClick} />
            <LegalModal isOpen={showLegalModal} onClose={() => setShowLegalModal(false)} />
        </>
    );
  }

  if (user.accountStatus === 'Blocked') {
      return (
          <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
              <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-2xl max-w-md w-full text-center border border-gray-100 dark:border-gray-700">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
                      <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Account Blocked</h2>
                  <p className="text-gray-500 dark:text-gray-400 mb-8">
                      Your account has been suspended by an administrator.
                  </p>
                  <button onClick={() => handleLogout(true)} className="w-full py-3 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl transition-colors">
                      Log Out
                  </button>
              </div>
          </div>
      );
  }

  const renderContent = () => {
    switch(currentView) {
        case 'discover': return <DiscoverPage onPromptClick={(txt, model) => handleSendMessage(txt, model)} onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'library': return <LibraryPage user={user} onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'spaces': return <SpacesPage onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'contact': return <ContactPage onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'services': return <ServicesPage onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'admin':
            if (!user.isAdmin) return <div className="p-10">Access Denied</div>;
            return <AdminPanel onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'settings':
            return (
                <SettingsLayout activePage={settingsPage} onNavigate={(p) => setSettingsPage(p as SettingsPage)} onHomeClick={() => setCurrentView('chat')} onMenuClick={() => setIsMobileMenuOpen(true)}>
                    {settingsPage === 'account' && <AccountPage user={user} onLogout={() => handleLogout(true)} onUpgradeClick={() => { setUpgradeReason("Upgrade your plan to unlock more features."); setShowUpgradeModal(true);}} onUpdateUser={handleUpdateUserDetails} onDeleteAccount={() => setShowDeleteConfirmModal(true)} onContactClick={() => setCurrentView('contact')} />}
                    {settingsPage === 'models' && <AIModelsPage />}
                    {(settingsPage === 'api_access' || settingsPage === 'api_usage') && <div className="text-center p-8 text-gray-500">Coming Soon</div>}
                </SettingsLayout>
            );
        case 'chat':
        default:
             return (
                <div className="flex-1 flex flex-col relative h-full transition-all bg-white dark:bg-gray-900">
                    <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
                        <button onClick={() => setIsMobileMenuOpen(true)} className="p-1.5 -ml-1.5"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg></button>
                        <div className="font-bold">VYNTO</div>
                        <button onClick={() => { setUpgradeReason("Upgrade your plan."); setShowUpgradeModal(true); }} className="text-xs bg-vynto-red text-white px-3 py-1.5 rounded-lg">{user.plan === PlanTier.BASIC ? 'Upgrade' : 'Manage Plan'}</button>
                    </div>
                    {messages.length === 0 ? (
                        <div className="flex-1 flex flex-col items-center justify-center p-4">
                            <h1 className="text-4xl font-medium mb-8">VYNTO AI</h1>
                            <InputArea 
                                onSend={handleSendMessage} 
                                isStreaming={isStreaming} 
                                onStop={handleStopGeneration} 
                                disabled={false} 
                                selectedModel={selectedModel} 
                                onModelChange={setSelectedModel} 
                                variant="centered" 
                                responseStyle={responseStyle} 
                                onResponseStyleChange={setResponseStyle} 
                                showSubscribe={user.plan === PlanTier.BASIC}
                                onSubscribeClick={() => { setUpgradeReason("Subscribe to unlock premium features."); setShowUpgradeModal(true); }}
                                onLegalClick={onLegalClick}
                            />
                        </div>
                    ) : (
                        <>
                            <div className="flex-1 overflow-y-auto"><ChatArea messages={messages} isStreaming={isStreaming} onFollowUpClick={(q) => handleSendMessage(q, selectedModel)} onPinMessage={handlePinMessage} /></div>
                            <div className="fixed bottom-0 left-0 md:left-64 right-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm pb-safe-bottom z-20 border-t border-gray-100 dark:border-gray-800">
                                <div className="py-4">
                                    <InputArea 
                                        onSend={handleSendMessage} 
                                        isStreaming={isStreaming}
                                        onStop={handleStopGeneration}
                                        disabled={false} 
                                        selectedModel={selectedModel} 
                                        onModelChange={setSelectedModel} 
                                        variant="bottom" 
                                        responseStyle={responseStyle} 
                                        onResponseStyleChange={setResponseStyle} 
                                        showSubscribe={user.plan === PlanTier.BASIC}
                                        onSubscribeClick={() => { setUpgradeReason("Subscribe to unlock premium features."); setShowUpgradeModal(true); }}
                                        onLegalClick={onLegalClick}
                                    />
                                </div>
                            </div>
                        </>
                    )}
                </div>
             );
    }
  };

  return (
    <div className={`flex h-screen bg-gray-50 overflow-hidden font-sans text-gray-900 dark:text-gray-100 dark:bg-gray-900 w-full`}>
      {notification && <NotificationToast message={notification.message} type={notification.type} onClose={() => setNotification(null)} />}
      <Sidebar 
          user={user} 
          activeView={currentView} 
          onNavigate={(v) => { setCurrentView(v as AppView); setIsMobileMenuOpen(false); }} 
          onNewChat={handleNewChat} 
          onUpgradeClick={() => { setUpgradeReason("Upgrade your plan to unlock more features."); setShowUpgradeModal(true); }} 
          onSettingsClick={() => handleOpenSettings('account')} 
          onComingSoon={setComingSoonFeature} 
          sessions={sessions} 
          onDeleteSession={handleDeleteSession} 
          onLoadSession={handleLoadSession} 
          isOpen={isMobileMenuOpen} 
          onClose={() => setIsMobileMenuOpen(false)} 
          onLogout={() => handleLogout(true)} 
          onAccountClick={() => handleOpenSettings('account')} 
          onLegalClick={onLegalClick}
      />
      <main className={`flex-1 flex flex-col md:ml-64 relative h-full transition-all w-full`}>{renderContent()}</main>
      <ComingSoonModal isOpen={!!comingSoonFeature} onClose={() => setComingSoonFeature(null)} featureName={comingSoonFeature || undefined} />
      <UpgradeModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} currentPlan={user.plan} onUpgrade={initiateUpgrade} message={upgradeReason} isGuest={user.isAnonymous} onGuestSignUpClick={handleGuestUpgradeAttempt} />
      <LegalModal isOpen={showLegalModal} onClose={() => setShowLegalModal(false)} />
      <ConfirmationModal
        isOpen={showDeleteConfirmModal}
        onClose={() => setShowDeleteConfirmModal(false)}
        onConfirm={handleDeleteAccount}
        title="Delete Account"
        message="Are you sure? This action is permanent and cannot be undone."
        confirmText="Delete"
      />
      <ConfirmationModal
        isOpen={showUpgradeConfirmModal}
        onClose={() => setShowUpgradeConfirmModal(false)}
        onConfirm={confirmAndPay}
        title={`Confirm Upgrade to ${PLANS[pendingUpgrade!]?.name}`}
        message={
            <>
              You will be redirected to our secure payment partner to complete your purchase.
              <br/><br/>
              <strong className="text-gray-800 dark:text-gray-100">
                  IMPORTANT: After upgrading, please send a screenshot to our Instagram page
                  <a href="https://www.instagram.com/vstoreonline.in/" target="_blank" rel="noopener noreferrer" className="text-vynto-red underline ml-1">
                      @vstoreonline.in
                  </a> to ensure prompt plan activation.
              </strong>
            </>
        }
        confirmText="Continue to Payment"
      />
      {pendingUpgrade && (
          <PaymentSuccessModal
            isOpen={showPaymentSuccessModal}
            onClose={finalizeUpgrade}
            onCancel={cancelPendingUpgrade}
            planName={PLANS[pendingUpgrade]?.name}
          />
      )}
    </div>
  );
}

export default App;