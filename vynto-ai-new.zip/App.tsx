import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User, Message, ModelType, PlanTier, ResponseStyle, ChatSession } from './types';
import { clearSession, saveSession, getUser, updateUser, loginAsGuest, deleteUser } from './services/authService';
import { getSessions, createSession, deleteSession } from './services/chatService';
import { generateResponseStream, generateImage, generateVideo, generateRelatedQuestions } from './services/geminiService';
import { AVAILABLE_MODELS, PLANS, ADMIN_CONFIG } from './constants';
import { supabase } from './services/supabaseClient';

import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import InputArea from './components/InputArea';
import UpgradeModal from './components/UpgradeModal';
import NotificationToast from './components/NotificationToast';
import ComingSoonModal from './components/ComingSoonModal';
import ContactPage from './components/ContactPage';
import ServicesPage from './components/ServicesPage';
import AuthPage from './components/AuthPage';
import SettingsLayout from './components/SettingsLayout';
import AccountPage from './components/AccountPage';
import AIModelsPage from './components/AIModelsPage';
import DiscoverPage from './components/DiscoverPage';
import LibraryPage from './components/LibraryPage';
import SpacesPage from './components/SpacesPage';
import ConfirmationModal from './components/ConfirmationModal';
import AdminPanel from './components/AdminPanel';
import PaymentSuccessModal from './components/PaymentSuccessModal';
import LegalModal from './components/LegalModal';

type AppView = 'chat' | 'settings' | 'discover' | 'library' | 'spaces' | 'contact' | 'services' | 'admin';
type SettingsPage = 'account' | 'models' | 'api_access' | 'api_usage';

const paymentLinks: Record<string, string> = {
  [PlanTier.STANDARD]: 'https://rzp.io/l/TTi26zoz',
  [PlanTier.PREMIUM]: 'https://rzp.io/l/aKStrC1',
  [PlanTier.ADVANCED]: 'https://rzp.io/l/vURF3hm',
};

const PENDING_UPGRADE_KEY = 'vynto_pending_upgrade';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [selectedModel, setSelectedModel] = useState<ModelType>(ModelType.CHATGPT);
  const [isStreaming, setIsStreaming] = useState(false);
  
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [upgradeReason, setUpgradeReason] = useState("Unlock more features.");
  const [comingSoonFeature, setComingSoonFeature] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [notification, setNotification] = useState<{ message: string, type: 'info' | 'warning' | 'success' | 'error' } | null>(null);
  const [currentView, setCurrentView] = useState<AppView>('chat');
  const [settingsPage, setSettingsPage] = useState<SettingsPage>('account');
  const [responseStyle, setResponseStyle] = useState<ResponseStyle>('standard');
  
  // States for confirmation and deletion flows
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [showUpgradeConfirmModal, setShowUpgradeConfirmModal] = useState(false);
  const [showPaymentSuccessModal, setShowPaymentSuccessModal] = useState(false);
  const [pendingUpgrade, setPendingUpgrade] = useState<PlanTier | null>(null);
  const [showLegalModal, setShowLegalModal] = useState(false);
  
  // Ref for aborting stream
  const abortControllerRef = useRef<AbortController | null>(null);

  const handleLoginSuccess = useCallback((loggedInUser: User) => {
      setUser(loggedInUser);
      setShowUpgradeModal(false);
      if(!loggedInUser.isAnonymous) {
          setNotification({ message: `Welcome back, ${loggedInUser.fullName.split(' ')[0]}!`, type: 'success' });
      } else {
          const isNewGuest = loggedInUser.creditsBalance === ADMIN_CONFIG.GUEST_MESSAGE_LIMIT;
          if (isNewGuest) {
            setNotification({ message: `You are browsing as a guest.`, type: 'info' });
          }
      }
  }, []);
  
  const handleLogout = async (notify = false) => {
      await clearSession();
      setUser(null);
      setMessages([]);
      setSessions([]);
      setCurrentView('chat');
      if (notify) {
        setNotification({ message: "You have been logged out.", type: 'info' });
      }
  };

  const handleGuestLogin = useCallback(() => {
    const guestUser = loginAsGuest();
    saveSession(guestUser);
    handleLoginSuccess(guestUser);
  }, [handleLoginSuccess]);
  
  const handleGuestUpgradeAttempt = () => {
    setShowUpgradeModal(false);
    handleLogout(false);
  };


  useEffect(() => {
    const initAuth = async () => {
      try {
        const userData = await getUser();
        if (userData) {
          setUser(userData);
          // Check for pending upgrade recovery
          const savedPendingUpgrade = localStorage.getItem(PENDING_UPGRADE_KEY);
          if (savedPendingUpgrade && Object.values(PlanTier).includes(savedPendingUpgrade as PlanTier)) {
              setPendingUpgrade(savedPendingUpgrade as PlanTier);
          }
        } else {
           handleGuestLogin();
        }
      } catch (error) {
        console.error("Auth initialization error", error);
        handleGuestLogin();
      } finally {
        setIsLoading(false);
      }
    };
    initAuth();
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
            const userData = await getUser();
            if(userData) setUser(userData);
        } else if (event === 'SIGNED_OUT') {
            setUser(null);
        }
    });
    return () => subscription.unsubscribe();
  }, [handleGuestLogin]);

  // Realtime subscription for Profile Updates (Admin changes)
  useEffect(() => {
    if (!user || user.isAnonymous || !user.id) return;
    const channel = supabase.channel(`user_profile_${user.id}`).on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${user.id}`},
            (payload: any) => {
                setUser(currentUser => currentUser ? { 
                    ...currentUser, 
                    plan: payload.new.plan, 
                    creditsBalance: payload.new.credits_balance, 
                    isAdmin: payload.new.is_admin,
                    fullName: payload.new.full_name,
                    username: payload.new.username
                } : null);
                setNotification({ message: "Your account has been updated.", type: 'info' });
            }
        ).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id]);

  // Fetch and Subscribe to Chat Sessions
  useEffect(() => {
    if (!user || user.isAnonymous || !user.id) {
        setSessions([]);
        return;
    };

    const fetchUserSessions = async () => {
        try {
            const userSessions = await getSessions(user.id!);
            setSessions(userSessions);
        } catch (error: any) {
            console.error("Failed to fetch sessions", error);
            if (error?.code === '42P01') { // undefined_table
                 setNotification({ message: "System Update: Please run the database setup SQL.", type: 'warning' });
            }
        }
    };
    fetchUserSessions();

    const channel = supabase.channel(`chat_sessions_${user.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_sessions', filter: `user_id=eq.${user.id}` },
            (payload) => {
                if (payload.eventType === 'INSERT') {
                    setSessions(prev => [payload.new as ChatSession, ...prev]);
                } else if (payload.eventType === 'DELETE') {
                    setSessions(prev => prev.filter(s => s.id !== payload.old.id));
                }
            }
        ).subscribe();
    
    return () => { supabase.removeChannel(channel); };
  }, [user?.id]);

  // Listen for returning from payment tab
  useEffect(() => {
      const handleVisibilityChange = () => {
          if (document.visibilityState === 'visible' && pendingUpgrade) {
              setShowPaymentSuccessModal(true);
          }
      };
      document.addEventListener('visibilitychange', handleVisibilityChange);
      return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [pendingUpgrade]);


  const handleNewChat = async () => {
    if (messages.length > 0 && user && !user.isAnonymous) {
        const title = messages[0].content.substring(0, 30) + (messages[0].content.length > 30 ? '...' : '');
        const newSession: Omit<ChatSession, 'id' | 'createdAt'> = { title, messages: [...messages] };
        try {
            await createSession(newSession, user.id!);
        } catch(e) {
            setNotification({ message: 'Failed to save session.', type: 'error' });
        }
    }
    setMessages([]);
    setCurrentView('chat');
    setIsMobileMenuOpen(false);
  };

  const handleDeleteSession = async (sessionId: string) => {
      try {
        await deleteSession(sessionId);
        setNotification({ message: "Thread deleted.", type: 'info' });
      } catch (e) {
        setNotification({ message: "Failed to delete thread.", type: 'error' });
      }
  };

  const handleLoadSession = (sessionId: string) => {
      const session = sessions.find(s => s.id === sessionId);
      if (session) {
          setMessages(session.messages);
          setCurrentView('chat');
          setIsMobileMenuOpen(false);
      }
  };

  const handleOpenSettings = (page: SettingsPage = 'account') => {
      setSettingsPage(page);
      setCurrentView('settings');
      setIsMobileMenuOpen(false);
  };
  
  const initiateUpgrade = (planId: PlanTier) => {
    if (!user || user.isAnonymous) {
        setShowUpgradeModal(true);
        return;
    }
    setPendingUpgrade(planId);
    // Persist pending upgrade state in case of reload
    localStorage.setItem(PENDING_UPGRADE_KEY, planId);
    setShowUpgradeModal(false);
    setShowUpgradeConfirmModal(true);
  };
  
  const confirmAndPay = () => {
      if (!pendingUpgrade) return;
      setShowUpgradeConfirmModal(false);
      const url = paymentLinks[pendingUpgrade];
      if (url) {
          setNotification({ message: "Redirecting to payment... Do not press back.", type: 'info' });
          setTimeout(() => window.open(url, '_blank'), 1500);
      }
  };

  const finalizeUpgrade = async () => {
      if (!user || !pendingUpgrade) return;
      const planId = pendingUpgrade;
      const planDetails = PLANS[planId];
      
      // Optimistic Update: Immediately update UI
      const updatedUser: User = { 
          ...user, 
          plan: planId, 
          creditsBalance: user.creditsBalance + planDetails.initialCredits 
      };
      setUser(updatedUser);
      setShowPaymentSuccessModal(false);
      setNotification({ message: `Successfully upgraded to ${planDetails.name}!`, type: 'success' });
      
      // Clear pending state
      setPendingUpgrade(null);
      localStorage.removeItem(PENDING_UPGRADE_KEY);

      // Persist to Database
      try {
          await updateUser(updatedUser);
      } catch(e) {
          console.error("Failed to sync upgrade to DB", e);
          setNotification({ message: "Plan updated locally. DB sync failed.", type: 'warning' });
      }
  };

  const cancelPendingUpgrade = () => {
      setPendingUpgrade(null);
      localStorage.removeItem(PENDING_UPGRADE_KEY);
      setShowPaymentSuccessModal(false);
      setNotification({ message: "Upgrade process has been cancelled.", type: 'info' });
  };
  
  const handleUpdateUserDetails = async (updatedDetails: { fullName: string; username: string }) => {
    if (!user) return;
    const updatedUser = { ...user, ...updatedDetails };
    try {
        await updateUser(updatedUser);
        setUser(updatedUser);
        setNotification({ message: 'Account details updated!', type: 'success' });
    } catch(e) {
        setNotification({ message: 'Failed to update details.', type: 'error' });
    }
  };

  const handleDeleteAccount = async () => {
    if (!user || user.isAnonymous) return;
    try {
        await deleteUser(user.email);
        setShowDeleteConfirmModal(false);
        handleLogout(false); 
        setNotification({ message: 'Deletion request submitted. Your account will be processed.', type: 'info'});
    } catch (error) {
        console.error(error);
        setNotification({ message: 'Failed to submit deletion request.', type: 'error' });
    }
  };

  const handlePinMessage = (message: Message) => {
      setMessages(prev => prev.map(m => m.id === message.id ? { ...m, isPinned: !m.isPinned } : m));
      setNotification({ 
          message: message.isPinned ? "Message unpinned." : "Message pinned.", 
          type: 'info' 
      });
  };

  const getRequestType = (text: string): 'text' | 'image' | 'video' => {
      const lower = text.toLowerCase();
      if (lower.startsWith('generate image') || lower.startsWith('create an image')) return 'image';
      if (lower.startsWith('generate video') || lower.startsWith('create a video')) return 'video'; 
      return 'text';
  };

  const handleStopGeneration = () => {
      if (abortControllerRef.current) {
          abortControllerRef.current.abort();
          abortControllerRef.current = null;
          setIsStreaming(false);
          // Mark the last message as not thinking anymore
          setMessages(prev => prev.map(m => m.isThinking ? { ...m, isThinking: false, content: m.content + " [Stopped]" } : m));
      }
  };

  const handleSendMessage = useCallback(async (text: string, model: ModelType, attachments?: string[]) => {
    if (currentView !== 'chat') setCurrentView('chat');
    if (!user) return;
    
    const type = getRequestType(text);
    const plan = PLANS[user.plan];
    
    if (type === 'image' && !plan.allowImages) {
        setUpgradeReason("Upgrade your plan to generate images.");
        setShowUpgradeModal(true);
        return;
    }
    
    if (user.creditsBalance <= 0) {
        if (user.isAnonymous) {
            setUpgradeReason("Please sign up for a free account to continue chatting.");
        } else {
            setUpgradeReason("You've run out of credits. Please upgrade your plan to continue.");
            setNotification({ message: "You are out of credits for this month.", type: 'warning' });
        }
        setShowUpgradeModal(true);
        return;
    }

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: text, timestamp: Date.now(), images: attachments };
    const modelMsgId = (Date.now() + 1).toString();
    const modelMsg: Message = { id: modelMsgId, role: 'model', content: '', modelUsed: AVAILABLE_MODELS.find(m => m.id === model)?.label, timestamp: Date.now(), isThinking: true };

    setMessages(prev => [...prev, userMsg, modelMsg]);
    setIsStreaming(true);

    // Create AbortController
    const aborter = new AbortController();
    abortControllerRef.current = aborter;

    try {
      if (type === 'image') {
          const imageUrl = await generateImage(text);
          if (aborter.signal.aborted) return;
          setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: `Image generated for: "${text}"`, isThinking: false, images: [imageUrl] } : m));
      } else if (type === 'video') {
          const videoUrl = await generateVideo(text);
          if (aborter.signal.aborted) return;
          setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: `Video generated for: "${text}"`, isThinking: false, videos: [videoUrl] } : m));
      } else {
          const history = messages.slice(0, -2).map(m => ({ role: m.role, content: m.content }));
          let fullResponse = "";
          await generateResponseStream(text, model, history, (chunk) => {
              fullResponse += chunk;
              setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: fullResponse, isThinking: false } : m));
          }, responseStyle, attachments, aborter.signal);
          
          if (!aborter.signal.aborted) {
              generateRelatedQuestions(fullResponse).then(questions => {
                  setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, relatedQuestions: questions } : m));
              });
          }
      }
      
      const updatedUser = { ...user, creditsBalance: Math.max(0, user.creditsBalance - 1) };
      setUser(updatedUser);
      updateUser(updatedUser);

    } catch (error: any) {
      if (error.name === 'AbortError' || error.message?.includes('Aborted')) {
          console.log("Generation aborted by user");
          // State is handled in handleStopGeneration
      } else {
          console.error("Generation error", error);
          setMessages(prev => prev.map(m => m.id === modelMsgId ? { ...m, content: "An error occurred. Please try again.", isThinking: false } : m));
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  }, [user, messages, currentView, responseStyle]);

  if (isLoading) {
    return (
        <div className="flex items-center justify-center h-screen w-screen bg-gray-50 dark:bg-gray-900">
            <div className="w-8 h-8 border-4 border-vynto-red border-t-transparent rounded-full animate-spin"></div>
        </div>
    );
  }

  if (!user) {
    return <AuthPage onLoginSuccess={handleLoginSuccess} onSignupSuccess={(u) => {
        handleLoginSuccess(u);
        setNotification({ message: `Welcome! You have ${u.creditsBalance} credits.`, type: 'success' });
    }} />;
  }

  const renderContent = () => {
    switch(currentView) {
        case 'discover': return <DiscoverPage onPromptClick={(txt, model) => handleSendMessage(txt, model)} onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'library': return <LibraryPage user={user} onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'spaces': return <SpacesPage onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'contact': return <ContactPage onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'services': return <ServicesPage onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'admin':
            if (!user.isAdmin) return <div className="p-10">Access Denied</div>;
            return <AdminPanel onMenuClick={() => setIsMobileMenuOpen(true)} />;
        case 'settings':
            return (
                <SettingsLayout activePage={settingsPage} onNavigate={(p) => setSettingsPage(p as SettingsPage)} onHomeClick={() => setCurrentView('chat')} onMenuClick={() => setIsMobileMenuOpen(true)}>
                    {settingsPage === 'account' && <AccountPage user={user} onLogout={() => handleLogout(true)} onUpgradeClick={() => { setUpgradeReason("Upgrade your plan to unlock more features."); setShowUpgradeModal(true);}} onUpdateUser={handleUpdateUserDetails} onDeleteAccount={() => setShowDeleteConfirmModal(true)} />}
                    {settingsPage === 'models' && <AIModelsPage />}
                    {(settingsPage === 'api_access' || settingsPage === 'api_usage') && <div className="text-center p-8 text-gray-500">Coming Soon</div>}
                </SettingsLayout>
            );
        case 'chat':
        default:
             return (
                <div className="flex-1 flex flex-col relative h-full transition-all bg-white dark:bg-gray-900">
                    <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-30 pt-safe-top">
                        <button onClick={() => setIsMobileMenuOpen(true)} className="p-1.5 -ml-1.5"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg></button>
                        <div className="font-bold">VYNTO</div>
                        <button onClick={() => { setUpgradeReason("Upgrade your plan to unlock more features."); setShowUpgradeModal(true); }} className="text-xs bg-vynto-red text-white px-3 py-1.5 rounded-lg">Upgrade</button>
                    </div>
                    {messages.length === 0 ? (
                        <div className="flex-1 flex flex-col items-center justify-center p-4">
                            <h1 className="text-4xl font-medium mb-8">VYNTO AI</h1>
                            <InputArea 
                                onSend={handleSendMessage} 
                                isStreaming={isStreaming} 
                                onStop={handleStopGeneration} 
                                disabled={false} 
                                selectedModel={selectedModel} 
                                onModelChange={setSelectedModel} 
                                variant="centered" 
                                responseStyle={responseStyle} 
                                onResponseStyleChange={setResponseStyle} 
                                showSubscribe={user.plan === PlanTier.BASIC}
                                onSubscribeClick={() => { setUpgradeReason("Subscribe to unlock premium features."); setShowUpgradeModal(true); }}
                            />
                        </div>
                    ) : (
                        <>
                            <div className="flex-1 overflow-y-auto"><ChatArea messages={messages} isStreaming={isStreaming} onFollowUpClick={(q) => handleSendMessage(q, selectedModel)} onPinMessage={handlePinMessage} /></div>
                            <div className="fixed bottom-0 left-0 md:left-64 right-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm pb-safe-bottom z-20 border-t border-gray-100 dark:border-gray-800">
                                <div className="py-4">
                                    <InputArea 
                                        onSend={handleSendMessage} 
                                        isStreaming={isStreaming}
                                        onStop={handleStopGeneration}
                                        disabled={false} 
                                        selectedModel={selectedModel} 
                                        onModelChange={setSelectedModel} 
                                        variant="bottom" 
                                        responseStyle={responseStyle} 
                                        onResponseStyleChange={setResponseStyle} 
                                        showSubscribe={user.plan === PlanTier.BASIC}
                                        onSubscribeClick={() => { setUpgradeReason("Subscribe to unlock premium features."); setShowUpgradeModal(true); }}
                                    />
                                </div>
                            </div>
                        </>
                    )}
                </div>
             );
    }
  };

  return (
    <div className={`flex h-screen bg-gray-50 overflow-hidden font-sans text-gray-900 dark:text-gray-100 dark:bg-gray-900 w-full`}>
      {notification && <NotificationToast message={notification.message} type={notification.type} onClose={() => setNotification(null)} />}
      <Sidebar 
          user={user} 
          activeView={currentView} 
          onNavigate={(v) => { setCurrentView(v as AppView); setIsMobileMenuOpen(false); }} 
          onNewChat={handleNewChat} 
          onUpgradeClick={() => { setUpgradeReason("Upgrade your plan to unlock more features."); setShowUpgradeModal(true); }} 
          onSettingsClick={() => handleOpenSettings('account')} 
          onComingSoon={setComingSoonFeature} 
          sessions={sessions} 
          onDeleteSession={handleDeleteSession} 
          onLoadSession={handleLoadSession} 
          isOpen={isMobileMenuOpen} 
          onClose={() => setIsMobileMenuOpen(false)} 
          onLogout={() => handleLogout(true)} 
          onAccountClick={() => handleOpenSettings('account')} 
          onLegalClick={() => setShowLegalModal(true)}
      />
      <main className={`flex-1 flex flex-col md:ml-64 relative h-full transition-all w-full`}>{renderContent()}</main>
      <ComingSoonModal isOpen={!!comingSoonFeature} onClose={() => setComingSoonFeature(null)} featureName={comingSoonFeature || undefined} />
      <UpgradeModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} currentPlan={user.plan} onUpgrade={initiateUpgrade} message={upgradeReason} isGuest={user.isAnonymous} onGuestSignUpClick={handleGuestUpgradeAttempt} />
      <LegalModal isOpen={showLegalModal} onClose={() => setShowLegalModal(false)} />
      <ConfirmationModal
        isOpen={showDeleteConfirmModal}
        onClose={() => setShowDeleteConfirmModal(false)}
        onConfirm={handleDeleteAccount}
        title="Delete Account"
        message="Are you sure you want to delete your account? This action is permanent and cannot be undone."
        confirmText="Delete"
      />
      <ConfirmationModal
        isOpen={showUpgradeConfirmModal}
        onClose={() => setShowUpgradeConfirmModal(false)}
        onConfirm={confirmAndPay}
        title={`Confirm Upgrade to ${PLANS[pendingUpgrade!]?.name}`}
        message={`You will be redirected to our secure payment partner to complete your purchase. Do you want to continue?`}
        confirmText="Continue to Payment"
      />
      {pendingUpgrade && (
          <PaymentSuccessModal
            isOpen={showPaymentSuccessModal}
            onClose={finalizeUpgrade}
            onCancel={cancelPendingUpgrade}
            planName={PLANS[pendingUpgrade]?.name}
          />
      )}
    </div>
  );
}

export default App;