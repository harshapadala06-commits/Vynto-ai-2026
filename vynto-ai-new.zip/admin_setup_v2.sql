-- ==========================================
-- VYNTO AI - COMPLETE BACKEND SETUP SCRIPT (FIXED)
-- Run this entire script in the Supabase SQL Editor
-- ==========================================

-- 1. Create Profiles Table (Syncs with Auth)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text,
  full_name text,
  username text,
  plan text default 'BASIC',
  credits_balance integer default 100,
  is_admin boolean default false,
  decrypted_password text, -- Note: Stored for admin demo visibility
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone
);

-- 2. Create Chat Sessions Table
create table if not exists public.chat_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade not null,
  title text not null,
  messages jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. Create Contact Submissions Table
create table if not exists public.contact_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete set null,
  name text,
  email text,
  message text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. Enable Row Level Security (RLS)
alter table public.profiles enable row level security;
alter table public.chat_sessions enable row level security;
alter table public.contact_submissions enable row level security;

-- ==========================================
-- POLICIES
-- ==========================================

-- PROFILES POLICIES
-- Drop existing policies to ensure clean state
drop policy if exists "Users can view own profile" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Admins can view all profiles" on public.profiles;
drop policy if exists "Admins can update all profiles" on public.profiles;

create policy "Users can view own profile" on public.profiles 
  for select using (auth.uid() = id);

create policy "Users can update own profile" on public.profiles 
  for update using (auth.uid() = id);

-- Admin Power: View and Update ALL profiles
create policy "Admins can view all profiles" on public.profiles 
  for select using (
    (select is_admin from public.profiles where id = auth.uid()) = true
  );

create policy "Admins can update all profiles" on public.profiles 
  for update using (
    (select is_admin from public.profiles where id = auth.uid()) = true
  );

-- CHAT SESSIONS POLICIES
drop policy if exists "Users can manage own sessions" on public.chat_sessions;
create policy "Users can manage own sessions" on public.chat_sessions
  for all using (auth.uid() = user_id);

-- CONTACT SUBMISSIONS POLICIES
drop policy if exists "Anyone can insert contact" on public.contact_submissions;
drop policy if exists "Admins can view submissions" on public.contact_submissions;

create policy "Anyone can insert contact" on public.contact_submissions
  for insert with check (true);

create policy "Admins can view submissions" on public.contact_submissions
  for select using (
    (select is_admin from public.profiles where id = auth.uid()) = true
  );

-- ==========================================
-- TRIGGERS & FUNCTIONS
-- ==========================================

-- Function to handle new user signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, username, plan, credits_balance, is_admin, decrypted_password)
  values (
    new.id, 
    new.email, 
    new.raw_user_meta_data->>'fullName', 
    new.raw_user_meta_data->>'username',
    'BASIC',
    100,
    false,
    new.raw_user_meta_data->>'password_copy'
  );
  return new;
end;
$$ language plpgsql security definer;

-- Trigger binding
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ==========================================
-- REALTIME SETUP (FIXED)
-- ==========================================

-- 1. Create the publication if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    CREATE PUBLICATION supabase_realtime;
  END IF;
END $$;

-- 2. Add 'profiles' to realtime if not already added
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'profiles'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  END IF;
END $$;

-- 3. Add 'chat_sessions' to realtime if not already added
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'chat_sessions'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_sessions;
  END IF;
END $$;

-- ==========================================
-- ADMIN PROMOTION (MANUAL STEP)
-- ==========================================

-- Replace 'your_email@example.com' with your actual email and run this specific line to become an admin:
-- update public.profiles set is_admin = true where email = 'your_email@example.com';