-- ====================================================================
-- VYNTO AI - MASTER DATABASE SETUP SCRIPT
-- Purpose: This single script sets up everything your Supabase project needs.
--          It creates tables, sets permissions, and enables admin controls.
--
-- Instructions:
-- 1. Go to your Supabase project dashboard.
-- 2. Click on the "SQL Editor" icon in the left sidebar.
-- 3. Click "+ New query".
-- 4. Copy and paste this ENTIRE script into the editor.
-- 5. Click the "RUN" button.
--
-- NOTE: This script is the single source of truth for your database schema
--       and security. It is safe to run this script multiple times. If you
--       encounter any database errors (like "infinite recursion"), running
--       this script again will reset and fix the policies.
-- ====================================================================

-- === SECTION 1: TABLE & SCHEMA SETUP ===
-- Ensures all required tables and columns exist, adding them safely if they don't.

-- 1.1: Profiles Table (Master User Data)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text,
  full_name text,
  username text,
  plan text default 'BASIC',
  credits_balance integer default 100,
  is_admin boolean default false,
  account_status text default 'Active',
  decrypted_password text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone
);

-- 1.2: Add missing columns to Profiles table without causing errors
do $$
begin
  if not exists (select 1 from information_schema.columns where table_name = 'profiles' and column_name = 'account_status') then
    alter table public.profiles add column account_status text default 'Active';
  end if;
  if not exists (select 1 from information_schema.columns where table_name = 'profiles' and column_name = 'decrypted_password') then
    alter table public.profiles add column decrypted_password text;
  end if;
end $$;

-- 1.3: Chat Sessions Table
create table if not exists public.chat_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade not null,
  title text not null,
  messages jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 1.4: Contact Submissions Table
create table if not exists public.contact_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete set null,
  name text,
  email text,
  message text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- === SECTION 2: HELPER FUNCTIONS FOR RLS ===
-- Creates helper functions to avoid RLS recursion issues, which is a common problem.

-- 2.1: is_admin() function
-- **THE FIX FOR "INFINITE RECURSION" ERRORS LIVES HERE.**
-- This function checks if the currently authenticated user is an admin.
--
-- Why was it failing?
-- An RLS policy on the `profiles` table would call this function to check for admin
-- status. However, this function *also* needs to read the `profiles` table to
-- see if the `is_admin` flag is true. This creates a loop:
--   Policy -> calls is_admin() -> reads profiles -> triggers Policy -> loop
--
-- How does this fix it?
-- `SECURITY DEFINER` makes the function execute with the privileges of the user who
-- created it (the 'postgres' superuser), NOT the user calling it. Since the
-- superuser is not subject to RLS policies, the function can safely check the
-- `profiles` table without triggering the RLS policy again, thus breaking the loop.
-- `SET search_path = ''` is a security best practice to prevent potential hijacking.
create or replace function public.is_admin()
returns boolean as $$
begin
  return exists (
    select 1
    from public.profiles
    where id = auth.uid() and is_admin = true
  );
end;
$$ language plpgsql security definer set search_path = '';


-- === SECTION 3: ROW LEVEL SECURITY (RLS) RESET ===
-- This is the MOST CRITICAL section. It enables all permissions and admin controls.
-- It removes all old, potentially conflicting rules and applies a fresh, correct set.

-- 3.1: Enable RLS on all tables
alter table public.profiles enable row level security;
alter table public.chat_sessions enable row level security;
alter table public.contact_submissions enable row level security;

-- 3.2: Reset Policies for PROFILES table (ensures a clean slate)
drop policy if exists "Users can view own profile" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Users can insert own profile" on public.profiles;
drop policy if exists "Admins can view all profiles" on public.profiles;
drop policy if exists "Admins can update all profiles" on public.profiles;

-- 3.3: Re-create Correct Policies for PROFILES
create policy "Users can view own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "Admins can view all profiles" on public.profiles for select using (public.is_admin());
create policy "Admins can update all profiles" on public.profiles for update using (public.is_admin());

-- 3.4: Reset & Re-create Policies for CHAT SESSIONS
drop policy if exists "Users manage sessions" on public.chat_sessions;
create policy "Users manage sessions" on public.chat_sessions for all using (auth.uid() = user_id);

-- 3.5: Reset & Re-create Policies for CONTACT SUBMISSIONS
drop policy if exists "Anyone insert contact" on public.contact_submissions;
drop policy if exists "Admins view contact" on public.contact_submissions;
create policy "Anyone insert contact" on public.contact_submissions for insert with check (true);
create policy "Admins view contact" on public.contact_submissions for select using (public.is_admin());


-- === SECTION 4: AUTOMATION & TRIGGERS ===
-- Ensures a profile is automatically created when a new user signs up.

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, username, plan, credits_balance, is_admin, account_status, decrypted_password)
  values (
    new.id, 
    new.email, 
    new.raw_user_meta_data->>'fullName', 
    new.raw_user_meta_data->>'username',
    'BASIC',
    100,
    false,
    'Active',
    new.raw_user_meta_data->>'password_copy'
  )
  on conflict (id) do nothing; -- Prevents errors if row somehow already exists
  return new;
end;
$$ language plpgsql security definer;

-- Bind the function to the auth.users table
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- === SECTION 5: REALTIME & PERMISSIONS ===
-- Final cleanup to ensure everything is accessible and updates in realtime.

-- 5.1: Grant general permissions
grant usage on schema public to anon, authenticated, service_role;
grant all on all tables in schema public to anon, authenticated, service_role;
grant all on all sequences in schema public to anon, authenticated, service_role;

-- 5.2: Set up Realtime Publication
begin;
  drop publication if exists supabase_realtime;
  create publication supabase_realtime;
commit;
alter publication supabase_realtime add table public.profiles;
alter publication supabase_realtime add table public.chat_sessions;


-- === SCRIPT COMPLETE ===
-- You can now test your application. Login and profile updates should work correctly.
-- To make yourself an admin, run this command separately after you have signed up:
-- update public.profiles set is_admin = true where email = 'your-email@example.com';