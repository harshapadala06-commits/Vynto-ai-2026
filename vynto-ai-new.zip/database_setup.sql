-- Safe SQL script to set up Chat Sessions
-- Run this in the Supabase SQL Editor

-- 1. Create the table if it doesn't exist
create table if not exists public.chat_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade not null,
  title text not null,
  messages jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. Enable Row Level Security (RLS)
alter table public.chat_sessions enable row level security;

-- 3. Create RLS policies (Drop first to avoid conflicts if re-running)
drop policy if exists "Users can view their own sessions" on public.chat_sessions;
drop policy if exists "Users can insert their own sessions" on public.chat_sessions;
drop policy if exists "Users can update their own sessions" on public.chat_sessions;
drop policy if exists "Users can delete their own sessions" on public.chat_sessions;

create policy "Users can view their own sessions" on public.chat_sessions for select using (auth.uid() = user_id);
create policy "Users can insert their own sessions" on public.chat_sessions for insert with check (auth.uid() = user_id);
create policy "Users can update their own sessions" on public.chat_sessions for update using (auth.uid() = user_id);
create policy "Users can delete their own sessions" on public.chat_sessions for delete using (auth.uid() = user_id);

-- 4. Enable Realtime
do $$
begin
  if not exists (
    select 1 from pg_publication_tables 
    where pubname = 'supabase_realtime' 
    and schemaname = 'public' 
    and tablename = 'chat_sessions'
  ) then
    alter publication supabase_realtime add table public.chat_sessions;
  end if;
end $$;
