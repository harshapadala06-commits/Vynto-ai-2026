export enum PlanTier {
  BASIC = 'BASIC',
  STANDARD = 'STANDARD',
  PREMIUM = 'PREMIUM',
  ADVANCED = 'ADVANCED'
}

export enum ModelType {
  CHATGPT = 'ChatGPT',
  GEMINI = 'Gemini',
  CLAUDE = 'Claude',
  GROK = 'Grok'
}

export type AccountStatus = 'Active' | 'Blocked';
export type ResponseStyle = 'concise' | 'standard' | 'detailed';

export interface Plan {
  id: PlanTier;
  name: string;
  price: string;
  originalPrice?: string;
  initialCredits: number;
  allowImages: boolean;
  features: string[];
  isPopular?: boolean;
  models?: ModelType[];
}

// Represents the user data model stored in localStorage
export interface User {
  id?: string; // UUID from Supabase
  fullName: string;
  username: string;
  email: string;
  password?: string; // Stored only for local auth simulation
  plan: PlanTier;
  accountStatus: AccountStatus;
  creditsBalance: number; 
  isAnonymous?: boolean;
  isAdmin?: boolean; // Admin flag
}

// Represents the session data stored in localStorage
export interface Session {
  email: string;
  loginTime: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  modelUsed?: string;
  timestamp: number;
  isThinking?: boolean;
  sources?: Array<{ title: string; uri: string }>;
  relatedQuestions?: string[];
  images?: string[]; 
  videos?: string[]; 
  isPinned?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}