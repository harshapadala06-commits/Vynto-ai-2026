# VYNTO AI - Professional AI Workspace

VYNTO AI is a full-stack, enterprise-grade AI SaaS platform designed with a professional, answer-first interface similar to Perplexity. It supports multi-model routing, allowing users to switch between powerful AI models like GPT-4o, Gemini Pro, and Claude 3.5 Sonnet.

The platform is presented by **V STORE**, an e-commerce brand, and features secure payment integration with **Razorpay** for its tiered subscription plans.

## Key Features
- **Multi-Model Support:** Seamlessly switch between different AI models for various tasks.
- **Guest Mode:** Try the application with a limited number of credits before signing up.
- **Tiered Subscriptions:** Freemium model with multiple paid plans to unlock advanced features, more credits, and image/video generation.
- **User Account Management:** Edit your user details and delete your account.
- **Professional UI/UX:** Clean, responsive, and intuitive interface designed for productivity.
- **Rich Media Generation:** Create images and videos directly from prompts.

## Deployment

### Replit (Manual Setup)
1.  **Import:** Import this repo into Replit.
2.  **Secrets:** Open the **Secrets (Lock Icon)** tool in the Replit sidebar.
3.  **Add Keys:** Add the following secrets manually:
    *   `API_KEY`: Your Google Gemini API Key.
    *   `VITE_SUPABASE_URL`: Your Supabase Project URL.
    *   `VITE_SUPABASE_ANON_KEY`: Your Supabase Anon/Public Key.
4.  **Run:** Click the big green **Run** button. The app will start in the webview.

### Vercel
1.  **Import:** Import this repository into Vercel.
2.  **Environment Variables:** Add the same variables (`API_KEY`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) in the Vercel Project Settings.
3.  **Deploy:** Vercel will automatically detect Vite and deploy.

**Note on Database:** Ensure you have run the SQL scripts located in `supabase_setup.sql` in your Supabase SQL Editor to set up the necessary tables (profiles, chat_sessions, etc.).
