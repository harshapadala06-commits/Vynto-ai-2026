# VYNTO AI - Professional AI Workspace

VYNTO AI is a full-stack, enterprise-grade AI SaaS platform designed with a professional, answer-first interface similar to Perplexity. It supports multi-model routing, allowing users to switch between powerful AI models like GPT-4o, Gemini Pro, and Claude 3.5 Sonnet.

The platform is presented by **V STORE**, an e-commerce brand, and features secure payment integration with **Razorpay** for its tiered subscription plans.

## Key Features
- **Multi-Model Support:** Seamlessly switch between different AI models for various tasks.
- **Guest Mode:** Try the application with a limited number of credits before signing up.
- **Tiered Subscriptions:** Freemium model with multiple paid plans to unlock advanced features, more credits, and image/video generation.
- **User Account Management:** Edit your user details and delete your account.
- **Professional UI/UX:** Clean, responsive, and intuitive interface designed for productivity.
- **Rich Media Generation:** Create images and videos directly from prompts.

## 🚀 Quick Start & Setup

### Step 1: Configure API Keys (Most Important!)
The application will not work without valid API keys. You have two options:

**Option A: (Recommended for Local Development)**
1.  Open the file: `services/apiKeys.ts`
2.  Paste your actual keys to replace the placeholder strings:
    ```ts
    export const ApiKeys = {
      GEMINI_API_KEY: "YOUR_GEMINI_API_KEY_HERE",
      SUPABASE_URL: "https://<your-project-ref>.supabase.co",
      SUPABASE_ANON_KEY: "ey...",
    };
    ```

**Option B: (Recommended for Deployment on Vercel/Netlify)**
1.  Go to your Vercel or Netlify project dashboard.
2.  Navigate to **Settings -> Environment Variables**.
3.  Add the following variables:
    *   `API_KEY`: Your Google Gemini API Key.
    *   `VITE_SUPABASE_URL`: Your Supabase Project URL.
    *   `VITE_SUPABASE_ANON_KEY`: Your Supabase Anon/Public Key.

> **Error?** If you see a "Backend not configured" screen, it means your keys are missing or incorrect. Please double-check them.

### Step 2: Set Up the Database
To enable all features and fix login or data access errors, you must run the master database setup script.

1.  Go to your **Supabase Project Dashboard**.
2.  Click on the **SQL Editor** in the left sidebar.
3.  Open the `database_setup.sql` file from this project. This is the **only** script you need to run.
4.  **Copy the entire contents** of the file and paste it into the Supabase SQL Editor.
5.  Click the **Run** button.

> **Note:** It is safe to run this script multiple times. If you encounter any database-related errors, running this script again will reset and apply the correct policies and functions.

### Step 3: Run the Application
You can now run the application locally or deploy it. It should connect to your backend successfully.

---

## 🔧 Troubleshooting

### Error: "infinite recursion detected in policy for relation 'profiles'"
This is the most common setup error and is caused by incorrect security policies on your database.

**Solution:**
The fix is simple: **re-run the `database_setup.sql` script** in your Supabase SQL Editor.

This script is designed to be run multiple times. It will safely drop the old, broken policies and create the correct new ones, instantly fixing the error. This is the only step required to solve this issue.