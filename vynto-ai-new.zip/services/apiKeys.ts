// ==================================================================================
// 🔐 SECURITY & CONFIGURATION CENTER
// ==================================================================================
//
// INSTRUCTIONS:
// 1. Your Gemini Key is already set below.
// 2. You still need to paste your Supabase URL and Key if you want Login/History to work.
//
// ==================================================================================

export const ApiKeys = {
  // 1. GOOGLE GEMINI API KEY
  GEMINI_API_KEY: "AIzaSyACeepG8GBu_75M_PWO7Ze9Z6E7efizT5g",

  // 2. SUPABASE URL
  // Get it here: https://supabase.com/dashboard/project/_/settings/api
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_URL_HERE",

  // 3. SUPABASE ANON KEY (Public)
  // Get it here: https://supabase.com/dashboard/project/_/settings/api
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};