// ==================================================================================
// 🔐 SECURITY & CONFIGURATION CENTER
// ==================================================================================
//
// INSTRUCTIONS:
// This file is for local development convenience. For production (Vercel, Netlify),
// it is STRONGLY RECOMMENDED to use environment variables instead.
// The app will automatically fall back to environment variables if these are placeholders.
//
// 1. (Optional) Paste your keys here for quick local testing.
// 2. (Recommended) Or, create a `.env` file in the root directory and add your keys:
//    VITE_GEMINI_API_KEY=your_gemini_key
//    VITE_SUPABASE_URL=your_supabase_url
//    VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
//
// ==================================================================================

export const ApiKeys = {
  // 1. GOOGLE GEMINI API KEY
  GEMINI_API_KEY: "PASTE_YOUR_GEMINI_API_KEY_HERE",

  // 2. SUPABASE URL
  SUPABASE_URL: "https://caoyuhuwohibybqrarcc.supabase.co",

  // 3. SUPABASE ANON KEY (Public)
  SUPABASE_ANON_KEY: "sb_publishable_S00yjrikMWx0bd1RHrg9Pw_XK5dukze"
};