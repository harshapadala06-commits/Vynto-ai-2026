import { Session, User, PlanTier } from '../types';
import { PLANS, ADMIN_CONFIG } from '../constants';
import { supabase, isSupabaseConfigured } from './supabaseClient';

const GUEST_USER_KEY = 'vynto_guest_user';

// Helper to map DB Profile to App User
const mapProfileToUser = (profile: any): User => {
    return {
        id: profile.id,
        email: profile.email,
        fullName: profile.full_name || 'User',
        username: profile.username || 'user',
        plan: profile.plan as PlanTier,
        accountStatus: profile.account_status || 'Active',
        creditsBalance: profile.credits_balance ?? 0,
        isAnonymous: false,
        isAdmin: profile.is_admin || false,
        password: profile.decrypted_password
    };
};

// Centralized function to get and self-heal a profile
const getProfileById = async (userId: string, authUser?: any): Promise<any | null> => {
    try {
        const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', userId)
            .single();

        if (profile) {
            return profile;
        }

        if (error) {
            // If row is missing (PGRST116), and we have the auth user object, attempt self-healing
            if (error.code === 'PGRST116' && authUser) {

                const createdAt = new Date(authUser.created_at);
                const now = new Date();
                const ageInSeconds = (now.getTime() - createdAt.getTime()) / 1000;

                // SAFETY CHECK: Only self-heal if the user account is new.
                // This targets the signup race condition without affecting existing users with data issues.
                // Increased from 60s to 300s (5 minutes) to be more robust.
                if (ageInSeconds < 300) {
                    console.warn("Profile not found for new user, attempting recovery for user:", userId);
                    const metadata = authUser.user_metadata || {};
                    const { data: newProfile, error: createError } = await supabase
                        .from('profiles')
                        .insert([{
                            id: authUser.id,
                            email: authUser.email,
                            full_name: metadata.fullName || authUser.email?.split('@')[0] || 'User',
                            username: metadata.username || authUser.email?.split('@')[0] || 'user',
                            plan: 'BASIC',
                            credits_balance: 100,
                            account_status: 'Active',
                            decrypted_password: metadata.password_copy || null
                        }])
                        .select()
                        .single();
                    
                    if (createError) {
                        console.error("Critical: Failed to recover profile during self-heal.", createError);
                        return null; // Self-healing failed
                    }
                    
                    console.log("Profile recovery successful for new user.");
                    return newProfile; // Return the newly created profile
                } else {
                    // For older accounts, a missing profile is a critical data issue.
                    // We must NOT create a new basic profile, as it would wipe their subscription.
                    console.error(`CRITICAL: Profile is missing for an existing user (ID: ${userId}, created at: ${authUser.created_at}). Login is blocked to prevent data loss.`);
                    return null;
                }

            } else {
                // For other errors, log it and return null to allow retry
                console.error(`Profile fetch error for user ${userId}:`, error.message);
                return null;
            }
        }
        return null; // Should not be reached, but for safety.
    } catch (e: any) {
        console.error("Exception in getProfileById:", e.message);
        return null;
    }
};

export const loginAsGuest = (): User => {
    const storedGuest = localStorage.getItem(GUEST_USER_KEY);
    if (storedGuest) {
      return JSON.parse(storedGuest);
    }
    const guestUser: User = {
        id: 'guest-' + Date.now(),
        fullName: 'Guest User',
        username: 'guest',
        email: `guest-${Date.now()}@example.com`,
        plan: PlanTier.BASIC,
        accountStatus: 'Active',
        creditsBalance: ADMIN_CONFIG.GUEST_MESSAGE_LIMIT,
        isAnonymous: true,
        isAdmin: false
    };
    localStorage.setItem(GUEST_USER_KEY, JSON.stringify(guestUser));
    return guestUser;
}

export const getUser = async (): Promise<User | null> => {
    if (!isSupabaseConfigured) {
        return loginAsGuest();
    }

    try {
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError || !session || !session.user) {
             return null;
        }
        
        const profile = await getProfileById(session.user.id, session.user);
        
        if (profile) {
            return mapProfileToUser(profile);
        }
        
        return null;
        
    } catch (error) {
        console.warn("Auth check failed, defaulting to guest", error);
        return loginAsGuest();
    }
};

export const signup = async (payload: Omit<User, 'plan' | 'accountStatus' | 'creditsBalance' | 'isAnonymous'>): Promise<User> => {
  if (!isSupabaseConfigured) throw new Error("Backend not configured. Please use Guest Mode.");

  const initialData = {
    fullName: payload.fullName,
    username: payload.username,
    plan: PlanTier.BASIC,
    accountStatus: 'Active',
    creditsBalance: PLANS[PlanTier.BASIC].initialCredits,
    password_copy: payload.password 
  };

  const { data, error } = await supabase.auth.signUp({
    email: payload.email,
    password: payload.password!,
    options: {
      data: initialData
    }
  });

  if (error) throw new Error(error.message);
  if (!data.user) throw new Error('Signup failed.');

  localStorage.removeItem(GUEST_USER_KEY);
  
  // Return a provisional user object
  return { 
      ...payload,
      id: data.user.id,
      plan: PlanTier.BASIC,
      accountStatus: 'Active',
      creditsBalance: PLANS[PlanTier.BASIC].initialCredits,
      isAnonymous: false,
      isAdmin: false
  } as User;
};

export const login = async (email, password): Promise<User> => {
  if (!isSupabaseConfigured) throw new Error("Backend not configured. Please use Guest Mode.");

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw new Error(error.message);
  if (!data.user) throw new Error('Login failed.');

  const authUser = data.user;

  let profile = null;
  let retries = 5; 
  
  while (!profile && retries > 0) {
      profile = await getProfileById(authUser.id, authUser);
      if (profile) break;
      await new Promise(r => setTimeout(r, 1000));
      retries--;
  }

  if (!profile) {
      await supabase.auth.signOut();
      throw new Error('Profile load failed. Please try logging in again.');
  }
  
  return mapProfileToUser(profile);
};

export const requestPasswordReset = async (email: string) => {
    if (!isSupabaseConfigured) throw new Error("Backend not configured.");
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin,
    });
    if (error) throw new Error(error.message);
};

export const loginWithGoogle = async (): Promise<void> => {
    if (!isSupabaseConfigured) throw new Error("Backend not configured.");
    const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo: window.location.origin }
    });
    if (error) throw error;
}

export const loginWithFacebook = async (): Promise<void> => {
    if (!isSupabaseConfigured) throw new Error("Backend not configured.");
    const { error } = await supabase.auth.signInWithOAuth({
        provider: 'facebook',
        options: { redirectTo: window.location.origin }
    });
    if (error) throw error;
}

export const updateUser = async (updatedUser: User) => {
    if (updatedUser.isAnonymous) {
        localStorage.setItem(GUEST_USER_KEY, JSON.stringify(updatedUser));
        return;
    }
    
    if (!isSupabaseConfigured || !updatedUser.id) return;

    const { error } = await supabase.from('profiles').update({
        full_name: updatedUser.fullName,
        username: updatedUser.username,
        plan: updatedUser.plan,
        account_status: updatedUser.accountStatus,
        credits_balance: updatedUser.creditsBalance
    }).eq('id', updatedUser.id);
    
    if (error) {
        console.error("Update user failed", error);
        throw new Error(error.message || "Failed to update profile");
    }
};

export const deleteUser = async (email: string) => {
    if (isSupabaseConfigured) await supabase.auth.signOut();
    localStorage.removeItem(GUEST_USER_KEY);
};

export const getAllUsers = async (): Promise<User[]> => {
    if (!isSupabaseConfigured) return [];
    const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
    if (error) throw new Error(error.message);
    return (data || []).map(mapProfileToUser);
};

export const adminUpdateUser = async (userId: string, updates: Partial<User>) => {
    if (!isSupabaseConfigured) return;
    
    const dbUpdates: any = {};
    if (updates.plan) dbUpdates.plan = updates.plan;
    if (updates.creditsBalance !== undefined) dbUpdates.credits_balance = updates.creditsBalance;
    if (updates.fullName) dbUpdates.full_name = updates.fullName;
    if (updates.username) dbUpdates.username = updates.username;
    if (updates.accountStatus) dbUpdates.account_status = updates.accountStatus;
    
    const { error } = await supabase.from('profiles').update(dbUpdates).eq('id', userId);
    
    if (error) throw new Error(error.message);
};

export const saveSession = (userData: User) => {
    if(userData.isAnonymous) { }
};

export const getSession = (): Session | null => { return null; };

export const clearSession = async () => {
    try {
        if (isSupabaseConfigured) {
            await supabase.auth.signOut();
        }
    } catch (e) {
        console.warn("Supabase signout warning:", e);
    } finally {
        localStorage.removeItem(GUEST_USER_KEY);
        localStorage.removeItem('sb-access-token');
        localStorage.removeItem('sb-refresh-token');
    }
};