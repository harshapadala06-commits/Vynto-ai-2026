import { Session, User, PlanTier } from '../types';
import { PLANS, ADMIN_CONFIG } from '../constants';
import { supabase } from './supabaseClient';

const GUEST_USER_KEY = 'vynto_guest_user';

// Helper to map Supabase User Metadata (fallback) to App User
const mapMetadataToUser = (sbUser: any): User => {
  const metadata = sbUser.user_metadata || {};
  return {
    id: sbUser.id,
    email: sbUser.email || '',
    fullName: metadata.fullName || 'User',
    username: metadata.username || 'user',
    plan: metadata.plan || PlanTier.BASIC,
    accountStatus: metadata.accountStatus || 'Active',
    creditsBalance: metadata.creditsBalance !== undefined ? metadata.creditsBalance : PLANS[PlanTier.BASIC].initialCredits,
    isAnonymous: false,
    isAdmin: false
  };
};

// Helper to map DB Profile to App User
const mapProfileToUser = (profile: any): User => {
    return {
        id: profile.id,
        email: profile.email,
        fullName: profile.full_name,
        username: profile.username,
        plan: profile.plan as PlanTier,
        accountStatus: 'Active',
        creditsBalance: profile.credits_balance,
        isAnonymous: false,
        isAdmin: profile.is_admin,
        password: profile.decrypted_password // Map the stored password for Admin View
    };
};

export const signup = async (payload: Omit<User, 'plan' | 'accountStatus' | 'creditsBalance' | 'isAnonymous'>): Promise<User> => {
  const initialData = {
    fullName: payload.fullName,
    username: payload.username,
    plan: PlanTier.BASIC,
    accountStatus: 'Active',
    creditsBalance: PLANS[PlanTier.BASIC].initialCredits,
    // SECURITY WARNING: We are saving a copy of the password to metadata so the Trigger can save it to the profiles table.
    password_copy: payload.password 
  };

  const { data, error } = await supabase.auth.signUp({
    email: payload.email,
    password: payload.password!,
    options: {
      data: initialData
    }
  });

  if (error) throw new Error(error.message);
  if (!data.user) throw new Error('Signup failed.');

  // Clear any existing guest session
  localStorage.removeItem(GUEST_USER_KEY);
  
  // Return basic user object immediately, real profile is created by trigger async
  return { ...mapMetadataToUser(data.user), ...payload } as User;
};

export const login = async (email, password): Promise<User> => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw new Error(error.message);
  if (!data.user) throw new Error('Login failed.');

  // We rely on getUser() to fetch the full profile with roles
  const user = await getUser();
  if (!user) throw new Error('Failed to load user profile.');
  return user;
};

export const requestPasswordReset = async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin,
    });
    if (error) throw new Error(error.message);
};

export const loginWithGoogle = async (): Promise<void> => {
    const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
            redirectTo: window.location.origin
        }
    });
    if (error) throw error;
    // No return needed, browser redirects
}

export const loginWithFacebook = async (): Promise<void> => {
    const { error } = await supabase.auth.signInWithOAuth({
        provider: 'facebook',
        options: {
            redirectTo: window.location.origin
        }
    });
    if (error) throw error;
    // No return needed, browser redirects
}

export const loginAsGuest = (): User => {
    const storedGuest = localStorage.getItem(GUEST_USER_KEY);
    if (storedGuest) {
      return JSON.parse(storedGuest);
    }
    const guestUser: User = {
        id: 'guest-' + Date.now(),
        fullName: 'Guest User',
        username: 'guest',
        email: `guest-${Date.now()}@example.com`,
        plan: PlanTier.BASIC,
        accountStatus: 'Active',
        creditsBalance: ADMIN_CONFIG.GUEST_MESSAGE_LIMIT,
        isAnonymous: true,
        isAdmin: false
    };
    localStorage.setItem(GUEST_USER_KEY, JSON.stringify(guestUser));
    return guestUser;
}

export const getUser = async (): Promise<User | null> => {
    // Check Supabase Session first
    const { data: { session } } = await supabase.auth.getSession();
    
    if (session?.user) {
        // Fetch detailed profile from 'profiles' table
        const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();
            
        if (profile) {
            return mapProfileToUser(profile);
        }
        
        // Fallback to metadata if profile doesn't exist yet (race condition on signup or old users)
        return mapMetadataToUser(session.user);
    }

    // Fallback to Guest
    const storedGuest = localStorage.getItem(GUEST_USER_KEY);
    if (storedGuest) {
        return JSON.parse(storedGuest);
    }
    
    return null;
};

export const updateUser = async (updatedUser: User) => {
    if (updatedUser.isAnonymous) {
        localStorage.setItem(GUEST_USER_KEY, JSON.stringify(updatedUser));
        return;
    }
    
    // Update 'profiles' table
    if (updatedUser.id) {
        const { error } = await supabase.from('profiles').update({
            full_name: updatedUser.fullName,
            username: updatedUser.username,
            plan: updatedUser.plan,
            credits_balance: updatedUser.creditsBalance
        }).eq('id', updatedUser.id);

        if (error) {
            // Fallback to updating metadata if profile update fails (e.g. RLS issue)
             await supabase.auth.updateUser({
                data: {
                    fullName: updatedUser.fullName,
                    username: updatedUser.username,
                    plan: updatedUser.plan,
                    creditsBalance: updatedUser.creditsBalance
                }
            });
        }
    }
};

export const deleteUser = async (email: string) => {
    await supabase.auth.signOut();
    localStorage.removeItem(GUEST_USER_KEY);
};


// --- ADMIN FUNCTIONS ---

export const getAllUsers = async (): Promise<User[]> => {
    const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
        
    if (error) throw new Error(error.message);
    
    return (data || []).map(mapProfileToUser);
};

export const adminUpdateUser = async (userId: string, updates: Partial<User>) => {
    const dbUpdates: any = {};
    if (updates.plan) dbUpdates.plan = updates.plan;
    if (updates.creditsBalance !== undefined) dbUpdates.credits_balance = updates.creditsBalance;
    if (updates.fullName) dbUpdates.full_name = updates.fullName;
    if (updates.username) dbUpdates.username = updates.username;
    
    const { error } = await supabase
        .from('profiles')
        .update(dbUpdates)
        .eq('id', userId);
        
    if (error) throw new Error(error.message);
};

// --- SESSION MANAGEMENT ---

export const saveSession = (userData: User) => {
    if(userData.isAnonymous) {
       // handled locally
    }
};

export const getSession = (): Session | null => {
   return null; 
};

export const clearSession = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem(GUEST_USER_KEY);
};