import { createClient } from '@supabase/supabase-js';
import { ApiKeys } from './apiKeys';

// Helper to determine the valid configuration
const getSupabaseConfig = () => {
  let url = ApiKeys.SUPABASE_URL;
  let key = ApiKeys.SUPABASE_ANON_KEY;

  // Check if hardcoded keys are valid (not placeholders)
  const isUrlValid = url && !url.includes("PASTE_YOUR");
  const isKeyValid = key && !key.includes("PASTE_YOUR");

  // Fallback to Env Vars if hardcoded ones are invalid
  if (!isUrlValid) {
    url = (import.meta as any).env?.VITE_SUPABASE_URL || "";
  }
  if (!isKeyValid) {
    key = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || "";
  }

  // Final Safety Check for Empty Strings
  // If we still don't have a URL, provide a dummy one so the app renders
  if (!url || url.includes("PASTE_YOUR")) {
    console.warn("⚠️ Supabase URL missing. Authentication will not work. Check services/apiKeys.ts");
    url = "https://placeholder.supabase.co"; 
  }
  if (!key || key.includes("PASTE_YOUR")) {
    console.warn("⚠️ Supabase Key missing.");
    key = "placeholder-key";
  }

  return { url, key };
};

const config = getSupabaseConfig();

export const supabase = createClient(config.url, config.key);
