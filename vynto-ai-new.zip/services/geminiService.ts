import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ModelType, ResponseStyle } from "../types";
import { ApiKeys } from "./apiKeys";

// Helper to safely get the key or fallback to env var
const getApiKey = (): string => {
  // 1. Check Hardcoded Key in apiKeys.ts
  if (ApiKeys.GEMINI_API_KEY && !ApiKeys.GEMINI_API_KEY.includes("PASTE_YOUR")) {
    return ApiKeys.GEMINI_API_KEY;
  }
  
  // 2. Check Environment Variable (Vite injection)
  if (typeof process !== 'undefined' && process.env.API_KEY) {
    return process.env.API_KEY;
  }

  // 3. Check import.meta.env (Standard Vite)
  if ((import.meta as any).env?.VITE_GEMINI_API_KEY) {
    return (import.meta as any).env.VITE_GEMINI_API_KEY;
  }

  return ""; // Return empty to trigger specific error handling downstream
};

// Helper to map UI model selection to actual Gemini models for the demo
const mapModelToGemini = (uiModel: ModelType, isImageRequest: boolean): string => {
  if (isImageRequest) {
    return 'gemini-2.5-flash-image';
  }
  switch (uiModel) {
    case ModelType.GEMINI:
      return 'gemini-3-pro-preview';
    case ModelType.CHATGPT:
      return 'gemini-3-flash-preview'; // Simulating standard fast response
    case ModelType.CLAUDE:
      return 'gemini-3-pro-preview'; // Simulating reasoning model
    case ModelType.GROK:
      return 'gemini-3-flash-preview'; // Simulating fast/witty
    default:
      return 'gemini-3-flash-preview';
  }
};

const getSystemInstruction = (model: ModelType, style: ResponseStyle): string => {
  let base = "You are VYNTO AI, an enterprise-grade AI assistant. Your responses MUST be structured, accurate, and professional. Adhere to the following formatting rules strictly:\n1. Use Markdown for formatting.\n2. Start with a clear, bolded heading for the main topic (e.g., \"**Definition of Photosynthesis**\").\n3. Provide a concise, answer-first definition or summary directly under the main heading.\n4. Use additional bolded subheadings for structure (e.g., \"**Key Points**\", \"**Why it Matters**\").\n5. Use bullet points (using a hyphen, e.g., \"- Occurs in the **chloroplasts**...\") for lists to ensure high readability.\n6. **Bold** all critical keywords, concepts, and entities within sentences for emphasis (e.g., \"...convert **light energy** into **chemical energy**.\").\n7. Keep paragraphs short and focused.\n8. Avoid conversational fluff, personal opinions, and emojis. Your tone is academic and professional.";

  // Style adjustments can append to these strict rules
  switch (style) {
      case 'concise':
          return base + "\n9. Be extremely brief and direct. Use bullet points over paragraphs where possible.";
      case 'detailed':
          return base + "\n9. Provide comprehensive, in-depth explanations. Cover all relevant aspects and provide examples.";
      case 'standard':
      default:
          return base; // The base is already a well-balanced standard style.
  }
};


export const generateResponseStream = async (
  prompt: string,
  modelType: ModelType,
  history: { role: string; content: string }[],
  onChunk: (text: string) => void,
  responseStyle: ResponseStyle = 'standard',
  images?: string[],
  signal?: AbortSignal
): Promise<string> => {
  const apiKey = getApiKey();
  
  if (!apiKey) {
      const errorMsg = "⚠️ **API Key Missing**: Please open `services/apiKeys.ts` and paste your Google Gemini API Key.";
      onChunk(errorMsg);
      return errorMsg;
  }
  
  const ai = new GoogleGenAI({ apiKey });
  const modelId = mapModelToGemini(modelType, false);

  const chat = ai.chats.create({
    model: modelId,
    config: {
      systemInstruction: getSystemInstruction(modelType, responseStyle),
    },
    history: history.map(h => ({
      role: h.role,
      parts: [{ text: h.content }]
    }))
  });

  let fullText = "";
  try {
    let messageContent: any = { role: 'user', parts: [{ text: prompt }] };
    
    if (images && images.length > 0) {
        const imageParts = images.map(img => {
            // Remove data:image/xxx;base64, prefix
            const base64Data = img.split(',')[1];
            const mimeType = img.split(';')[0].split(':')[1];
            return { inlineData: { mimeType, data: base64Data } };
        });
        messageContent.parts.push(...imageParts);
    }

    // `chat.sendMessageStream` expects the content (string or Part array) directly
    const messageToSend = messageContent.parts.length > 1 ? messageContent.parts : prompt;
    const resultStream = await chat.sendMessageStream({ message: messageToSend });
    
    for await (const chunk of resultStream) {
      if (signal?.aborted) {
         throw new DOMException('Aborted', 'AbortError');
      }
      const c = chunk as GenerateContentResponse;
      const text = c.text || "";
      fullText += text;
      onChunk(text);
    }
  } catch (error: any) {
    if (error.name === 'AbortError' || error.message?.includes('Aborted')) {
        throw error; // Re-throw abort errors to be handled by caller
    }
    console.error("Gemini API Error:", error);
    
    // Provide a user-friendly error message in the chat
    if (error.message?.includes("API_KEY")) {
         const msg = "\n\n**Error**: Invalid API Key. Please check `services/apiKeys.ts`.";
         onChunk(msg);
         return fullText + msg;
    }
    
    throw error;
  }
  return fullText;
};

export const generateImage = async (prompt: string): Promise<string> => {
   const apiKey = getApiKey();
   if (!apiKey) throw new Error("API Key missing in services/apiKeys.ts");

   const ai = new GoogleGenAI({ apiKey });
   
   try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [{ text: prompt }]
        },
        config: {
            imageConfig: {
                aspectRatio: "1:1",
            }
        }
      });
      
      // Iterate to find image part
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData && part.inlineData.data) {
                return `data:image/png;base64,${part.inlineData.data}`;
            }
        }
      }
      throw new Error("No image data returned from model");
   } catch (e) {
     console.error("Image generation failed", e);
     // Fallback for "workable" demo if API fails
     const keywords = prompt.split(' ').slice(0, 3).join(',');
     return `https://source.unsplash.com/random/1024x1024/?${keywords}`;
   }
};

export const generateVideo = async (prompt: string): Promise<string> => {
    const apiKey = getApiKey();
    if (!apiKey) throw new Error("API Key missing in services/apiKeys.ts");

    const ai = new GoogleGenAI({ apiKey });
    
    try {
       let operation = await ai.models.generateVideos({
         model: 'veo-3.1-fast-generate-preview',
         prompt: prompt,
         config: {
           numberOfVideos: 1,
           resolution: '720p', 
           aspectRatio: '16:9'
         }
       });
 
       // Polling mechanism
       while (!operation.done) {
         await new Promise(resolve => setTimeout(resolve, 10000)); // Poll every 10s
         operation = await ai.operations.getVideosOperation({operation: operation});
       }
 
       const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
       if (downloadLink) {
         // The response.body contains the MP4 bytes. Need to proxy or use blob. 
         // For browser playback, usually we need to fetch it with the key.
         const response = await fetch(`${downloadLink}&key=${apiKey}`);
         if (!response.ok) throw new Error("Failed to fetch video bytes");
         const blob = await response.blob();
         return URL.createObjectURL(blob);
       }
       throw new Error("No video URI returned");
 
    } catch (e) {
      console.error("Video generation failed (likely requires paid project/quota)", e);
      // Fallback for "workable" demo experience
      return "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4";
    }
 };

export const enhancePrompt = async (currentInput: string): Promise<string> => {
    try {
        const apiKey = getApiKey();
        if (!apiKey) return currentInput;
        
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Improve this prompt for a professional AI assistant to get a detailed, accurate response. Output ONLY the improved prompt text. Input: "${currentInput}"`
        });
        return response.text?.trim() || currentInput;
    } catch (e) {
        console.error("Prompt enhancement failed", e);
        return currentInput;
    }
};

export const generateRelatedQuestions = async (context: string): Promise<string[]> => {
    try {
        const apiKey = getApiKey();
        if (!apiKey) return [];

        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Based on this text, generate 3 relevant, professional follow-up questions for a user to ask. Return ONLY the questions, one per line. Text: ${context.substring(0, 500)}...`
        });
        const text = response.text || "";
        return text.split('\n').filter(line => line.trim().length > 0 && line.includes('?')).slice(0, 3);
    } catch (e) {
        return [];
    }
}