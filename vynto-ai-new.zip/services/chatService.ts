import { supabase } from './supabaseClient';
import { ChatSession, Message } from '../types';

// Map DB session to frontend type
const mapDBSessionToChatSession = (dbSession: any): ChatSession => ({
    id: dbSession.id,
    title: dbSession.title,
    messages: dbSession.messages as Message[],
    createdAt: new Date(dbSession.created_at).getTime()
});

export const getSessions = async (userId: string): Promise<ChatSession[]> => {
    const { data, error } = await supabase
        .from('chat_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data.map(mapDBSessionToChatSession);
};

export const createSession = async (session: Omit<ChatSession, 'id' | 'createdAt'>, userId: string): Promise<ChatSession> => {
    const { data, error } = await supabase
        .from('chat_sessions')
        .insert([{
            user_id: userId,
            title: session.title,
            messages: session.messages
        }])
        .select()
        .single();
        
    if (error) throw error;
    return mapDBSessionToChatSession(data);
};

export const deleteSession = async (sessionId: string): Promise<void> => {
    const { error } = await supabase
        .from('chat_sessions')
        .delete()
        .eq('id', sessionId);

    if (error) throw error;
};
