import { supabase, isSupabaseConfigured } from './supabaseClient';
import { ChatSession, Message } from '../types';

const LOCAL_STORAGE_SESSION_KEY = 'vynto_local_sessions';

// Helper to get local sessions
const getLocalSessions = (): ChatSession[] => {
    try {
        const stored = localStorage.getItem(LOCAL_STORAGE_SESSION_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch {
        return [];
    }
};

// Helper to save local sessions
const saveLocalSessions = (sessions: ChatSession[]) => {
    localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify(sessions));
};

const mapDBSessionToChatSession = (dbSession: any): ChatSession => ({
    id: dbSession.id,
    title: dbSession.title,
    messages: dbSession.messages as Message[],
    createdAt: new Date(dbSession.created_at).getTime()
});

export const getSessions = async (userId: string): Promise<ChatSession[]> => {
    // If backend is missing, use local storage
    if (!isSupabaseConfigured) {
        return getLocalSessions();
    }

    const { data, error } = await supabase
        .from('chat_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data.map(mapDBSessionToChatSession);
};

export const createSession = async (session: Omit<ChatSession, 'id' | 'createdAt'>, userId: string): Promise<ChatSession> => {
    // If backend is missing, use local storage
    if (!isSupabaseConfigured) {
        const newSession: ChatSession = {
            id: Date.now().toString(),
            title: session.title,
            messages: session.messages,
            createdAt: Date.now()
        };
        const sessions = getLocalSessions();
        saveLocalSessions([newSession, ...sessions]);
        return newSession;
    }

    const { data, error } = await supabase
        .from('chat_sessions')
        .insert([{
            user_id: userId,
            title: session.title,
            messages: session.messages
        }])
        .select()
        .single();
        
    if (error) throw error;
    return mapDBSessionToChatSession(data);
};

export const deleteSession = async (sessionId: string): Promise<void> => {
    // If backend is missing, use local storage
    if (!isSupabaseConfigured) {
        const sessions = getLocalSessions();
        const filtered = sessions.filter(s => s.id !== sessionId);
        saveLocalSessions(filtered);
        return;
    }

    const { error } = await supabase
        .from('chat_sessions')
        .delete()
        .eq('id', sessionId);

    if (error) throw error;
};
